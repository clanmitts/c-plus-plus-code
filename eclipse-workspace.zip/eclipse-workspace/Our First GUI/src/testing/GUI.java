package testing;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class GUI{
	
	static int count = 0;
	
	private JLabel label;
	private JFrame frame;
	private JButton button;
	private JButton button2;
	private JPanel panel;
	
	public GUI() {
		frame = new JFrame();
		
		button = new JButton(new AbstractAction("Click me") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				count ++;
				label.setText("Number of clicks: " + count);
			}
		});
		button.setPreferredSize(new Dimension(100, 50));
		button2 = new JButton(new AbstractAction("Don't click me") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				button.setVisible(false);
				label.setText("YOU SHOULDN't HAVE CLICKED THE BUTTON!!!");
			}
		});
		button2.setPreferredSize(new Dimension(100, 50));
		
		label = new JLabel("Number of clicks: 0");
		
		panel = new JPanel();
	
		
		panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50)); //width of the top bottom left and right
		panel.setLayout(new GridLayout(0, 1));
		
		panel.add(button);
		panel.add(button2);
		panel.add(label);
		
		
		frame.add(panel, BorderLayout.CENTER); // add the pannel to the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // set what happesn when they close the frame
		frame.setTitle("Our GUI");
		frame.pack();
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		new GUI();
		
		
	}
}

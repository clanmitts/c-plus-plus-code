module module {
	requires java.desktop;
}
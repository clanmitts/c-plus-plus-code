package ChatGPT;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create a button
        Button button = new Button("Click me!");

        // Create a layout container to hold the button
        StackPane layout = new StackPane();
        layout.getChildren().add(button);

        // Create a scene and add the layout to it
        Scene scene = new Scene(layout, 300, 250);

        // Set the scene on the primary stage and show the stage
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
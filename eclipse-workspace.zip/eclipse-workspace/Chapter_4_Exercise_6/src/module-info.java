module Chapter_4_Exercise_6 {
}
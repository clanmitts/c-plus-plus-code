package Grade_12_Culminating;

public class move {

	static String name; // name of move
	static int bp; // base power of move
	static String type; // type of move
	static String split; // whether move is physical of special
}

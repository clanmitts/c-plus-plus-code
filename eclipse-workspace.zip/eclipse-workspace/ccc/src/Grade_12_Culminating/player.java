package Grade_12_Culminating;

import java.util.InputMismatchException;
import java.util.Scanner;

public class player {
	static int poke1num;
	static int poke2num;
	static int binarySearchPokemon(String pokemon) { // checks if the Pokemon exists
		int l = 1; int r = 893;
	        while (l <= r) {
	        	int m = l + (r - l) / 2;
	        	if (main.pokemon[m].name.equals(pokemon)) return m;
	            if (main.pokemon[m].name.compareTo(pokemon) < 0)l = m + 1;
	            else r = m - 1;
	        }
	        return -1;
	}
	static int binarySearchMove(String move) { // checks if the move exists
		int l = 1; int r = 733;
	        while (l <= r) {
	        	int m = l + (r - l) / 2;
	        	if (main.move[m][1].equals(move)) return m;
	            if (main.move[m][1].compareTo(move) < 0) l = m + 1;
	            else r = m - 1;
	        }
	        return -1;
	}
	static void inputPokemon1() { // valid Pokemon are ones contained in the pokemon.txt file
		Scanner input = new Scanner(System.in);
		while (true) {
			System.out.print("Enter the first pokemon (only letters): ");
			String temp = input.nextLine().trim().toUpperCase().replaceAll(" ", "");
			if (binarySearchPokemon(temp) != -1) {
				poke1num = binarySearchPokemon(temp);
				main.poke1.name = temp;
				break;
			}
			System.out.println("Sorry. cannot find that pokemon");
		}
		main.poke1.type1 = main.pokemon[poke1num].type1;
		main.poke1.type2 = main.pokemon[poke1num].type2;
		main.poke1.base[0] = main.pokemon[poke1num].base[0];
		main.poke1.base[1] = main.pokemon[poke1num].base[1];
		main.poke1.base[2] = main.pokemon[poke1num].base[2];
		main.poke1.base[3] = main.pokemon[poke1num].base[3];
		main.poke1.base[4] = main.pokemon[poke1num].base[4];
		main.poke1.base[5] = main.pokemon[poke1num].base[5];
		main.poke1.iv[0] = 31;
		main.poke1.iv[1] = 31;
		main.poke1.iv[2] = 31;
		main.poke1.iv[3] = 31;
		main.poke1.iv[4] = 31;
		main.poke1.iv[5] = 31;
	}
	static void inputEV1() { // each stat is 0-252 and the total of all stats cannot surpass 510
		Scanner input = new Scanner(System.in);
		try {
			while (true) {
				System.out.println("Enter the EVs of every stat (Each stat is 0-252. Total of all stats is 0-510) ");
				System.out.print("HP: ");
				int tempHP = input.nextInt();
				input.nextLine();
				if (tempHP < 0 || tempHP > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("ATTACK: ");
				int tempATTACK = input.nextInt();
				input.nextLine();
				if (tempATTACK < 0 || tempATTACK > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("DEFENSE: ");
				int tempDEFENSE = input.nextInt();
				input.nextLine();
				if (tempDEFENSE < 0 || tempDEFENSE > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPECIAL ATTACK: ");
				int tempSPATTACK = input.nextInt();
				input.nextLine();
				if (tempSPATTACK < 0 || tempSPATTACK > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPECIAL DEFENSE: ");
				int tempSPDEFENSE = input.nextInt();
				input.nextLine();
				if (tempSPDEFENSE < 0 || tempSPDEFENSE > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPEED: ");
				int tempSPEED = input.nextInt();
				input.nextLine();
				if (tempSPEED < 0 || tempSPEED > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				if (tempHP + tempATTACK + tempDEFENSE + tempSPATTACK + tempSPDEFENSE + tempSPEED > 510) {
					System.out.println("Sorry this is not a valid EV spread. ");
					continue;
				}
				main.poke1.ev[0] = tempHP;
				main.poke1.ev[1] = tempATTACK;
				main.poke1.ev[2] = tempDEFENSE;
				main.poke1.ev[3] = tempSPATTACK;
				main.poke1.ev[4] = tempSPDEFENSE;
				main.poke1.ev[5] = tempSPEED;
				break;
			}
		}
		catch(InputMismatchException e) {
			System.out.println("You didn't enter a number");
			inputEV1();
		}
	}
	static void inputNature1() { // nature needs to one of the listed ones. 
		Scanner input = new Scanner(System.in);
		while (true ) {
			System.out.println("Enter the nature (The word)");
			System.out.println("1. Adamant - raises ATTACK, lowers SPECIAL ATTACK\r\n"
					+ "2. Bashful - neutral\r\n"
					+ "3. Bold - raises DEFENSE, lowers ATTACK\r\n"
					+ "4. Brave - raises ATTACK, lowers SPEED\r\n"
					+ "5. Calm - raises SPECIAL DEFENSE, lowers ATTACK\r\n"
					+ "6. Careful - raises SPECIAL DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "7. Docile - neutral\r\n"
					+ "8. Gentle - raises SPECIAL DEFENSE, lowers DEFENSE\r\n"
					+ "9. Hardy - neutral\r\n"
					+ "10. Hasty - raises SPEED, lowers DEFENSE\r\n"
					+ "11. Impish - Raises DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "12. Impish - raises DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "13. Lax - raises DEFENSE, lowers SPECIAL DEFENSE\r\n"
					+ "14. Lonely - raises ATTACK, lowers DEFENSE\r\n"
					+ "15. Mild - raises SPECIAL ATTACK, lowers DEFENSE\r\n"
					+ "16. Modest - raises SPECIAL ATTACK, lowers ATTACK\r\n"
					+ "17. Na�ve - raises SPEED, lowers SPECIAL DEFENSE\r\n"
					+ "18. Naughty - raises ATTACK, lowers SPECIAL DEFENSE\r\n"
					+ "19. Quiet - raises SPECIAL ATTACK, lowers SPEED\r\n"
					+ "20. Quirky - neutral\r\n"
					+ "21. Rash - raises SPECIAL ATTACK, lowers SPECIAL DEFENSE\r\n"
					+ "22. Relaxed - raises DEFENSE, lowers SPEED\r\n"
					+ "23. Sassy - raises SPECIAL DEFENSE, lowers SPEED\r\n"
					+ "24. Serious - neutral\r\n"
					+ "25. Timid - raises SPEED, lowers ATTACK");
			String temp = input.nextLine().trim().toUpperCase();
			if (main.nature.contains(temp)) {
				main.poke1.nature = temp;
				break;
			}
			System.out.println("Sorry that wasn't one of the natures. ");
		}
	}
	static void inputPokemon2() {
		Scanner input = new Scanner(System.in);
		while (true) {
			System.out.print("Enter the second pokemon (only letters): ");
			String temp = input.nextLine().trim().toUpperCase().replaceAll(" ", "");
			if (binarySearchPokemon(temp) != -1) {
				poke2num = binarySearchPokemon(temp);
				main.poke2.name = temp;
				break;
			}
			System.out.println("Sorry. cannot find that pokemon");
		}
		main.poke2.type1 = main.pokemon[poke2num].type1;
		main.poke2.type2 = main.pokemon[poke2num].type2;
		main.poke2.base[0] = main.pokemon[poke2num].base[0];
		main.poke2.base[1] = main.pokemon[poke2num].base[1];
		main.poke2.base[2] = main.pokemon[poke2num].base[2];
		main.poke2.base[3] = main.pokemon[poke2num].base[3];
		main.poke2.base[4] = main.pokemon[poke2num].base[4];
		main.poke2.base[5] = main.pokemon[poke2num].base[5];
		main.poke2.iv[0] = 31;
		main.poke2.iv[1] = 31;
		main.poke2.iv[2] = 31;
		main.poke2.iv[3] = 31;
		main.poke2.iv[4] = 31;
		main.poke2.iv[5] = 31;
	}
	static void inputEV2() {
		Scanner input = new Scanner(System.in);
		try {
			while (true) {
				System.out.println("Enter the EVs of every stat (Each stat is 0-252. Total of all stats is 0-510) ");
				System.out.print("HP: ");
				int tempHP = input.nextInt();
				input.nextLine();
				if (tempHP < 0 || tempHP > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("ATTACK: ");
				int tempATTACK = input.nextInt();
				input.nextLine();
				if (tempATTACK < 0 || tempATTACK > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("DEFENSE: ");
				int tempDEFENSE = input.nextInt();
				input.nextLine();
				if (tempDEFENSE < 0 || tempDEFENSE > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPECIAL ATTACK: ");
				int tempSPATTACK = input.nextInt();
				input.nextLine();
				if (tempSPATTACK < 0 || tempSPATTACK > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPECIAL DEFENSE: ");
				int tempSPDEFENSE = input.nextInt();
				input.nextLine();
				if (tempSPDEFENSE < 0 || tempSPDEFENSE > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				System.out.print("SPEED: ");
				int tempSPEED = input.nextInt();
				input.nextLine();
				if (tempSPEED < 0 || tempSPEED > 252) {
					System.out.println("Sorry this is not a valud EV. ");
					continue;
				}
				if (tempHP + tempATTACK + tempDEFENSE + tempSPATTACK + tempSPDEFENSE + tempSPEED > 510) {
					System.out.println("Sorry this is not a valid EV spread. ");
					continue;
				}
				main.poke2.ev[0] = tempHP;
				main.poke2.ev[1] = tempATTACK;
				main.poke2.ev[2] = tempDEFENSE;
				main.poke2.ev[3] = tempSPATTACK;
				main.poke2.ev[4] = tempSPDEFENSE;
				main.poke2.ev[5] = tempSPEED;
				break;
			}
		}
		catch(InputMismatchException e) {
			System.out.println("You didn't enter a number.");
			inputEV2();
		}
	}
	static void inputNature2() {
		Scanner input = new Scanner(System.in);
		while (true ) {
			System.out.println("Enter the nature (The word)");
			System.out.println("1. Adamant - raises ATTACK, lowers SPECIAL ATTACK\r\n"
					+ "2. Bashful - neutral\r\n"
					+ "3. Bold - raises DEFENSE, lowers ATTACK\r\n"
					+ "4. Brave - raises ATTACK, lowers SPEED\r\n"
					+ "5. Calm - raises SPECIAL DEFENSE, lowers ATTACK\r\n"
					+ "6. Careful - raises SPECIAL DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "7. Docile - neutral\r\n"
					+ "8. Gentle - raises SPECIAL DEFENSE, lowers DEFENSE\r\n"
					+ "9. Hardy - neutral\r\n"
					+ "10. Hasty - raises SPEED, lowers DEFENSE\r\n"
					+ "11. Impish - Raises DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "12. Impish - raises DEFENSE, lowers SPECIAL ATTACK\r\n"
					+ "13. Lax - raises DEFENSE, lowers SPECIAL DEFENSE\r\n"
					+ "14. Lonely - raises ATTACK, lowers DEFENSE\r\n"
					+ "15. Mild - raises SPECIAL ATTACK, lowers DEFENSE\r\n"
					+ "16. Modest - raises SPECIAL ATTACK, lowers ATTACK\r\n"
					+ "17. Na�ve - raises SPEED, lowers SPECIAL DEFENSE\r\n"
					+ "18. Naughty - raises ATTACK, lowers SPECIAL DEFENSE\r\n"
					+ "19. Quiet - raises SPECIAL ATTACK, lowers SPEED\r\n"
					+ "20. Quirky - neutral\r\n"
					+ "21. Rash - raises SPECIAL ATTACK, lowers SPECIAL DEFENSE\r\n"
					+ "22. Relaxed - raises DEFENSE, lowers SPEED\r\n"
					+ "23. Sassy - raises SPECIAL DEFENSE, lowers SPEED\r\n"
					+ "24. Serious - neutral\r\n"
					+ "25. Timid - raises SPEED, lowers ATTACK");
			String temp = input.nextLine().trim().toUpperCase();
			if (main.nature.contains(temp)) {
				main.poke2.nature = temp;
				break;
			}
			System.out.println("Sorry that wasn't one of the natures. ");
		}
	}
	static void inputMoves1() {
		Scanner input = new Scanner(System.in);
		for (int q = 1; q <= 4; q++) {
			while (true) {
				System.out.print("Enter move #" + q + " for the first pokemon: ");
				String temp = input.nextLine().trim().replaceAll(" ", "").toUpperCase();
				if (binarySearchMove(temp) != -1) {
					main.move1[q] = binarySearchMove(temp);
					break;
				}
				System.out.println("Sorry cannot find this move. ");
			}
		}
	}
	static void inputMoves2() {
		Scanner input = new Scanner(System.in);
		for (int i = 1; i <= 4; i++) {
			while (true) {
				System.out.print("Enter move #" + i + " for the second pokemon: ");
				String temp = input.nextLine().trim().replaceAll(" ", "").toUpperCase();
				if (binarySearchMove(temp) != -1) {
					main.move2[i] = binarySearchMove(temp);
					break;
				}
				System.out.println("Sorry cannot find this move. ");
			}
		}
	}
}

package Grade_12_Culminating;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class filework {

	public static void inputPokemon() throws IOException {
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("pokemon.txt")));
			for (int i = 1; i <= 893; i++) {
				String str;
				while ((str = br.readLine()).length() < 12 || !(str).substring(0, 12).equals("InternalName"));
				main.pokemon[i].name = str.substring(13, str.length());
				while ((str = br.readLine()).length() < 5 || !(str).substring(0, 5).equals("Type1"));
				main.pokemon[i].type1 = str.substring(6, str.length());
				if ((str = br.readLine()).length() < 5 ||(str).substring(0, 5).equals("Type2")) {
					main.pokemon[i].type2 = str.substring(6, str.length());;
					str = br.readLine();
				}
				else {
					main.pokemon[i].type2 = "NA";
				}
				String [] temp = str.substring(10, str.length()).trim().split(",");
				for (int j = 0; j < 6; j++) {
					main.pokemon[i].base[j] = Integer.parseInt(temp[j]);
				}
				
			}
		}
		catch (FileNotFoundException e) {
			
		}
		quicksortPokemon(1, 893);
	}
	public static void inputMoves() throws IOException {
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("moves.txt")));
			for (int i = 1; i <= 733; i++) {
				main.move[i] = br.readLine().trim().split(",");
			}
		}
		catch(FileNotFoundException e) {
			
		}
		quicksortMove(1, 733);
	}
	public static void quicksortPokemon(int low, int high) {
		if (low < high) {
            int pi = partitionPokemon(low, high);
            quicksortPokemon(low, pi - 1);
            quicksortPokemon(pi + 1, high);
        }
	}
	static void swapPokemon(int i, int j) {
        pokemon temp = main.pokemon[i];
        main.pokemon[i] = main.pokemon[j];
        main.pokemon[j] = temp;
    }
    static int partitionPokemon (int low, int high){
        String pivot = main.pokemon[high].name;
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++) {
            if (main.pokemon[j].name.compareTo(pivot) < 0) {
                i++;
                swapPokemon(i, j);
            }
        }
        swapPokemon(i + 1, high);
        return (i + 1);
    }
	public static void quicksortMove(int low, int high) {
		if (low < high) {
            int pi = partitionMove(low, high);
            quicksortMove(low, pi - 1);
            quicksortMove(pi + 1, high);
        }
	}
	static void swapMove(int i, int j) {
        String [] temp = main.move[i];
        main.move[i] = main.move[j];
        main.move[j] = temp;
    }
    static int partitionMove (int low, int high){
        String pivot = main.move[high][1];
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++) {
            if (main.move[j][1].compareTo(pivot) < 0) {
                i++;
                swapMove(i, j);
            }
        }
        swapMove(i + 1, high);
        return (i + 1);
    }
}

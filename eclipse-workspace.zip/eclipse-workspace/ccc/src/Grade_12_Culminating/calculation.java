package Grade_12_Culminating;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class calculation {
	private static final DecimalFormat df = new DecimalFormat("0.00");
	static void calculateStats() {
		main.poke1.real[0] = (int) Math.floor(0.01 * (2*main.poke1.base[0]+main.poke1.iv[0] + Math.floor(0.25*main.poke1.ev[0]))*100) + 100 + 10; // stat formula for hp
		for (int i = 1; i <= 5; i++) {
			main.poke1.real[i] = ((int) Math.floor(0.01 * (2*main.poke1.base[i]+main.poke1.iv[i] + Math.floor(0.25*main.poke1.ev[i]))*100)+5); // stat formula for all other stats
		}
		if (main.poke1.nature.equals("LONELY")) { // the 25 different natures decide which stat gets a 10% boost and which stat gets a 10% decrease
			main.poke1.real[1] *= 1.1;
			main.poke1.real[2] *= 0.9;
		}
		if (main.poke1.nature.equals("BRAVE")) {
			main.poke1.real[1] *= 1.1;
			main.poke1.real[5] *= 0.9;
		}
		if (main.poke1.nature.equals("ADAMANT")) {
			main.poke1.real[1] *= 1.1;
			main.poke1.real[3] *= 0.9;
		}
		if (main.poke1.nature.equals("NAUGHTY")) {
			main.poke1.real[1] *= 1.1;
			main.poke1.real[4] *= 0.9;
		}
		if (main.poke1.nature.equals("BOLD")) {
			main.poke1.real[2] *= 1.1;
			main.poke1.real[1] *= 0.9;
		}
		if (main.poke1.nature.equals("RELAXED")) {
			main.poke1.real[2] *= 1.1;
			main.poke1.real[5] *= 0.9;
		}
		if (main.poke1.nature.equals("IMPISH")) {
			main.poke1.real[2] *= 1.1;
			main.poke1.real[3] *= 0.9;
		}
		if (main.poke1.nature.equals("LAX")) {
			main.poke1.real[2] *= 1.1;
			main.poke1.real[4] *= 0.9;
		}
		if (main.poke1.nature.equals("MODEST")) {
			main.poke1.real[3] *= 1.1;
			main.poke1.real[1] *= 0.9;
		}
		if (main.poke1.nature.equals("MILD")) {
			main.poke1.real[3] *= 1.1;
			main.poke1.real[2] *= 0.9;
		}
		if (main.poke1.nature.equals("QUIET")) {
			main.poke1.real[3] *= 1.1;
			main.poke1.real[5] *= 0.9;
		}
		if (main.poke1.nature.equals("RASH")) {
			main.poke1.real[3] *= 1.1;
			main.poke1.real[4] *= 0.9;
		}
		if (main.poke1.nature.equals("CALM")) {
			main.poke1.real[4] *= 1.1;
			main.poke1.real[1] *= 0.9;
		}
		if (main.poke1.nature.equals("GENTLE")) {
			main.poke1.real[4] *= 1.1;
			main.poke1.real[2] *= 0.9;
		}
		if (main.poke1.nature.equals("SASSY")) {
			main.poke1.real[4] *= 1.1;
			main.poke1.real[5] *= 0.9;
		}
		if (main.poke1.nature.equals("CAREFUL")) {
			main.poke1.real[4] *= 1.1;
			main.poke1.real[3] *= 0.9;
		}
		if (main.poke1.nature.equals("TIMID")) {
			main.poke1.real[5] *= 1.1;
			main.poke1.real[1] *= 0.9;
		}
		if (main.poke1.nature.equals("HASTY")) {
			main.poke1.real[5] *= 1.1;
			main.poke1.real[2] *= 0.9;
		}
		if (main.poke1.nature.equals("JOLLY")) {
			main.poke1.real[5] *= 1.1;
			main.poke1.real[3] *= 0.9;
		}
		if (main.poke1.nature.equals("NAIVE")) {
			main.poke1.real[5] *= 1.1;
			main.poke1.real[4] *= 0.9;
		}
		main.poke2.real[0] = (int) Math.floor(0.01 * (2*main.poke2.base[0]+main.poke2.iv[0] + Math.floor(0.25*main.poke2.ev[0]))*100) + 100 + 10;
		for (int i = 1; i <= 5; i++) {
			main.poke2.real[i] = ((int) Math.floor(0.01 * (2*main.poke2.base[i]+main.poke2.iv[i] + Math.floor(0.25*main.poke2.ev[i]))*100)+5);
		}
		if (main.poke2.nature.equals("LONELY")) {
			main.poke2.real[1] *= 1.1;
			main.poke2.real[2] *= 0.9;
		}
		if (main.poke2.nature.equals("BRAVE")) {
			main.poke2.real[1] *= 1.1;
			main.poke2.real[5] *= 0.9;
		}
		if (main.poke2.nature.equals("ADAMANT")) {
			main.poke2.real[1] *= 1.1;
			main.poke2.real[3] *= 0.9;
		}
		if (main.poke2.nature.equals("NAUGHTY")) {
			main.poke2.real[1] *= 1.1;
			main.poke2.real[4] *= 0.9;
		}
		if (main.poke2.nature.equals("BOLD")) {
			main.poke2.real[2] *= 1.1;
			main.poke2.real[1] *= 0.9;
		}
		if (main.poke2.nature.equals("RELAXED")) {
			main.poke2.real[2] *= 1.1;
			main.poke2.real[5] *= 0.9;
		}
		if (main.poke2.nature.equals("IMPISH")) {
			main.poke2.real[2] *= 1.1;
			main.poke2.real[3] *= 0.9;
		}
		if (main.poke2.nature.equals("LAX")) {
			main.poke2.real[2] *= 1.1;
			main.poke2.real[4] *= 0.9;
		}
		if (main.poke2.nature.equals("MODEST")) {
			main.poke2.real[3] *= 1.1;
			main.poke2.real[1] *= 0.9;
		}
		if (main.poke2.nature.equals("MILD")) {
			main.poke2.real[3] *= 1.1;
			main.poke2.real[2] *= 0.9;
		}
		if (main.poke2.nature.equals("QUIET")) {
			main.poke2.real[3] *= 1.1;
			main.poke2.real[5] *= 0.9;
		}
		if (main.poke2.nature.equals("RASH")) {
			main.poke2.real[3] *= 1.1;
			main.poke2.real[4] *= 0.9;
		}
		if (main.poke2.nature.equals("CALM")) {
			main.poke2.real[4] *= 1.1;
			main.poke2.real[1] *= 0.9;
		}
		if (main.poke2.nature.equals("GENTLE")) {
			main.poke2.real[4] *= 1.1;
			main.poke2.real[2] *= 0.9;
		}
		if (main.poke2.nature.equals("SASSY")) {
			main.poke2.real[4] *= 1.1;
			main.poke2.real[5] *= 0.9;
		}
		if (main.poke2.nature.equals("CAREFUL")) {
			main.poke2.real[4] *= 1.1;
			main.poke2.real[3] *= 0.9;
		}
		if (main.poke2.nature.equals("TIMID")) {
			main.poke2.real[5] *= 1.1;
			main.poke2.real[1] *= 0.9;
		}
		if (main.poke2.nature.equals("HASTY")) {
			main.poke2.real[5] *= 1.1;
			main.poke2.real[2] *= 0.9;
		}
		if (main.poke2.nature.equals("JOLLY")) {
			main.poke2.real[5] *= 1.1;
			main.poke2.real[3] *= 0.9;
		}
		if (main.poke2.nature.equals("NAIVE")) {
			main.poke2.real[5] *= 1.1;
			main.poke2.real[4] *= 0.9;
		}
	}
	static void calculateDamage() {
		for (int i = 1; i <= 4; i++) { //loops through all four moves the pokemon has
			if (main.move[main.move1[i]][6].equals("Physical")) { // if the move is physical, uses the attack and defense stat. special attacks use spattack and spdefense stat. status move deal no damage
				main.damage1[i][0] = ((2*100)/5+2*Integer.parseInt(main.move[main.move1[i]][4])*(double)main.poke1.real[1]/main.poke2.real[2]*0.85)/main.poke2.real[0]*100;
				main.damage1[i][1] = ((2*100)/5+2*Integer.parseInt(main.move[main.move1[i]][4])*(double)main.poke1.real[1]/main.poke2.real[2])/main.poke2.real[0]*100; // there is a damage roll in pokemon. A move will randomly deal between 85-100% of its max damage
			}
			else if (main.move[main.move1[i]][6].equals("Special")) {
				main.damage1[i][0] = (2*100)/5+2*Integer.parseInt(main.move[main.move1[i]][4])*(double)main.poke1.real[3]/main.poke2.real[4]*0.85/main.poke2.real[0]*100;
				main.damage1[i][1] = (2*100)/5+2*Integer.parseInt(main.move[main.move1[i]][4])*(double)main.poke1.real[3]/main.poke2.real[4]/main.poke2.real[0]*100;
			}
			if (main.move[main.move1[i]][5].equals(main.poke1.type1) || main.move[main.move1[i]][5].equals(main.poke1.type2)) { // if the move is the same type as the offensive pokemon, the moves power gets a 1.5 times boost
				main.damage1[i][0] *= 1.5;
				main.damage1[i][1] *= 1.5;
			}
			type.str.set(0, main.move[main.move1[i]][5].toUpperCase()); // checks whether a move is super effect or not very effective against the opposing pokemon. Supper effective is x2. Not very effective is x0.5
			type.str.set(1, main.poke2.type1.toUpperCase());
			main.damage1[i][0] *= (main.typeChart.get(type.str));
			main.damage1[i][1] *= (main.typeChart.get(type.str));
			type.str.set(1, main.poke2.type2.toUpperCase());
			if (!main.poke2.type2.equals("NA")) {
				main.damage1[i][0] *= (main.typeChart.get(type.str));
				main.damage1[i][1] *= (main.typeChart.get(type.str));
			}
			
			main.damage1[i][0] = Double.parseDouble(df.format(main.damage1[i][0]));
			main.damage1[i][1] = Double.parseDouble(df.format(main.damage1[i][1]));
		}
		for (int i = 1; i <= 4; i++) {
			if (main.move[main.move2[i]][6].equals("Physical")) { //same thing for the second pokemon
				main.damage2[i][0] = (2*100)/5+2*Integer.parseInt(main.move[main.move2[i]][4])*(double)main.poke2.real[1]/main.poke1.real[2]*0.85/main.poke1.real[0]*100;
				main.damage2[i][1] = (2*100)/5+2*Integer.parseInt(main.move[main.move2[i]][4])*(double)main.poke2.real[1]/main.poke1.real[2]/main.poke1.real[0]*100;
			}
			else if (main.move[main.move2[i]][6].equals("Special")) {
				main.damage2[i][0] = (2*100)/5+2*Integer.parseInt(main.move[main.move2[i]][4])*(double)main.poke2.real[3]/main.poke1.real[4]*0.85/main.poke1.real[0]*100;
				main.damage2[i][1] = (2*100)/5+2*Integer.parseInt(main.move[main.move2[i]][4])*(double)main.poke2.real[3]/main.poke1.real[4]/main.poke1.real[0]*100;
			}
			if (main.move[main.move2[i]][5].equals(main.poke2.type1) || main.move[main.move2[i]][5].equals(main.poke2.type2)) {
				main.damage2[i][0] *= 1.5;
				main.damage2[i][1] *= 1.5;
			}
			type.str.set(0, main.move[main.move2[i]][5].toUpperCase());
			type.str.set(1, main.poke1.type1.toUpperCase());
			
			main.damage2[i][0] *= (main.typeChart.get(type.str));
			main.damage2[i][1] *= (main.typeChart.get(type.str));
			type.str.set(1, main.poke1.type2.toUpperCase());
			if (!main.poke1.type2.equals("NA")) {
				main.damage2[i][0] *= (main.typeChart.get(type.str));
				main.damage2[i][1] *= (main.typeChart.get(type.str));
			}
			
			main.damage2[i][0] = Double.parseDouble(df.format(main.damage2[i][0]));
			main.damage2[i][1] = Double.parseDouble(df.format(main.damage2[i][1]));
		}
	}
}

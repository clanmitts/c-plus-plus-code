package Grade_12_Culminating;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public class main {
	static class pair{
		String att;
		String def;
		public pair(String att, String def) {
			this.att = att;
			this.def = def;
		}
	}
	static pokemon [] pokemon = new pokemon [894];
	static String [][] move = new String [734][1]; // The relevant data is Internal name at index 1, bp at index 4, type at index 5, and split at index 6
	static String nature = "Adamant\r\n"
			+ "Bashful\r\n"
			+ "Brave\r\n"
			+ "Bold\r\n"
			+ "Calm\r\n"
			+ "Careful\r\n"
			+ "Docile\r\n"
			+ "Gentle\r\n"
			+ "Hardy\r\n"
			+ "Hasty\r\n"
			+ "Impish\r\n"
			+ "Jolly\r\n"
			+ "Lax\r\n"
			+ "Lonely\r\n"
			+ "Mild\r\n"
			+ "Modest\r\n"
			+ "Naive\r\n"
			+ "Naughty\r\n"
			+ "Quiet\r\n"
			+ "Quirky\r\n"
			+ "Rash\r\n"
			+ "Relaxed\r\n"
			+ "Sassy\r\n"
			+ "Serious\r\n"
			+ "Timid";
	static pokemon poke1 = new pokemon();
	static pokemon poke2 = new pokemon();
	static int [] move1 = new int [5]; // the 4 moves for both pokemon
	static int [] move2 = new int [5];
	static double [][] damage1 = new double [5][2]; // the percent damage range the move can do to the opposing pokemon
	static double [][] damage2 = new double [5][2];
	static HashMap<ArrayList<String>, Double> typeChart = new HashMap<ArrayList<String>, Double>();
	/* The type chart will store whether a move is super effective or not very effective against another move
	 * the first index is the attacking type and the second index is the defending type
	 * */
	public static void main(String[] args) throws IOException {
		nature = nature.toUpperCase();
		for (int i = 1; i <= 893; i++) pokemon[i] = new pokemon();
		type.create();
	
		filework.inputPokemon();
		filework.inputMoves(); 
		player.inputPokemon1();
		player.inputEV1();
		player.inputNature1(); //inputting the necessary data
		player.inputMoves1();
		player.inputPokemon2();
		player.inputEV2();
		player.inputNature2();
		player.inputMoves2();
		calculation.calculateStats();
		calculation.calculateDamage(); // calculates the real stats and how much damage each move does
		display.print();
		display.change(); // printing then letting the use change any inputs to see how the damage would change
	}
}

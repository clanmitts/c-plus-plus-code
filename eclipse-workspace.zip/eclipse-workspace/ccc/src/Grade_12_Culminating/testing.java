package Grade_12_Culminating;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;

public class testing {
	// this was just for me to test random things while coding
	private static final DecimalFormat df = new DecimalFormat("0.00");
	public static void main(String [] args ) throws IOException {
		double n = 1.2334234234;
		System.out.println(df.format(n));
		
	}

}

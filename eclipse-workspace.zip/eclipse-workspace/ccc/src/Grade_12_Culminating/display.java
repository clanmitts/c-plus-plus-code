package Grade_12_Culminating;

import java.text.DecimalFormat;
import java.util.Scanner;

public class display {
	private static final DecimalFormat df = new DecimalFormat("0.00");
	static void print() { // displays the minimum and maximum damage each move can do shown as a percentage of the opposing pokemons health. Rounded to 2 decimal places
		System.out.println();
		System.out.println(main.poke1.name);
		for (int i = 1; i <= 4; i++) {
			System.out.println(main.move[main.move1[i]][1] + ": " + df.format(main.damage1[i][0]) + "-" + df.format(main.damage1[i][1]) + "%");
		}
		System.out.println(main.poke2.name);
		for (int i = 1; i <= 4; i++) {
			System.out.println(main.move[main.move2[i]][1] + ": " + df.format(main.damage2[i][0]) + "-" + df.format(main.damage2[i][1]) + "%");
		}
		System.out.println();
	}
	static void change() { // players can change any variable and see how it changes the damage dealt
		System.out.println("What variables do you want to change (Enter the number)?\r\n"
				+ "1. Pokemon #1\r\n"
				+ "2. Pokemon #2\r\n"
				+ "3. EVs of Pokemon #1\r\n"
				+ "4. EVs of Pokemon #2\r\n"
				+ "5. Nature of Pokemon #1\r\n"
				+ "6. Nature of Pokemon #2\r\n"
				+ "7. Moves of Pokemon #1\r\n"
				+ "8. Moves of Pokemon #2\r\n"
				+ "9. Exit the program");
		Scanner input = new Scanner(System.in);
		int n = Integer.parseInt(input.nextLine().trim());
		if (n == 1) player.inputPokemon1();
		else if (n == 2) player.inputPokemon2();
		else if (n == 3) player.inputEV1();
		else if (n == 4) player.inputEV2();
		else if (n == 5) player.inputNature1();
		else if (n == 6) player.inputNature2();
		else if (n == 7) player.inputMoves1();
		else if (n == 8) player.inputMoves2();
		else if (n == 9) return;
		calculation.calculateStats();
		calculation.calculateDamage();
		print();
		change();
	}
}

package Grade_12_Culminating;

public class pokemon {
	String name; // internal name
	String type1; // first type
	String type2; // type 2. stores NA if there is no type 2
	int [] base = new int [6]; // base stats of the pokemon (hp, attack, defense, special attack, special defense, speed)
	int [] iv = new int [6]; // IVs of the pokemon
	int [] ev = new int [6]; // EVs of the pokemon
	int [] real = new int [6]; // real stats after calculation
	String nature; // nature of pokemon
}

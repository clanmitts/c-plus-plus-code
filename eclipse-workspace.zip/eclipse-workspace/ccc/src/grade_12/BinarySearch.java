package grade_12;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.StringTokenizer;

public class BinarySearch {

	static ArrayList<String> arr = new ArrayList<String>();
	static char [][] arr1 = new char [10][10], arr2 = new char [10][10], arr4 = new char [10][10];
	static ArrayList<String> arr3 = new ArrayList<String>();
	static HashSet<String> h = new HashSet<String>();
	static int maxScore = 0;
	
	static boolean works(String str) {
		for (int i = 0; i < 10; i++) if (new String(arr1[i]).contains(str) 
				|| new String(arr2[i]).contains(str) 
				||  new String(arr1[i]).contains(new StringBuilder(str).reverse().toString()) 
				|| new String(arr2[i]).contains(new StringBuilder(str).reverse().toString())) return true;
		for (String i: arr3) if (i.contains(str) || i.contains(new StringBuilder(str).reverse().toString())) return true;
		return false;
	}
	static void sort() throws IOException {
		try {
		BufferedReader br = new BufferedReader(new FileReader(new File("dictionary.txt")));
			String str;
			while ((str = br.readLine()) != null) {
				str = str.trim();
				arr.add(str);
			}
		}
		catch(FileNotFoundException e) {
			System.out.println("File Not Found");
			return;
		}
		Collections.sort(arr);
		BufferedWriter bw = new BufferedWriter(new FileWriter("dictionary.txt"));
		for (String i: arr) {
			bw.write(i);
			bw.newLine();
		}
		bw.close();
	}
	static boolean real (String str) {
		int l = 0;
		int r = arr.size()-1;
		while (l <= r) {
			int mid = (l+r)/2;
			if (arr.get(mid).equals(str)) return true;
			if (arr.get(mid).compareTo(str) > 0) r = mid-1;
			if (arr.get(mid).compareTo(str) < 0) l = mid+1;
		}
		return false;
	}
	static void create() {
		Random rand = new Random();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				arr1[i][j] = (char) (rand.nextInt(26) + 'a');
			}
		}
	}
	
	
	/*static int count(String str, char c) {
		int counter = 0;
		for (int i = 0; i < str.length(); i++) if (str.charAt(i) == c) counter ++;
		return counter;
	}
	static int score(String str) {
		int score = 0;
		int tempScore = 0;
		for (int i = 0; i < 10; i++) {
			tempScore = 0;
			for (int j = 0; j < str.length(); j++) {
				tempScore += Math.max(count(new String(grid[i]), str.charAt(j)), count(str, str.charAt(j)));
			}
			score = Math.max(score, tempScore);
		}
		String tempString = "";
		for (int i = 0; i < 10; i++) {
			tempString = "";
			tempScore = 0;
			for (int j = 0; j < 10; j++) {
				tempString += grid[j][i];
			}
			for (int j = 0; j < str.length(); j++) {
				tempScore += Math.max(count(tempString, str.charAt(j)), count(str, str.charAt(j)));
			}
		}
	}*/
	public static void main(String[] args) throws IOException {
		sort();
		create();
		for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++) arr2[j][i] = arr1[i][j];
		for (int i = 0; i < 10; i++) arr4[i] = arr1[10-i-1];
		for (int i = 0; i < 10; i++) {
			for (int j = 1; j <= 4; j++) arr3.add("");
			for (int j = 0; i+j < 10; j++) arr3.set(arr3.size()-4, arr3.get(arr3.size()-4) + arr1[i+j][j]);
			for (int j = 0; i+j < 10; j++) arr3.set(arr3.size()-3, arr3.get(arr3.size()-3) + arr1[j][i+j]);
			for (int j = 0; i+j < 10; j++) arr3.set(arr3.size()-2, arr3.get(arr3.size()-2) + arr4[i+j][j]);
			for (int j = 0; i+j < 10; j++) arr3.set(arr3.size()-1, arr3.get(arr3.size()-1) + arr4[j][i+j]);
		}
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(arr1[i][j]);
			}
			System.out.println();
		}
		BufferedReader br2 = new BufferedReader(new FileReader(new File("HighScore.txt")));
		int HighScore =0;
		try {HighScore = Integer.parseInt(br2.readLine()); }
		catch (FileNotFoundException e) {
			
		}
		System.out.println("your current high score is: " + HighScore);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		String temp = "";
		boolean done = false;
		while (true) {
			if (done) break;
			System.out.println("Your score is currectly: " + maxScore);
			System.out.println("Enter a word to find (enter -1 to exit) :");
			while (true) {
				st = new StringTokenizer(br.readLine());
				temp = st.nextToken().toLowerCase().trim();
				if (!h.add(temp)) {
					System.out.println("You already guessed this word");
					break;
				}
				if (temp.equals("-1")) {
					done = true;
					break;
				}
				System.out.println("Sorry, that word isn't found in the dictionary. Enter a real word.");
			}
			if (done) break;
			if (works(temp)) {
				System.out.println("The word was found");
				maxScore += temp.length();
			}
			else {
				System.out.println("The word was not found");
			}
		}
		System.out.println("Your final score is: " + maxScore);
		if (maxScore > HighScore) {
			BufferedWriter bw = new BufferedWriter(new FileWriter("HighScore.txt"));
			bw.write(HighScore);
			bw.close();
		}
	}

}

package grade_12;

import java.util.Scanner;

public class assign13 {
	static char [][] a = new char [5][5];
	static char [][] b = new char [10000][10000];
	static int m;
	public static void magnify() {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				for (int k = 1; k <= m; k++) {
					for (int l = 1; l <= m; l++) {
						b[(i-1)*m + k][(j-1)*m + l] = a[i][j-1];
					}
				}
			}
		}
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		for (int i = 1; i <= 4; i++) {
			a[i] = input.nextLine().trim().toCharArray();
		}
		System.out.println("Enter the magnifying factor: ");
		m = input.nextInt();
		magnify();
		for (int i = 1; i <= 4*m; i++) {
			for (int j = 1; j <= 4*m; j++) {
				System.out.print(b[i][j]);
			}
			System.out.println();
		}
	}
}

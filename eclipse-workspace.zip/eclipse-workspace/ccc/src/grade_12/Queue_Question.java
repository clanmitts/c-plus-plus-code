package grade_12;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

public class Queue_Question {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner input = new Scanner(System.in);
		System.out.println("How many children will there be: ");
		int n = input.nextInt();
		input.nextLine();
		Queue<String> q = new LinkedList<String>();
		for (int i = 1; i <= n; i++) {
			q.add(input.nextLine());
		}
		while (q.size() > 1) {
			int temp = rand.nextInt(10)+1;
			for (int i = 1; i <= temp; i++) {
				q.add(q.poll());
			}
			System.out.println(q.peek() + " was eliminated");
			q.poll();
		}
		System.out.println(q.peek() + " is the winner!!");
	}
}

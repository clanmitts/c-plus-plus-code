package grade_12;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class WordSearch {
	static char [][] arr1 = new char [100][100], arr2 = new char [100][100], arr4 = new char [100][100];
	static ArrayList<String> arr3 = new ArrayList<String>();
	static String works(int n, String str) {
		for (int i = 0; i < n; i++) if (new String(arr1[i]).contains(str) || new String(arr2[i]).contains(str) ||  new String(arr1[i]).contains(new StringBuilder(str).reverse().toString()) || new String(arr2[i]).contains(new StringBuilder(str).reverse().toString())) return (str + " was found in the board");
		for (String i: arr3) if (i.contains(str) || i.contains(new StringBuilder(str).reverse().toString())) return (str + " was found in the board");
		return (str + " was not found in the board. ");
	}
	public static void main(String[] args) throws IOException{
		try { 
			BufferedReader br = new BufferedReader(new FileReader(new File("wordSearchBoard.txt")));
			int n = Integer.parseInt(br.readLine());
			for (int i = 0; i < n; i++) arr1[i] = br.readLine().toCharArray();
			for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) arr2[j][i] = arr1[i][j];
			for (int i = 0; i < n; i++) arr4[i] = arr1[n-i-1];
			for (int i = 0; i < n; i++) {
				for (int j = 1; j <= 4; j++) arr3.add("");
				for (int j = 0; i+j < n; j++) arr3.set(arr3.size()-4, arr3.get(arr3.size()-4) + arr1[i+j][j]);
				for (int j = 0; i+j < n; j++) arr3.set(arr3.size()-3, arr3.get(arr3.size()-3) + arr1[j][i+j]);
				for (int j = 0; i+j < n; j++) arr3.set(arr3.size()-2, arr3.get(arr3.size()-2) + arr4[i+j][j]);
				for (int j = 0; i+j < n; j++) arr3.set(arr3.size()-1, arr3.get(arr3.size()-1) + arr4[j][i+j]);
			}
			br = new BufferedReader(new FileReader(new File("wordSearchWords.txt")));
			String str;
			while ((str = br.readLine()) != null) System.out.println(works(n, str));
		}
		catch (Exception e) {System.out.println("File input isn't right");
		};
	}
}

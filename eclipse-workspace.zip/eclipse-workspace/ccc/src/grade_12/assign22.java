package grade_12;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class assign22 {
	static String [] name = new String [1000000];
	static class math {
		static double mean(int [] arr, int ind) {
			double total = 0;
			for (int i = 1; i <= ind; i++) {
				total += arr[i];
			}
			total /= ind;
			total *= 10;
			Math.round(total);
			total /= 10;
			return total;
		}
		static int min(int [] arr, int ind) {
			return arr[1];
		}
		static int max(int [] arr, int ind) {
			return arr[ind];
		}
		static double median(int [] arr, int l, int r) {
			if (((r-l)+1) % 2 == 0) {
				return ((arr[(l+r-1)/2] + arr[(l+r-1)/2+1])/2.0); 
			}
			else {
				return (arr[(l+r-1)/2+1]);
			}
		}
		static void mode(int [] arr, int index) {
			int high = 0;
			int [] freq = new int [1000000];
			for (int i = 1; i <= index; i++) {
				freq[arr[i]] ++;
				if (freq[arr[i]] > high) high = freq[arr[i]];
			}
			if (high == 1) System.out.println("There is no mode.");
			else {
				System.out.print("Modes:");
				for (int i = 1; i <= 100000; i++) {
					if (freq[i] == high) System.out.print(" " +i);
				}
				System.out.println();
			}
		}
		
	}
		static void swap(int[] arr, int a, int b){
	        int temp = arr[a];
	        arr[a] = arr[b];
	        arr[b] = temp;
	        String t = name[a];
	        name[a] = name[b];
	        name[b] = t;
	    }
	    static int partition(int[] arr, int l, int r) {
	        int pivot = arr[r];
	        int i = (l - 1);
	 
	        for (int j = l; j <= r - 1; j++) {
	            if (arr[j] < pivot) {
	                i++;
	                swap(arr, i, j);
	            }
	        }
	        swap(arr, i + 1, r);
	        return (i + 1);
	    }
	    static void quickSort(int[] arr, int low, int high){
	        if (low < high) {
	            int pi = partition(arr, low, high);
	            quickSort(arr, low, pi - 1);
	            quickSort(arr, pi + 1, high);
	        }
	    }
    public static void main(String[] args) throws IOException{
    	Scanner input = new Scanner(System.in);
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    	StringTokenizer st;
    	int index = 0;
    	int [] arr = new int [10000000];
    	System.out.println("Enter mark then name");
        while (true) {
        	st = new StringTokenizer(br.readLine());
        	int temp = Integer.parseInt(st.nextToken());
        	if (temp == -1) break;
        	index++;
        	arr[index] = temp;
        	String n = st.nextToken();
        	name[index] = n;
        }
        quickSort(arr, 1, index);
        System.out.println("mean: " + math.mean(arr, index));
        math.mode(arr,  index);
        System.out.println("min: " + arr[1]);
        System.out.println("max: " + arr[index]);
        System.out.println("median: " + math.median(arr, 1, index));
        System.out.println("Q1: " + math.median(arr, 1, index/2));
        if (index%2 == 0) {
        	System.out.println("Q3: " + math.median(arr, index/2 + 1, index));
        }
        else {
        	System.out.println("Q3: " + math.median(arr,  index/2 + 2, index));
        }
    }
}

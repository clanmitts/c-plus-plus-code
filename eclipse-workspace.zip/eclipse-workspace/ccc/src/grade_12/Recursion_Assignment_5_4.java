

package grade_12;

import java.util.Scanner;

public class Recursion_Assignment_5_4 {
	static int thing(int n, int m, int counter) {
		if (counter == m) return n;
		counter ++;
		if (counter % 2 == 0) return thing (2*n + 3,  m, counter);
		return thing(n-2, m, counter);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n;
		n = input.nextInt();
		int m;
		m = input.nextInt();
		System.out.println(thing(n, m, 1));
	}

}

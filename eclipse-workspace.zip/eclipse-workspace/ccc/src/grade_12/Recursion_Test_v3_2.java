package grade_12;

import java.util.Scanner;

public class Recursion_Test_v3_2 {
	public static int thing(String cipher, String str, int ind) {
		if (ind == str.length()) return 0;
		if ('a' <= str.charAt(ind) && str.charAt(ind) <= 'z' ) {
			System.out.print(cipher.charAt(str.charAt(ind)-'a'));
		}
		else {
			System.out.print(str.charAt(ind));
		}
		return thing(cipher, str, ind+1);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Cipher alphabet: ");
		String cipher = input.nextLine().trim();
		System.out.print("Enter plaintext to be encrypted: ");
		System.out.print("Encrypted CipherText: ");
		String str = input.nextLine().trim();
		thing(cipher, str, 0);
	}

}

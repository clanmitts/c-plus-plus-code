package grade_12;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class assign24 {
	static int [] arr = new int [1000001];
	static int ind = 0;
	static int [][] add = new int [1000][1000];
	static int [] total = new int [1000001];
	static void swap(int a, int b){
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }
    static int partition(int l, int r) {
        int pivot = arr[r];
        int i = (l - 1);
 
        for (int j = l; j <= r - 1; j++) {
            if (arr[j] < pivot) {
                i++;
                swap( i, j);
            }
        }
        swap(i + 1, r);
        return (i + 1);
    }
    static void quickSort(int low, int high){
        if (low < high) {
            int pi = partition(low, high);
            quickSort(low, pi - 1);
            quickSort(pi + 1, high);
        }
    }
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter scores -1 to end");
		while (true) {
			int temp = input.nextInt();
			if (temp == -1) break;
			ind ++;
			arr[ind] = temp;
		}
		quickSort(1, ind);
		for (int i = 1; i <= ind; i++) {
			int temp = 1;
			for (int j = 1; j < ind; j++) {
				if (temp == i) temp++;
				add[j][i] = arr[i]-arr[temp];
				temp++;
			}
		}
		for (int j = 1; j <= ind; j++) {
			for (int i = 1; i < ind; i++) {
				total[j] += add[i][j];
			}
		}
		for (int i = 1; i <= ind; i++) {
			System.out.print("   " + arr[i] + "\t");
		}
		System.out.println();
		for (int i = 1; i <= ind*8; i++) {
			System.out.print('-');
		}
		System.out.println();
		for (int i = 1; i < ind; i++) {
			for (int j = 1; j <= ind; j++) {
				if (add[i][j] >= 0)System.out.print("   " + add[i][j] + "\t");
				else System.out.print("  " + add[i][j] + "\t");
			}
			System.out.println();
		}
		for (int i = 1; i <= ind*8; i++) {
			System.out.print('-');
		}
		System.out.println();
		for (int i = 1; i <= ind; i++) {
			if (total[i] >= 0) System.out.print("   " + total[i] + "\t");
			else System.out.print("  " + total[i] + "\t");
		}
		System.out.println();
	}
}

package grade_12;

import java.util.Scanner;

public class Recursion_Test_v3_1 {
	static boolean notPrime(int a, int b) {
		if (a == b) return false;
		if (b % a == 0) return true;
		return notPrime(a+1, b);
	}
	static void check (int a, int b) {
		if (a > b) return;
		if (notPrime(2, a)) {
			System.out.print(a + " ");
		}
		check(a+1, b);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		check(3, n);
	}

}

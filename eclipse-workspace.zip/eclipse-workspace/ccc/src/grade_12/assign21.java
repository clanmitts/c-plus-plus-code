package grade_12;

import java.util.Random;
import java.util.Scanner;

public class assign21 {
	static String [] arr;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a sentence: ");
		arr = input.nextLine().trim().split(" ");
		for (String i: arr) {
			for (int j = 0; j < i.length(); j++) {
				for (int k = 1; k <= i.length()-j-1; k++) {
					System.out.print(" ");
				}
				for (int k = 0; k <= j; k++) {
					System.out.print(i.charAt(k));
				}
				for (int k = j-1; k >= 0; k--) {
					System.out.print(i.charAt(k));
				}
				System.out.println();
			}
			for (int j = i.length()-2; j >= 1; j--) {
				for (int k = 1; k <= i.length()-j-1; k++) {
					System.out.print(" ");
				}
				for (int k = 0; k <= j; k++) {
					System.out.print(i.charAt(k));
				}
				for (int k = j-1; k >= 0; k--) {
					System.out.print(i.charAt(k));
				}
				System.out.println();
			}
			for (int j = 0; j < i.length(); j++) {
				for (int k = 1; k <= i.length()-1; k++) {
					System.out.print(" ");
				}
				System.out.println(i.charAt(j));
			}
		}
	}
}
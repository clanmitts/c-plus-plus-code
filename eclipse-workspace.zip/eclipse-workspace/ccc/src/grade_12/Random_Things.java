package grade_12;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;

public class Random_Things {

	public static void main(String[] args) {
        HashMap<String, Integer> precedence = new HashMap<>();
        precedence.put("+", 1);
        precedence.put("-", 1);
        precedence.put("*", 2);
        precedence.put("/", 2);
        precedence.put("^", 3);

        Stack<Double> operands = new Stack<>();
        Stack<String> operators = new Stack<>();

        Scanner input = new Scanner(System.in);
        String expression = input.nextLine();
        String[] tokens = expression.trim().split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                operands.push(Double.parseDouble(token));
            } else {
                while (!operators.isEmpty() && precedence.get(operators.peek()) >= precedence.get(token)) {
                    evaluateStackTop(operands, operators);
                }
                operators.push(token);
            }
        }

        while (!operators.isEmpty()) {
            evaluateStackTop(operands, operators);
        }

        System.out.println(operands.pop());
    }

    private static boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?");
    }

    private static void evaluateStackTop(Stack<Double> operands, Stack<String> operators) {
        String operator = operators.pop();
        double operand2 = operands.pop();
        double operand1 = operands.pop();

        switch (operator) {
            case "+":
                operands.push(operand1 + operand2);
                break;
            case "-":
                operands.push(operand1 - operand2);
                break;
            case "*":
                operands.push(operand1 * operand2);
                break;
            case "/":
                operands.push(operand1 / operand2);
                break;
            case "^":
                operands.push(Math.pow(operand1, operand2));
                break;
        }
    }

}

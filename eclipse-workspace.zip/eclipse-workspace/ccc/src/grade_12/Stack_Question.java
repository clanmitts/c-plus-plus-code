package grade_12;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;


public class Stack_Question {

	public static void main(String[] args) {
		//Assumes that there are at least 1 operator and 2 numbers
		HashMap<String, Integer> h  = new HashMap<String, Integer>();
		h.put("+", 1);
		h.put("-", 2);
		h.put("*", 3);
		h.put("/", 4);
		h.put("^", 5);
		Stack<Double> num = new Stack<Double>();
		Stack<String> opp = new Stack<String>();
		Scanner input = new Scanner(System.in);
		String [] arr = input.nextLine().trim().split(" ");
		num.push(Double.parseDouble(arr[0]));
		for (String i: arr) {
			if (h.containsKey(i)) {
				while (!opp.isEmpty() && h.get(opp.peek()) >= h.get(i)) {
					if (opp.peek().equals("+")) {
						double b = num.pop();
						double a = num.pop();
						num.push(a+b);
						opp.pop();
					}
					else if (opp.peek().equals("-")) {
						double b = num.pop();
						double a = num.pop();
						num.push(a-b);
						opp.pop();
					}
					else if (opp.peek().equals("*")) {
						double b = num.pop();
						double a = num.pop();
						num.push(a*b);
						opp.pop();
					}
					else if (opp.peek().equals("/")) {
						double b = num.pop();
						double a = num.pop();
						num.push(a/b);
						opp.pop();
					}
					else if (opp.peek().equals("^")) {
						double b = num.pop();
						double a = num.pop();
						num.push(Math.pow(a, b));
						opp.pop();
					}
				}
				opp.push(i);
			}
			else {
				num.push(Double.parseDouble(i));
			}
		}
		while (!opp.isEmpty()) {
			if (opp.peek().equals("+")) {
				double b = num.pop();
				double a = num.pop();
				num.push(a+b);
				opp.pop();
			}
			else if (opp.peek().equals("-")) {
				double b = num.pop();
				double a = num.pop();
				num.push(a-b);
				opp.pop();
			}
			else if (opp.peek().equals("*")) {
				double b = num.pop();
				double a = num.pop();
				num.push(a*b);
				opp.pop();
			}
			else if (opp.peek().equals("/")) {
				double b = num.pop();
				double a = num.pop();
				num.push(a/b);
				opp.pop();
			}
			else if (opp.peek().equals("^")) {
				double b = num.pop();
				double a = num.pop();
				num.push(Math.pow(a, b));
				opp.pop();
			}
		}
		System.out.println(num.pop());
	}
}

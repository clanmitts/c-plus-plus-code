package grade_12;

import java.util.Random;
import java.util.Scanner;

public class Assign14 {
	static boolean [] used = new boolean [100];
	static int total = 0;
	static String str = "";
	static int counter = 0;
	public static void main(String[] args) {
		Random rand = new Random();
		while (counter < 10) {
			int temp = rand.nextInt(50)+1;
			if (!used[temp]) {
				used[temp] = true;
				counter ++;
				str += Integer.toString(temp);
			}
		}
		for (int i = 0; i < str.length(); i += 2) {
			total += (str.charAt(i)-'0');
		}
		System.out.println(total);
	}
}

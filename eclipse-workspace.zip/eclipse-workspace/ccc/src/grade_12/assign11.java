package grade_12;

import java.util.Scanner;

public class assign11 {
	static double height;
	static double hip;
	static String gender;
	static double age;
	static double percent;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter height in cm: ");
		height = input.nextDouble();
		System.out.println("Enter hip cicumderence in cm: ");
		hip = input.nextDouble();
		System.out.println("Enter gender(enter either m or f): ");
		input.nextLine();
		gender = input.nextLine().trim();
		System.out.println("Enter your age: ");
		age = input.nextDouble();
		percent = (hip/Math.pow(height/100, 1.5)) - 18;
		percent = Math.round(percent*10)/10;
		System.out.println("You BAI is: " + percent);
		if (gender.equals("f")) {
			if (20 <= age && age <= 39) {
				if (percent < 21) System.out.println("You are underweight.");
				else if (21 <= percent && percent <= 33) System.out.println("You are healthy.");
				else if (33 < percent && percent <= 39) System.out.println("You are overweight.");
				else if (43 < percent) System.out.println("You are Obese.");
				
			}
			else if (40 <= age && age <= 59) {
				if (percent < 23) System.out.println("You are underweight.");
				else if (23 <= percent && percent <= 35) System.out.println("You are healthy.");
				else if (35 < percent && percent <= 41) System.out.println("You are overweight.");
				else if (41 < percent) System.out.println("You are Obese.");
				
			}
			if (60 <= age && age <= 79) {
				if (percent < 25) System.out.println("You are underweight.");
				else if (25 <= percent && percent <= 38) System.out.println("You are healthy.");
				else if (38 < percent && percent <= 43) System.out.println("You are overweight.");
				else if (43 < percent) System.out.println("You are Obese.");
				
			}
		}
		else if (gender.equals("m")) {
			if (20 <= age && age <= 39) {
				if (percent < 8) System.out.println("You are underweight.");
				else if (8 <= percent && percent <= 21) System.out.println("You are healthy.");
				else if (21 < percent && percent <= 26) System.out.println("You are overweight.");
				else if (26 < percent) System.out.println("You are Obese.");
				
			}
			else if (40 <= age && age <= 59) {
				if (percent < 11) System.out.println("You are underweight.");
				else if (11 <= percent && percent <= 23) System.out.println("You are healthy.");
				else if (23 < percent && percent <= 29) System.out.println("You are overweight.");
				else if (29 < percent) System.out.println("You are Obese.");
				
			}
			if (60 <= age && age <= 79) {
				if (percent < 13) System.out.println("You are underweight.");
				else if (13 <= percent && percent <= 25) System.out.println("You are healthy.");
				else if (25 < percent && percent <= 31) System.out.println("You are overweight.");
				else if (31 < percent) System.out.println("You are Obese.");
				
			}
		}
	}
}

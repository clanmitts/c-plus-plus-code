package grade_12;

import java.util.ArrayList;
import java.util.Scanner;

// NOT FINISHED YET

//sdghsodifhodxhvndxinmc      

public class Recursion_Assignment_5_5 {
	public static String recursion (String str) {
		if (str.toLowerCase().replaceAll(" ", "").equals(new StringBuffer(str.toLowerCase().replaceAll(" ", "")).reverse().toString())) return str;
		String s1 = recursion(str.substring(1, str.length()));
		String s2 = recursion(str.substring(0, str.length()-1));
		if (s1.length() > s2.length()) return s1;
		return s2;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str = input.nextLine().trim();
		System.out.println(recursion(str));
	
	}
}

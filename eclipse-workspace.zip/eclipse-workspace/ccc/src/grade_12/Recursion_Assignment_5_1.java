package grade_12;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

class ans {
	int q;
	int r;
	ans(int a, int b) {
		q = a;
		r = b;
	}
}

public class Recursion_Assignment_5_1 {
	static ans divide (int a, int b, int q, int r) {
		if (a < b) return new ans(q, a);
		return divide(a-b, b, q+1, r);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		int a;
		int b;
		int q = 0;
		int r = 0;
		System.out.println("First number :");
		st = new StringTokenizer(br.readLine());
		a = Integer.parseInt(st.nextToken());
		System.out.println("Divided by what number? ");
		st = new StringTokenizer(br.readLine());
		b = Integer.parseInt(st.nextToken());
		ans ans = divide(a, b, q, r);
		System.out.println(a + " Divided by " + b + " is " + ans.q + " with a remainder of " + ans.r);
	}

}

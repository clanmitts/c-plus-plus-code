package grade_12;

import java.util.Scanner;

public class Recursion_Assignment_5_6 {
	static int n;
	static int m;
	static char[][] arr;
	static int [][] vis;
	public static boolean maze(int x, int y) {
		if (x < 0 || x >= n || y < 0 || y >= m) return false;
		if (vis[x][y] == 1) return false;
		if (arr[x][y] == 'x') return true;
		if (arr[x][y] != '.'  && arr[x][y] != 'e')return false;
		vis[x][y] = 1;
		arr[x][y] = '+';
		if (maze(x+1, y)) return true;
		if (maze(x-1, y)) return true;
		if (maze(x, y+1)) return true;
		if (maze(x, y-1)) return true;
		arr[x][y] = '.';
		return false;

	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		n = input.nextInt();
		m = input.nextInt();
		arr = new char[n][m];
		vis = new int [n][m];
		input.nextLine();
		for (int i = 0; i < n; i++) arr[i] = input.nextLine().trim().toCharArray();
		int x = 0, y = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] == 'e') {
					x = i;
					y = j;
				}
			}
		}
		maze(x, y);
		arr[x][y] = 'e';
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
	}

}

package grade_12;

import java.util.ArrayList;
import java.util.Scanner;

public class assign12 {
	static ArrayList<Character> winner = new ArrayList<Character>();
	static int [] votes = new int [1000];
	static int most = 0;
	static String str;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the votes: ");
		str = input.nextLine().trim();
		for (int i = 0; i < str.length(); i++) votes[str.charAt(i)]++;
		for (char i = 'A'; i <= 'Z'; i++) {
			if (votes[i] > most) {
				winner = new ArrayList<Character>();
				winner.add(i);
				most = votes[i];
			}
			else if (votes[i] == most) {
				winner.add(i);
			}
		}
		if (winner.size() > 1) {
			System.out.print("Singer " + winner.get(0));
			for (int i = 1; i < winner.size(); i++) {
				System.out.print(", " + winner.get(i));
			}
			System.out.println(" tied with " + most + " votes each.");
		}
		else {
			System.out.println("The Winner is singer " + winner.get(0) + " with " + most + " votes.");
		}
	}
}

package grade_12;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Chapter_12_Exercise_7 {
	static int ind = 0;
	static int llength;
	static int l = 0;
	static int r = 0;
	public static void main(String[] args) throws IOException{
		try {
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			BufferedReader br = new BufferedReader(new FileReader(new File("HTML.txt")));
			System.out.println("What is the maximum line width? ");
			llength = Integer.parseInt(input.readLine());
			String temp;
			String str = "";
			while ((temp = br.readLine()) != null)	str = str + temp + " ";
			while (r < str.length()) {
				if (str.charAt(r) == ' ') {
					System.out.print(str.charAt(r));
					ind ++;
					l++;
					r++;
				}
				else if (str.charAt(r) == '<') {
					while (str.charAt(r) != '>') r++;
					if (str.substring(l, r+1).equals("<br>")) {
						System.out.println();
						ind = 0;
						r++;
						l= r;
					}
					else if (str.substring(l, r+1).equals("<p>")) {
						System.out.println();
						System.out.println();
						ind = 0;
						r++;
						l =r;
					}
					else if (str.substring(l, r+1).equals("<hr>")) {
						while (ind < llength) {
							System.out.print("-");
							ind++;
						}
						System.out.println();
						ind = 0;
						r ++;
						l = r;
					}
				}
				else {
					while (r < str.length() && str.charAt(r) != ' ' && str.charAt(r) != '<') r++;
					if (ind+(r-l) < llength) {
						System.out.print(str.substring(l, r));
						ind = ind + (r-l);
					}
					else {
						System.out.println();
						System.out.print(str.substring(l, r));
						ind = r-l;
						
					}
					l = r;
				}
				if (ind == llength) {
					System.out.println();
					ind = 0;
				}
			}
			
		}
		catch (Exception e) {System.out.println("Right file cannot be found");
		};
	}

}

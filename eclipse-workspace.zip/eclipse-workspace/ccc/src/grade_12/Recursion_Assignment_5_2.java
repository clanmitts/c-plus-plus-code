package grade_12;

import java.util.Scanner;

public class Recursion_Assignment_5_2 {
	static int thing(int n, int total) {
		if (n < 10) {
			return total + n;
		}
		total += n%10;
		n /= 10;
		return thing(n, total);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int n = input.nextInt();
		System.out.println("The sum of digits of " + n + " is " + thing(n, 0));
	}

}

package grade_12;

import java.util.Scanner;

public class Recursion_Assignment_5_3 {
	static boolean isPalindrome(String str) {
		if (str.length() <= 1) return true;
		if (str.charAt(0) != str.charAt(str.length()-1)) return false;
		return isPalindrome(str.substring(1, str.length()-1));
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str = input.nextLine().trim();
		if (isPalindrome(str)) System.out.println(str + " is a palindrome");
		else System.out.println(str + " is not a palindrome");
	}

}

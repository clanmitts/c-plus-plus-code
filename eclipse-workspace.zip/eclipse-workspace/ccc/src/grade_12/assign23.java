package grade_12;

import java.util.Scanner;


public class assign23 {
	//not done
	static int win() {
		for (int i = 1; i <= 6;i ++) {
			for (int j = 1; j <= 4; j++) {
				if (grid[i][j]==1 && 
					grid[i][j]==grid[i+1][j+1] && 
					grid[i][j]==grid[i+2][j+2] &&
					grid[i][j]==grid[i+1][j+3] &&
					grid[i][j]==grid[i+0][j+4]) {
					return 1;
				}
				if (grid[i][j]==2 && 
					grid[i][j]==grid[i+1][j+1] && 
					grid[i][j]==grid[i+2][j+2] &&
					grid[i][j]==grid[i+1][j+3] &&
					grid[i][j]==grid[i+0][j+4]) {
					return 2;
				}
				if (grid[i+2][j]==1 &&
					grid[i+2][j]==grid[i+1][j+1] &&
					grid[i+2][j]==grid[i+0][j+2] &&
					grid[i+2][j]==grid[i+1][j+3] &&
					grid[i+2][j]==grid[i+2][j+4]) {
					return 1;
				}
				if (grid[i+2][j]==1 &&
					grid[i+2][j]==grid[i+1][j+1] &&
					grid[i+2][j]==grid[i+0][j+2] &&
					grid[i+2][j]==grid[i+1][j+3] &&
					grid[i+2][j]==grid[i+2][j+4]) {
					return 1;
				}
			}
		}
		return 0;
	}
	static boolean tie() {
		for (int i = 1; i <= 8; i++) {
			for (int j = 1; j <= 8; j++) {
				if (grid[i][j] == 0) return false;
			}
		}
		return true;
	}
	static void place(int n, int turn) {
		for (int i = 8; i >= 1; i--) {
			if (grid[i][n] == 0) {
				grid[i][n] = turn;
				return;
			}
		}
	}
	static void print() {
		for (int i = 1; i <= 8; i++) {
			for (int j = 1; j <= 8; j++) {
				System.out.print(grid[i][j] + " ");
			}
			System.out.println();
		}
		for (char i = 'A'; i <= 'H'; i++) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println();
	}
	static int [][] grid = new int [9][9];
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		while (true) {
			print();
			System.out.println("Player 1, pick a column: ");
			int n = input.nextLine().trim().charAt(0)-'A'+1;
			place(n, 1);
			if (win() == 1) {
				print();
				System.out.println("player 1 wins!!");
				break;
			}
			print();
			System.out.println("Player 2, pick a row");
			n = input.nextLine().trim().charAt(0)-'A'+1;
			print();
			place(n, 2);
			if (win() == 2) {
				print();
				System.out.println("Player 2 wins!!");
				break;
			}
			if (tie()) {
				print();
				System.out.println("It's a tie");
				break;
			}
		}
	}
}

package grade_12;

public class Recursion_Test_v3_bonus {

	public static void main(String[] args) {
		int n = 5;
		System.out.println(f(n));
	}
	public static int f(int n) {
		return (n==1)? 4: f(n-1) + (((n+1)%2)*f(n-1)*2) + (n%2*2);
	}

}

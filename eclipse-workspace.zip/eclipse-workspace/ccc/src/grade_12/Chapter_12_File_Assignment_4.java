package grade_12;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Chapter_12_File_Assignment_4 {
	static ArrayList<Integer> num = new ArrayList<Integer>();
	static ArrayList<String> name = new ArrayList<String>();
	static ArrayList<String> married = new ArrayList<String>();
	static ArrayList<Integer> age = new ArrayList<Integer>();
	static ArrayList<Integer> salary = new ArrayList<Integer>();
	
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		/*BufferedWriter WriteFile = new BufferedWriter(new FileWriter("FilesBEx1.txt")); //,true -
		WriteFile.write("Employee\tEmployee Name\tMarital Status\tAge\tSalary\n");
		WriteFile.write("0128\t\tB.Smith\t\tM\t\t\t19\t11000");
		WriteFile.newLine();
		WriteFile.write("1008\t\tH.Holly\t\tS\t\t\t24\t14800");
		WriteFile.newLine();
		WriteFile.write("2009\t\tS.Dan\t\t\tS\t\t\t26\t12000");
		WriteFile.newLine();
		WriteFile.write("1109\t\tT.Fal\t\t\tM\t\t\t32\t16400");
		WriteFile.newLine();
		WriteFile.write("0118\t\tH.Onda\t\tS\t\t\t19\t22000");
		WriteFile.close();*/
		while (true) {
			System.out.println("1. Open File\r\n"
					+ "2. Save File\r\n"
					+ "3. Add a record\r\n"
					+ "4. Delete a record\r\n"
					+ "5. Modify a record\r\n"
					+ "6. Display All\r\n"
					+ "7. Quit\r\n"
					+ "Select a Number:");
			int temp = input.nextInt();
			if (temp == 7) break;
			if (temp == 1) {
				try {
					num = new ArrayList<Integer>();
					name = new ArrayList<String>();
					married = new ArrayList<String>();
					age = new ArrayList<Integer>();
					salary = new ArrayList<Integer>();
					BufferedReader br = new BufferedReader(new FileReader(new File("FilesBEx1.txt")));
					String str;
					br.readLine();
					while ((str = br.readLine()) != null) {
						num.add(Integer.parseInt(str.split("\\t+")[0]));
						name.add(str.split("\\t+")[1]);
						married.add(str.split("\\t+")[2]);
						age.add(Integer.parseInt(str.split("\\t+")[3]));
						salary.add(Integer.parseInt(str.split("\\t+")[4]));
					}
					System.out.println("File Opened Successfully!!");
				}
				catch (FileNotFoundException e) {
					System.out.println("File could no be oppened");
				}
				
			}
			if (temp == 2) {
				try {
					BufferedWriter WriteFile = new BufferedWriter(new FileWriter("FilesBEx1.txt"));
					for (int i = 0; i < num.size(); i++) {
						if (name.get(i).length() <= 4) {
							WriteFile.write(num.get(i) + "\t\t" + name.get(i) + "\t\t\t" + married.get(i) + "\t\t\t" + age.get(i) + "\t" + salary.get(i));
							WriteFile.newLine();
						}
						else {
							WriteFile.write(num.get(i) + "\t\t" + name.get(i) + "\t\t" + married.get(i) + "\t\t\t" + age.get(i) + "\t" + salary.get(i));
							WriteFile.newLine();
						}
					}
					WriteFile.close();
					System.out.println("File Saved Successfully!!");
				}
				catch (FileNotFoundException e) {
					System.out.println("File could not be saved");
				}
			}
			if (temp == 3) {
				
				System.out.print("Employee Number: ");
				num.add(input.nextInt());
				System.out.print("Name: ");
				name.add(input.next());
				System.out.print("Marital Status(M or S): ");
				married.add(input.next());
				System.out.print("Age: ");
				age.add(input.nextInt());
				System.out.print("Salary: ");
				salary.add(input.nextInt());				
			}
			if (temp == 4) {
				if (num.size() == 0) {
					System.out.println("There is no daya stored");
					continue;
				}
				for (int i = 0; i < num.size(); i++) {
					if (name.get(i).length() <= 4) {
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else if (name.get(i).length() <= 8){
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else {
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
				}
				System.out.println("Which one to delete?(Enter the number)");
				int n = input.nextInt();
				num.remove(n);
				name.remove(n);
				married.remove(n);
				age.remove(n);
				salary.remove(n);
			}
			if (temp == 5) {
				if (num.size() == 0) {
					System.out.println("There is no data stored");
					continue;
				}
				for (int i = 0; i < num.size(); i++) {
					if (name.get(i).length() <= 4) {
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else if (name.get(i).length() <= 8){
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else {
						System.out.println(i+1 + ". " + num.get(i) + "\t\t" + name.get(i) + "\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
				}
				System.out.println("Which one to modify?(Enter the number)");
				int n = input.nextInt();
				System.out.print("Employee Number: ");
				num.set(n-1, (input.nextInt()));
				System.out.print("Name");
				name.set(n-1, input.next());
				System.out.print("Marital Status(M or S): ");
				married.set(n-1, input.next());
				System.out.print("Age: ");
				age.set(n-1, input.nextInt());
				System.out.print("Salary: ");
				salary.set(n-1, input.nextInt());		
	
			}
			if (temp == 6) {
				System.out.println("Employee#\tEmployee Name\tMarital Status\tAge\tSalary");
				for (int i = 0; i < num.size(); i++) {
					if (name.get(i).length() <= 4) {
						System.out.println(num.get(i) + "\t\t" + name.get(i) + "\t\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else if (name.get(i).length() <= 8){
						System.out.println(num.get(i) + "\t\t" + name.get(i) + "\t\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
					else {
						System.out.println(num.get(i) + "\t\t" + name.get(i) + "\t" + married.get(i) + "\t\t" + age.get(i) + "\t" + salary.get(i));
					}
				}
			}
		}
		
	}


}

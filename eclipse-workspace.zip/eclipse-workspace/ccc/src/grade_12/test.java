package grade_12;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

public class test {
	static ArrayList<String []> arr = new ArrayList<String []>();
	public static void main(String[] args) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter("ICS4U_test1.txt"));
		bw.write("Business 2 2 5 2 10 61");
		bw.newLine();
		bw.write("Tech 0 0 3 2 0 3");
		bw.newLine();
		bw.write("Co-op 2 3 4 4 6 1");
		bw.close();
		try {
		BufferedReader br = new BufferedReader(new FileReader(new File("ICS4U_test1.txt")));
		String temp;
		while ((temp = br.readLine()) != null) {
			arr.add(temp.split(" "));
		}
		}
		catch (FileNotFoundException e) {
			System.out.println("Couldn't find file");
		}
		while (true) {
			System.out.println("What operation (Enter the coresponding number)?"
					+ "\n1: Add a new record"
					+ "\n2: Display tht total number of IPADS, and the total number of Computers for all Departments"
					+ "\n3: Totals for each column"
					+ "\n4: Display department totals"
					+ "\n5: Quit");
			Scanner input = new Scanner(System.in);
			int n = input.nextInt();
			input.nextLine();
			if (n == 5) break;
			if (n == 1) {
				String str = "";
				System.out.println();
				System.out.println("What department: ");
				str = input.nextLine().trim();
				System.out.println("How many Administrative IPADS: ");
				str = str + " " + input.nextLine().trim();
				System.out.println("How many Administrative Computers: ");
				str = str + " " + input.nextLine().trim();
				System.out.println("How many Teacher IPADS: ");
				str = str + " " + input.nextLine().trim();
				System.out.println("How many Teacher Computers: ");
				str = str + " " + input.nextLine().trim();
				System.out.println("How many Student IPADS: ");
				str = str + " " + input.nextLine().trim();
				System.out.println("How many Student Computers: ");
				str = str + " " + input.nextLine().trim();
				arr.add(str.split(" "));
			}
			if (n == 2) {
				int IPADS = 0;
				int Computers = 0;
				for (String [] i: arr) {
					IPADS += Integer.parseInt(i[1]);
					IPADS += Integer.parseInt(i[3]);
					IPADS += Integer.parseInt(i[5]);
					Computers += Integer.parseInt(i[2]);
					Computers += Integer.parseInt(i[4]);
					Computers += Integer.parseInt(i[6]);
				}
				System.out.println("IPADS - " + IPADS);
				System.out.println("Computers - " + Computers);
				System.out.println();
			}
			if (n == 3) {
				int aIPADS = 0;
				int tIPADS = 0;
				int sIPADS = 0;
				int aComputers = 0;
				int tComputers = 0;
				int sComputers = 0;
				for (String [] i: arr) {
					aIPADS += Integer.parseInt(i[1]);
					tIPADS += Integer.parseInt(i[3]);
					sIPADS += Integer.parseInt(i[5]);
					aComputers += Integer.parseInt(i[2]);
					tComputers += Integer.parseInt(i[4]);
					sComputers += Integer.parseInt(i[6]);
				}
				System.out.println("Administrative - " + aIPADS + " IPADS, " + aComputers + " Computers");
				System.out.println("Teacher - " + tIPADS + " IPADS, " + tComputers + " Computers");
				System.out.println("Student - " + sIPADS + " IPADS, " + sComputers + " Computers");
				System.out.println();
			}
			if (n == 4) {
				for (String [] i: arr) {
					int IPADS = 0;
					int Computers = 0;
					IPADS += Integer.parseInt(i[1]);
					IPADS += Integer.parseInt(i[3]);
					IPADS += Integer.parseInt(i[5]);
					Computers += Integer.parseInt(i[2]);
					Computers += Integer.parseInt(i[4]);
					Computers += Integer.parseInt(i[6]);
					System.out.println(i[0] + " - " + IPADS + " IPADS, " + Computers + " Computers");
				}
				System.out.println();
			}
		}
		bw = new BufferedWriter(new FileWriter("ICS4U_test1.txt"));
		for (String [] i: arr) {
			bw.write(i[0] + " " + i[1] + " " + i[2] + " " + i[3] + " " + i[4] + " " + i[5] + " " + i[6]);
			bw.newLine();
		}
		bw.close();
	}

}

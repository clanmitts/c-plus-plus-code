package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Nations1Secret2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		String str = st.nextToken().trim();
		char [] ascii = new char [str.length()];
		for (int i = 0; i < str.length(); i++) {
			ascii[i] = str.charAt(i);
		}
		str = "";
        boolean list[][] = new boolean[n][n];
        int max = 1;
        for (int i = 0; i < n; ++i)
            list[i][i] = true;
        int start = 0;
        for (int i = 0; i < n - 1; i++) {
            if (ascii[i] == ascii[i + 1]) {
                list[i][i + 1] = true;
                start = i;
                max = 2;
            }
        }
        for (int k = 3; k <= n; k++) {
            for (int i = 0; i < n - k + 1; i++) {
                int j = i + k - 1;
                if (list[i + 1][j - 1]
                    && ascii[i] == ascii[j]) {
                    list[i][j] = true;
                    if (k > max) {
                        start = i;
                        max = k;
                    }
                }
            }
        }
        for (int i = start; i < start+max; i++) {
        	System.out.print((char)(ascii[i]));
        }
        System.out.println();
        System.out.println(max);
	}
}

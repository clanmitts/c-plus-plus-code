package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class RangeMaxQuery {
	static int n;
	static int m;
	public static int log2(int a) {
		return 31-Integer.numberOfLeadingZeros(a);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) list[i] = Integer.parseInt(st.nextToken());
		int [][] rmq = new int [(int)log2(n) + 1][n+1];
		for (int i = 1; i <= n; i++) {
			rmq[0][i] = list[i];
		}
		for (int i = 1; i <= log2(n); i++) {
			for (int j = 1; j + (1 << i) -1 <= n; j++) {
				rmq[i][j] = Math.max(rmq[i-1][j], rmq[i-1][j + (1<<(i-1))]);
			}
		}
		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int c = log2(b-a+1);
			System.out.println(Math.max(rmq[c][a], 
					rmq[c][(int) (b-(1<<c)) + 1]));
		}
	}
}

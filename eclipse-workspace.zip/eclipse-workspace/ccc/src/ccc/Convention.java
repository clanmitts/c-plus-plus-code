package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Convention {
	static int n, m, c;
	static int [] list;
	public static boolean works(int wait){
		int wagons = 1;
		int firstArrival = list[0];
		int firstIndex = 0;
		for(int i = 1; i < n; i++) {
			if(list[i] - firstArrival > wait || i + 1 - firstIndex > c) {
				wagons += 1;
				firstArrival = list[i];
				firstIndex = i;
			}
		}
		return (wagons <= m);
	}
	public static int binSearch(int low,int high)
	{
		if(low == high) return low;
		if(low + 1 == high)
		{
			if(works(low)) return low;
			return high;
		}
		int mid = (low+high)/2;
		if(works(mid)) return binSearch(low,mid);
		else return binSearch(mid+1,high);
	}
	 
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		c = Integer.parseInt(st.nextToken());
		list = new int[n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) list[i] = Integer.parseInt(st.nextToken());
		Arrays.sort(list);
		System.out.println(binSearch(0, 1000000000));
	}
}

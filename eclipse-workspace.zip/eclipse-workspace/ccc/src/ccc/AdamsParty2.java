package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class AdamsParty2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		ArrayList<Integer>[] list = new ArrayList[n+1];
		for (int i = 0; i <= n; i++) list[i] = new ArrayList<Integer>();
		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			list[a].add(b);
			list[b].add(a);
		}
		boolean [] vis = new boolean [n+1];
		int [] adam = new int [n+1];
		Arrays.fill(adam, Integer.MAX_VALUE);
		adam[1] = 0;
		vis[1] = true;
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(1);
		while (!q.isEmpty()) {
			int cur = q.poll();
			for (int i: list[cur]) {
				if (!vis[cur]) {
					vis[i] = true;
					adam[i] = adam[cur]+1;
					q.add(i);
				}
			}
		}
		int [] bruce = new int [n+1];
		Arrays.fill(bruce, Integer.MAX_VALUE);
		bruce[n] = 0;
		vis = new boolean [n+1];
		vis[n] = true;
		q.add(n);
		while (!q.isEmpty()) {
			int cur = q.poll();
			for (int i: list[cur]) {
				if (!vis[i]) {
					vis[i] = true;
					bruce[i] = bruce[cur] +1;
					q.add(i);
				}
			}
		}
		long count = 0;
		for (int i = 2; i < n; i++) {
			if (adam[i] <= k && bruce[i] <= k) count ++;
		}
		System.out.println(count);
		long sum = 1;
		for (int i = 0; i < count; i++) {
			sum = (long) ((sum *2)%(10e9 + 7));
		}
		System.out.println(sum);
	}
}

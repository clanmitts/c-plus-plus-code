package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class NonTransitiveDice {
	public static boolean win (int [] a, int [] b) {
		int count = 0;
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if (a[i] > b[j]) count ++;
				else if (a[i] < b[j]) count --;
			}
		}
		if (count > 0) return true;
		return false;
	}
	public static boolean works (int [] a, int [] b) {
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				for (int k = 1; k <= 10; k++) {
					for (int l = 1; l <= 10; l++) {
						int [] c = {0, i, j, k, l};
						if (win(c, a) && win(b, c)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= t; i++) {
			int [] a = new int [5];
			int [] b = new int [5];
			int [] c = new int [5];
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= 4; j++) {
				a[j] = Integer.parseInt(st.nextToken());
			}
			for (int j = 1; j <= 4; j++) {
				b[j] = Integer.parseInt(st.nextToken());
			}
			if (win(a, b)) {
				if (works(a, b)) {
					System.out.println("yes");
				}
				else {
					System.out.println("no");
				}
			}
			else {
				if (works(b, a)) {
					System.out.println("yes");
				}
				else {
					System.out.println("no");
				}
			}
		}
	}
}

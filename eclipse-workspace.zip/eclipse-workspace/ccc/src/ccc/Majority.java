package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Majority {
	static int n;
	static int [] list;
	static int []freq;
	static int [] psa;
	public static void update(int index, long val) {
		while (index <= 4001) {
			freq[index] += val;
			index += (index & -index);
		}
	}
	public static long freqTo(int index) {
		long sum = 0;
		while (index > 0) {
			sum += freq[index];
			index -= (index & -index);
		}
		return sum;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		freq = new int [4003];
		psa = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= n; i++) {
			if (list[i] == 1) psa[i] = psa[i-1]--;
			else if (list[i] == 2) psa[i] = psa[i-1]++;
		}
		for (int i = 1; i <= n; i++) {
			update(psa[i]+2001, 1);
			System.out.println(freqTo(0-psa[i]+2002));
		}
	}
}

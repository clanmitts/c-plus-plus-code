package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ArithmeticSquare2 {
	static int [][] list;
	static int onePlace;
	public static boolean fill() {
		for (int i = 1; i <= 3; i++) {
			if (list[i][1] != Integer.MAX_VALUE && list[i][3] != Integer.MAX_VALUE && list[i][2] == Integer.MAX_VALUE) {
				list[i][2] = (list[i][1]+list[i][3])/2;
				return true;
			}
			if (list[i][2] != Integer.MAX_VALUE && list[i][3] != Integer.MAX_VALUE && list[i][1] == Integer.MAX_VALUE) {
				list[i][1] = list[i][2]- (list[i][3]-list[i][2]);
				return true;
			}
			if (list[i][1] != Integer.MAX_VALUE && list[i][2] != Integer.MAX_VALUE && list[i][3] == Integer.MAX_VALUE) {
				list[i][2] = list[i][3]- (list[i][1]-list[i][2]);
				return true;
			}
		}
		for (int i = 1; i <= 3; i++) {
			if (list[1][i] != Integer.MAX_VALUE && list[3][i] != Integer.MAX_VALUE && list[2][1] == Integer.MAX_VALUE) {
				list[2][i] = (list[1][i]+list[3][i])/2;
				return true;
			}
			if (list[2][i] != Integer.MAX_VALUE && list[3][i] != Integer.MAX_VALUE && list[1][i] == Integer.MAX_VALUE) {
				list[1][i] = list[2][i]- (list[3][i]-list[2][i]);
				return true;
			}
			if (list[1][i] != Integer.MAX_VALUE && list[2][i] != Integer.MAX_VALUE && list[3][i] == Integer.MAX_VALUE) {
				list[2][i] = list[3][i]- (list[1][i]-list[2][i]);
				return true;
			}
		}
		return false;
	}
	public static boolean one() {
		for (int i = 1; i <= 3; i++) {
			if (list[i][1] != Integer.MAX_VALUE && list[i][2] != Integer.MAX_VALUE && list[i][3] != Integer.MAX_VALUE) {
				onePlace = i;
				return true;
			}
			if (list[1][i] != Integer.MAX_VALUE && list[2][i] != Integer.MAX_VALUE && list[3][i] != Integer.MAX_VALUE) {
				onePlace = i*10;
				return true;
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		list = new int [4][4];
		for (int i = 1; i <= 3; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= 3; j++) {
				String temp = st.nextToken().trim();
				if (!temp.equals("X")) list[i][j] = Integer.parseInt(temp);
				else list[i][j] = Integer.MAX_VALUE;
			}
		}
		boolean works = true;
		while (works) {
			works = false;
			works = fill();
		}
		int count = 0;
		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j <= 3; j++) {
				if (list[i][j] != Integer.MAX_VALUE) {
					count ++;
				}
			}
		}
		if (count == 9) {
			for (int i = 1; i <= 3; i++) {
				for (int j = 1; j <= 3; j++) { 
					System.out.print(list[i][j] + " ");
				}
				System.out.println();
			}
		}
		else {
			if (one()) {
				if (onePlace == 1) {
					int x = 0;
					int y = 0;
					for (int i = 2; i <= 3; i++) {
						for (int j = 1; j <= 3; j++) {
							if (list[i][j] == Integer.MAX_VALUE) {
								x = i;
								y = j;
							}
						}
					}
					if (count == 4) {
						if (x == 3) {
							list[2][y] = (list[1][y]+list[3][y])/2;
						}
						else {
							list[3][y] = list[2][y]-(list[1][y]-list[2][y]);
						}
					}
					if (y == 1) {
						list[2][2] = list[2][1]+ (list[1][2]-list[1][1]) + (list[1][1]-list[2][1]);
						works = true;
						while (works) {
							works = fill();
						}
					}
					if (y == 2) {
						list[2][1] = list[2][2] + (list[1][2]-list[1][3]) + (list[1][2]-list[2][1]);
						works = true;
						while (works) {
							works = fill();
						}
					}
					if (y == 3) {
						list[2][2] = list[2][2]+ (list[1][2]-list[1][1]) + (list[1][3]-list[2][3]);
						works = true;
						while (works) {
							works = fill();
						}
					}
				}
				for (int i = 1; i <= 3; i++) {
					for (int j = 1; j <= 3; j++) { 
						System.out.print(list[i][j] + " ");
					}
					System.out.println();
				}
			}
			else {
				if (list[2][2] == Integer.MAX_VALUE) {
					list[2][2] = 0;
					if (list[1][1] != Integer.MAX_VALUE) {
						list[1][2] = -list[3][2];
						list[2][1] = -list[2][3];
						list[3][1] = -list[2][3]*2 -list[1][1];
						list[1][3] = -list[3][2]*2 - list[1][1];
						list[3][3] = list[2][3]*2 + list[3][2]*2 + list[1][1];
					}
					else if (list[3][1] != Integer.MAX_VALUE) {
						list[2][1] = -list[2][3];
						list[3][2] = -list[1][2];
						list[3][3] = -list[1][2]*2 -list[3][1];
						list[1][1] = -list[2][3]*2 - list[3][1];
						list[1][3] = list[1][2]*2 + list[2][3]*2 + list[3][1];
					}
					else if (list[3][3] != Integer.MAX_VALUE) {
						list[3][2] = -list[1][2];
						list[2][3] = -list[2][1];
						list[1][3] = -list[2][1]*2 -list[3][3];
						list[3][1] = -list[1][2]*2 - list[3][3];
						list[1][1] = list[2][1]*2 + list[1][2]*2 + list[3][3];
					}
					else if (list[1][3] != Integer.MAX_VALUE) {
						list[2][3] = -list[2][1];
						list[1][2] = -list[3][2];
						list[1][1] = -list[3][2]*2 -list[1][3];
						list[3][3] = -list[2][1]*2 - list[1][3];
						list[3][1] = list[3][2]*2 + list[2][1]*2 + list[1][3];
					}
				}
				else {
					if (list[1][1] != Integer.MAX_VALUE) {
						list[2][1] = list[2][2];
						list[2][3] = list[2][2];
						list[3][1] = list[2][2]*2-list[1][1];
						list[1][2] = (list[2][2]*2-list[3][3]+list[1][1])/2;
						list[1][3] = list[2][2]*2-list[3][3];
					}
					else {
						list[3][2] = list[2][2];
						list[1][2] = list[2][2];
						list[3][3] = list[2][2]*2-list[1][1];
						list[2][1] = (list[2][2]*2-list[1][3]+list[3][1])/2;
						list[1][1] = list[2][2]*2-list[1][3];
					}
				}
			}
			for (int i = 1; i <= 3; i++) {
				for (int j = 1; j <= 3; j++) { 
					System.out.print(list[i][j] + " ");
				}
				System.out.println();
			}
		}
	}
}

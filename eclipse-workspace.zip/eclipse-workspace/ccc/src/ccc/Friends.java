package ccc;

public class Friends {

}

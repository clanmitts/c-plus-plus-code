package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;

public class BobsPortalTravel2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		long k = Long.parseLong(st.nextToken());
		boolean [] check = new boolean [n+1];
		int [] list = new int [n+1];
		int [] place = new int [n+1];
		place[1] = 1;
		check[1] = true;
		int [] order = new int [100001];
		order[1] = 1;
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) list[i] = Integer.parseInt(st.nextToken());
		int where = 1;
		int loop = 0;
		int first = 0;
		int last = 0;
		for (int i = 2; i <= 100000; i++) {
			if (check[list[where]] == false) {
				check[list[where]] = true;
				order[i] = list[where];
				place[list[where]] = i;
				where = list[where];
			}
			else {
				first = place[list[where]];
				last = place[where];
				loop = place[where] - place[list[where]] + 1;
				break;
			}
		}
		for (int i = 1; i <= 6; i++) System.out.println(order[i]);
		if (k <= first) {
			System.out.println(order[(int) k]);
		}
		else {
			k = k-first+1;
			long count = k%loop;
			if (count == 0) System.out.println(order[last]);
			else System.out.println(order[first+loop-1]);
		}
	}
}

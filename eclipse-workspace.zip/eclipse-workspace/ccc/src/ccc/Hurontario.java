package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Hurontario {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		String a = st.nextToken().trim();
		String b = st.nextToken().trim();
		int n = a.length();
		int m = b.length();
		for (int i = Math.min(a.length(), b.length()); i >= 1; i++) {
			if (true);
		}
	}
}

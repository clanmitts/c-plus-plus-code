package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class PermutationsPrimes33 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		boolean [] prime = new boolean [100001];
		Arrays.fill(prime, true);
		int count = 0;
		for (int i = 2; i <= 100000; i++) {
			if (prime[i]) {
				for (int j = i+i; j <= 100000; j+= i) {
					prime[j] = false;
				}
			}
		}
		prime[1] = false;
		ArrayList<Integer> primes = new ArrayList<Integer>();
		for (int i = 1; i <= 100000; i++) {
			if (prime[i]) primes.add(i);
		}
		boolean [] dp = new boolean [100001];
		dp[0] = true;
		for (int i = 1; i <= 100000; i++) {
			for (int j: primes) {
				count ++;
				if (!dp[Math.max(i-j, 0)]) {
					dp[i] = true;
					break;
				}
			}
		}
		System.out.println(count);
		int n = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			int x = Integer.parseInt(st.nextToken());
			if (x <= 2) System.out.println(-1);
			else {
				if (dp[x]) {
					System.out.print(1);
					for (int j = 2; j <= x; j++) {
						System.out.print(" " + j);
					}
				}
				else if (dp[x-1]) {
					System.out.print(1);
					for (int j = 2; j < x-1; j++) {
						System.out.print(" " + j);
					}
					System.out.print(" " + x + " " + (x-1));
				}
				else {
					System.out.print(1);
					for (int j = 2; j < x-2; j++) {
						System.out.print(" " + j);
					}
					System.out.print(" " + x + " " + (x-2) + " " + (x-1));
				}
				System.out.println();
			}
		}
	}
}

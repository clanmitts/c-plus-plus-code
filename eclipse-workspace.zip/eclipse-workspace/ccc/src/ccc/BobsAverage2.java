package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

public class BobsAverage2 {
	public static void find
	(List<List<Integer>> subset, ArrayList<Integer> nums, 
			ArrayList<Integer> output, int index){
        if (index == nums.size()) {
            subset.add(output);
            return;
        }
        find(subset, nums, new ArrayList<>(output), index + 1);
        output.add(nums.get(index));
        find(subset, nums, new ArrayList<>(output), index + 1);
    }
 
    public static void main(String[] args) throws IOException{
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    	StringTokenizer st = new StringTokenizer(br.readLine());
    	int m = Integer.parseInt(st.nextToken());
    	int x = Integer.parseInt(st.nextToken());
    	List<List<Integer>> subset = new ArrayList<>();
    	ArrayList<Integer> input = new ArrayList<>();
    	st = new StringTokenizer(br.readLine());
    	for (int i = 0; i < m; i++) input.add(Integer.parseInt(st.nextToken()));
      find(subset, input, new ArrayList<>(), 0);
        Collections.sort(subset, (o1, o2) -> {
            int n = Math.min(o1.size(), o2.size());
            for (int i = 0; i < n; i++) {
                if (o1.get(i) == o2.get(i)){
                    continue;
                }else{
                    return o1.get(i) - o2.get(i);
                }
            }
            return 1;
        });
        int count = 0;
      for(int i = 0; i < subset.size(); i++){
    	  int sum = 0;
          for(int j = 0; j < subset.get(i).size(); j++){
        	  sum += subset.get(i).get(j);
              System.out.print(subset.get(i).get(j) + " ");
          }
          System.out.println();
      }
       
    }
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsStringPower {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		for (int q = 0; q < n; q++) {
			st = new StringTokenizer(br.readLine());
			char [] str = st.nextToken().trim().toCharArray();
			int [] list = new int [str.length];
			for (int i = 1; i < str.length; i++) {
				int k = list[i-1];
				while (true) {
					if (str[i] == str[k]) {
						list[i] = k+1;
						break;
					}
					else if (k == 0) {
						list[i] = 0;
						break;
					}
					else {
						k = list[k-1];
					}
				}
			}
			int temp = str.length - list[str.length-1];
			if (str.length % temp == 0) System.out.println(str.length/temp);
			else System.out.println(1);
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Nations1Secret {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		char [] str = st.nextToken().trim().toCharArray();
		boolean [][] list = new boolean [n][n];
		int max = 1;
		int start = 0;
		for (int i = 0; i < n; i++) {
			list[i][i] = true;
		}
		for (int i = 0; i < n-1; i++) {
			if (str[i] == str[i+1]) {
				list[i][i+1] = true;
				start =  i;
				max = 2;
			}
		}
		for (int i = 3; i <= n; i++) {
			for (int j = 0; j < n - i + 1; j++) {
				int length = j + i - 1;
				if (list[j + 1][length - 1] && str[j] == str[length]) {
					list[j][length] = true;
					if (i > max) {
						start = j;
						max = length;
					}
				}
			}
		}
		System.out.println(start);
		for (int i = start; i < start+max; i++) {
			System.out.print(str[i]);
		}
		 
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class lowestcommonancestor {
	public static int [][] list;
	public static int n;
	public static int q;
	public static int node1, node2;
	public static int LCA(int a) {
		
		if (list[a][0] == -1) return -1;
		if (a == node1 || a == node2) return a;
		if (list[a][1] != 0 && list[a][2] != 0) {
			int x = LCA(list[a][1]);
			int y = LCA(list[a][2]);
			if (x != -1 && y != -1) {
				return a;
			}
		}
		return 0;
	}
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new int [n+1][3];
		for (int i = 0; i < q; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			if (list[a][1] != 0) list[a][2] = b;
			else list[a][1] = b;
		}
		st = new StringTokenizer(br.readLine());
		node1 = Integer.parseInt(st.nextToken());
		node2 = Integer.parseInt(st.nextToken());
		System.out.println(LCA(1));
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.StringTokenizer;

public class ModeFinding {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		HashMap<Integer, Integer> list = new HashMap<Integer, Integer>();
		st = new StringTokenizer(br.readLine());
		int maxNum =Integer.MAX_VALUE;
		int maxValue = Integer.MIN_VALUE;
		for (int i = 0; i < n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (list.containsKey(temp)) {
				list.put(temp, list.get(temp) + 1);
			}
			else {
				list.put(temp, 1);
			}
			if (list.get(temp) > maxValue) {
				maxValue = list.get(temp);
				maxNum = temp;
			}
			else if (list.get(temp) == maxValue) {
				if (temp < maxNum) {
					maxValue = list.get(temp);
					maxNum = temp;
				}
			}
		}
		System.out.println(maxNum);
		
	}
}

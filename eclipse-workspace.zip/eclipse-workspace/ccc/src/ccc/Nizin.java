package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Nizin {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st=  new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		int [] left = new int [n+1];
		int [] right = new int [n+2];
		int l = 1;
		int r = n;
		for (int i = 1; i <= n; i++) left[i] = left[i-1] + list[i];
		for (int i = n; i >= 1; i--) right[i] = right[i+1] + list[i];
		int count = 0;
		while (l < r) {
			if (left[l] == right[r]) {
				l++;
				r--;
			}
			else if (left[l] < right[r]) {
				l++;
				count ++;
			}
			else if (left[l] > right[r]) {
				r--;
				count ++;
			}
		}
		System.out.println(count);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;

public class GoodGroups {
	static HashMap<String, ArrayList<String>> sam;
	static HashSet<String> same;
	static HashMap<String, ArrayList<String>> diff;
	static HashSet<String> different;
	static String [] list;
	public static boolean notSame(String str) {
		for (int i = 1; i <= 3; i++) {
			for (String j: sam.get(str)) {
				if (j.equals(list[i])) {
					return false;
				}
			}
		}
		return true;
	}
	public static boolean notDifferent(String str) {
		for (int i = 1; i <= 3; i++) {
			for (String j: diff.get(str)) {
				if (j.equals(list[i])) {
					return true;
				}
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int x = Integer.parseInt(st.nextToken());
		sam = new HashMap<String, ArrayList<String>>();
		for (int i = 1; i <= x; i++) {
			st = new StringTokenizer(br.readLine());
			String a = st.nextToken().trim();
			String b = st.nextToken().trim();
			if (sam.containsKey(a)) {
				ArrayList<String> temp = sam.get(a);
				temp.add(b);
				sam.put(a, temp);
			}
			else {
				ArrayList<String> temp = new ArrayList<String>();
				temp.add(b);
				sam.put(a, temp);
			}
			if (sam.containsKey(b)) {
				ArrayList<String> temp = sam.get(b);
				temp.add(a);
				sam.put(b, temp);
			}
			else {
				ArrayList<String> temp = new ArrayList<String>();
				temp.add(a);
				sam.put(b, temp);
			}
		}
		st = new StringTokenizer(br.readLine());
		int y = Integer.parseInt(st.nextToken());
		diff = new HashMap<String, ArrayList<String>>();
		for (int i = 1; i <= y; i++) {
			st = new StringTokenizer(br.readLine());
			String a = st.nextToken().trim();
			String b = st.nextToken().trim();
			if (diff.containsKey(a)) {
				ArrayList<String> temp = diff.get(a);
				temp.add(b);
				diff.put(a, temp);
			}
			else {
				ArrayList<String> temp = new ArrayList<String>();
				temp.add(b);
				sam.put(a, temp);
			}
			if (diff.containsKey(b)) {
				ArrayList<String> temp = diff.get(b);
				temp.add(a);
				diff.put(b, temp);
			}
			else {
				ArrayList<String> temp = new ArrayList<String>();
				temp.add(a);
				diff.put(b, temp);
			}
		}
		int count = 0;
		st = new StringTokenizer(br.readLine());
		int g = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= g; i++) {
			list = new String [4];
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= 3; j++ ) {
				list[j] = st.nextToken().trim();
			}
			for (int j = 1; j <= 3; j++) {
				if (sam.containsKey(list[j])) {
					if (notSame(list[j])) {
						count ++;
					}
				}
				if (diff.containsKey(list[j])) {
					if (notDifferent(list[j])) {
						count ++;
					}
				}
			}
		}
		System.out.println(count/2);
	}
}

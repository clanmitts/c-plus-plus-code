package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class StringFinding2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		char [] str1 = st.nextToken().trim().toCharArray();
		st = new StringTokenizer(br.readLine());
		char [] str2 = st.nextToken().trim().toCharArray();
		int index = 0;
		boolean works = false;
		int n = str1.length;
		int m = str2.length;
		for (int i = 0; i < n; i++) {
			if (str1[i] == str2[index]) {
				index ++;
			}
			else {
				index = 0;
			}
			if (index == m) {
				works = true;
				System.out.println(i-m+1);
				break;
			}
		}
		if (!works)System.out.println(-1);
	}
}

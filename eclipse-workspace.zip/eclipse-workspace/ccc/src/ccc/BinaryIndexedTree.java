package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BinaryIndexedTree {  
	 
    static int [] list;
    static int [] bit;
    static int n, m;
    public static int sum(int index){
        int sum = 0;
        index = index + 1;
        while(index>0){
            sum += bit[index];
            index -= index & (-index);
        }
        return sum;
    }
    public static void update(int n, int index, int val){
        index = index + 1;
        while(index <= n){
        	bit[index] += val;
        	index += index & (-index);
        }
    }
    public static void build(int arr[], int n){
        for(int i=1; i<=n; i++) {
        	bit[i] = 0;
        }
        for(int i = 0; i < n; i++) {
           update(n, i, arr[i]);
        }
    }
    public static int binarySearch(int arr[], int l, int r, int x){
        if (r >= l) {
            int mid = l + (r - l) / 2;
            if (arr[mid] == x)
                return mid;
            if (arr[mid] > x)
                return binarySearch(arr, l, mid - 1, x);
            return binarySearch(arr, mid + 1, r, x);
        }
        return r;
    }
    public static void main(String args[]) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int n = Integer.parseInt(st.nextToken());
        int m = Integer.parseInt(st.nextToken());
        bit = new int [n+1];
        list = new int [n+1];
        st = new StringTokenizer(br.readLine());
        for (int i = 1; i <= n; i++) {
        	list[i] = Integer.parseInt(st.nextToken());
        	update(n, i, list[i]);
        }
        for (int i = 0; i < m; i++) {
        	st = new StringTokenizer(br.readLine());
        	char temp = st.nextToken().charAt(0);
        	if (temp == 'C') {
        		int a = Integer.parseInt(st.nextToken());
        		int b = Integer.parseInt(st.nextToken());
        		update(n+1, a, b-a);
        		list[a] = b;
        	}
        	else if (temp == 'S') {
        		int a = Integer.parseInt(st.nextToken());
        		int b = Integer.parseInt(st.nextToken());
        		System.out.println(sum(b) - sum(a-1));
        	}
        	else {
        		int a = Integer.parseInt(st.nextToken());
        		System.out.println(binarySearch(list, 0, n, a));
        	}
        }
    }
}

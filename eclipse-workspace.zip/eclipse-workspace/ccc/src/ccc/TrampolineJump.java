package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class TrampolineJump {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		long [] list = new long [n+1];
		list[1] = 1;
		list[2] = 1;
		for (int i = 3; i <= n; i++) list[i] = (list[i-1] + list[i-2])%2021;
		for (int i = 1; i <= n; i++) list[i] += (i%50);
		int [] dis = new int [n+1];
		Arrays.fill(dis, Integer.MAX_VALUE);
		dis[1] = 0;
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(1);
		while (!q.isEmpty()) {
			int cur = q.poll();
			if (cur + list[cur] <= n) {
				if (dis[cur]+1 < dis[cur+(int)list[cur]]) {
					q.add(cur+(int)list[cur]);
					dis[cur+(int)list[cur]] = dis[cur]+1;
				}
			}
			if (cur < n) {
				if (dis[cur]+1 < dis[cur+1]) {
					q.add(cur+1);
					dis[cur+1] = dis[cur]+1;				
				}
			}
			if (cur-list[cur] >= 1) {
				if (dis[cur]+1 < dis[cur-(int)list[cur]]) {
					q.add(cur-(int)list[cur]);
					dis[cur-(int)list[cur]] = dis[cur]+1;
				}
			}
			if (cur >= 1) {
				if (dis[cur]+1 < dis[cur-1]) {
					q.add(cur-1);
					dis[cur-1] = dis[cur]+1;
				}
			}
		}
		System.out.println(dis[n]);
	}
}

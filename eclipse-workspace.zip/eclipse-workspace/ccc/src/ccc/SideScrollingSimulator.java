package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SideScrollingSimulator {
	static int j;
	static int w;
	static int h;
	static char [][] arr = new char [1000][1000];
	static int start;
	static int end;
	static boolean forwards(int height) {
		start += 2;
		for (int i = height; i <= h-2; i++) {
			if (arr[i][start] == '@') {
				System.out.println(start);
				return false;
			}
		}
		return true;
	}
	static boolean jump() {
		int height = h-2;
		for (int i = 1; i <= j; i++) {
			height--;
			if (height < 0 ) {
				System.out.println(start+2);
				return false;
			}
			if (arr[height][start] == '@') {
				System.out.println(start+2);
				return false;
			}
			if (arr[height][start+1] == '.' && arr[height][start+2] == '.')  {
				return forwards(height);
			}
		}
		System.out.println(start+2);
		return false;
	}
	static boolean works2() {
		while (start < end) {
			if (arr[h-2][start+1] == 'G') return true;
			if (arr[h-2][start+1] == '.') {
				start ++;
			}
			else {
				if (!jump()) return false;
			}
		}
		return true;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
			st = new StringTokenizer(br.readLine());
			j = Integer.parseInt(st.nextToken());
			w = Integer.parseInt(st.nextToken());
			h = Integer.parseInt(st.nextToken());
			for (int i = 0; i < h; i++) {
				st = new StringTokenizer(br.readLine());
				arr[i] = st.nextToken().trim().toCharArray();
				
			}
			
			for (int i = 0; i < w; i++) {
				if (arr[h-2][i] == 'L') {
					start = i;
				}
				if (arr[h-2][i] == 'G') {
					end = i;
				}
			}
			if (works2()) System.out.println("CLEAR");
		
	}

}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DashersDigits {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		char [] list = st.nextToken().trim().toCharArray();
		st = new StringTokenizer(br.readLine());
		char [] values = new char [m];
		for (int i = 0; i < m; i++) values[i] = st.nextToken().charAt(0);
		int count = 0;
		int index = 0;
		while (count < m) {
			if (list[index] == '0') {
				list[index] = values[count];
				count ++;
			}
			index ++;
		}
		char max = '0';
		int ind = 0;
		for (int i = 0; i < list.length; i++) {
			if (list[i] >= max && list[i] <= '9'+1) {
				ind = i;
				max = list[i];
			}
		}
		for (int i = ind+1; i < list.length; i++) {
			if ('A' <= list[i] && list[i] <= 'Z') {
				System.out.print(list[i]);
			}
		}
		for (int i = 0; i < ind; i++) {
			if ('A' <= list[i] && list[i] <= 'Z') {
				System.out.print(list[i]);
			}
		}
		System.out.println();
	}
}

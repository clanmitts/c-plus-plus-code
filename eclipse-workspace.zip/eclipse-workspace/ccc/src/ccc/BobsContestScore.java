package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;

public class BobsContestScore {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		boolean [] set = new boolean [1000000];
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(0);
		a.add(list[1]);
		set[list[1]] = true;
		for (int i = 2; i <= n; i++) {
			int temp = a.size();
			for (int j = 0; j < temp; j++) {
				if (!set[a.get(j) + list[i]]) {
					set[a.get(j) + list[i]] = true;
					a.add(a.get(j) + list[i]);
				}
			}
		}
		System.out.println(a.size());
	}
}

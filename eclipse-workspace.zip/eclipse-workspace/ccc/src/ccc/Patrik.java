package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Patrik {
	static int n;
	static Integer [][] list;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new Integer [n+1][2];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[n-i+1][0] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= n; i++) {
			list[i][1] = i;
		}
		long [] ans = new long [n+1];
		int sum = 0;
		Stack<Integer []> s = new Stack<Integer []>();
		s.push(list[n]);
		for (int i = n-1; i >= 1; i--) {
			while (!s.isEmpty() && s.peek()[0] <= list[i][0]) {
				s.pop();
			}
			if (!s.isEmpty()) sum += s.peek()[1]-list[i][1];
			else ans[i] = n-list[i][1];
			s.push(list[i]);
		}
		System.out.println(sum);
	}
}

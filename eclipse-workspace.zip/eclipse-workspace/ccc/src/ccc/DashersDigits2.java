package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DashersDigits2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		String str = st.nextToken().trim();
		int [] list = new int [n+1];
		for (int i = 1; i <= n; i++) list[i] = (int)(str.charAt(i-1))-'Z';
		int [] value = new int [m+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= m; i++) value[i] = Integer.parseInt(st.nextToken());
		int index = 1;
		int count = 1;
		while (count <= m) {
			if (list[index] == '0'-'Z') {
				list[index] = value[count];
				count ++;
			}
			index ++;
		}
		int max = 1;
		int ind = 1;
		for (int i = 0; i < list.length; i++) {
			if (list[i] >= max) {
				ind = i;
				max = list[i];
			}
		}
		for (int i = ind+1; i < list.length; i++) {
			if (list[i] <= 0) {
				System.out.print((char)(list[i]+'Z'));
			}
		}
		for (int i = 1; i < ind; i++) {
			if (list[i] <= 0) {
				System.out.print((char)(list[i]+'Z'));
			}
		}
		System.out.println();
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ScramblingSwaps2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		int [] index = new int [n+1];
		int [] number = new int [n+1];
		for (int i = 1; i <= n; i++) {
			index[i] = i;
			number[i] = i;
		}
		for (int i = 1; i <= q; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().trim().charAt(0);
			if (a == 'B') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				int temp = number[b];
				number[b] = number[c];
				number[c] = temp;
				index[number[b]] = b;
				index[number[c]] = c;
			}
			else if (a == 'E') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				int temp = number[index[b]];
				number[index[b]] = number[index[c]];
				number[index[c]] = temp;
				temp = index[b];
				index[b] = index[c];
				index[c] = temp;
			}
			else if (a == 'Q') {
				int [] temp = new int [n+1];
				for (int j = 1; j <= n; j++) temp[j] = Integer.parseInt(st.nextToken());
				for (int j = 1; j < n; j++) System.out.print(temp[number[j]] + " ");
				System.out.print(temp[number[n]]);
				System.out.println();
			}
		}
	}
}

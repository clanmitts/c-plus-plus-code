package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsAverage {
	public static int count (int [] list, int sum) {
		int [] array = new int [sum +1];
		array[0] = 1;
		for (int cur: list) {
			for (int num = sum-cur+100; num >= 100; num--) {
				if (array[num] != 0) {
					array[num + cur] += array[num];
				}
			}
		}
		return array[sum];
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int x = Integer.parseInt(st.nextToken());
		int [] list = new int [n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) list[i] = x-Integer.parseInt(st.nextToken());
		System.out.println(count(list, 0));
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class PowerPlan {
	public static void main(String[] args ) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		cost [] price = new cost [n+1];
		int [][] connection = new int [n+1][n+1];
		for (int i = 0; i <= n; i++) price[i] = new cost(0, 0);
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			price[i].p = Integer.parseInt(st.nextToken());
			price[i].ind = i;
		}
		price[0].p = 0;
		price[0].ind = 0;
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= n; j++) {
				connection[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		for (int i = 1; i <= n; i++) {
			connection[i][i] = Integer.MAX_VALUE;
		}
		int [] min = new int [n+1];
		for (int i = 1; i <= n; i++) {
			min[i] = price[i].p;
		}
		Arrays.sort(price);
		boolean [] vis = new boolean [n+1];
		boolean [] plant = new boolean [n+1];
		for (int i = 1; i <= n; i++) {
			for (boolean j: vis) System.out.print(j);
			System.out.println();
			if (!vis[price[i].ind]) {
				boolean [] tempvis = new boolean [n+1];
				vis[price[i].ind] = true;
				plant[price[i].ind] = true;
				Queue<Integer> q = new LinkedList<Integer>();
				q.add(price[i].ind);
				while (!q.isEmpty()) {
					int cur = q.poll();
					for (int j = 1; j <= n; j++) {
						if (connection[cur][j] < min[j] && j != i && !plant[j]) {
							tempvis[j] = true;
							vis[j] = true;
							min[j] = connection[cur][j];
							q.add(j);
						}
					}
				}
			}
		}
		int total = 0;
		for (int i = 1; i <= n; i++) {
			total += min[i];
		}
		System.out.println(total);
	}
	public static class cost implements Comparable<cost> {
		int p;
		int ind;
		public cost (int a, int b) {
			p = a;
			ind = b;
		}
		public int getP() {
			return p;
		}
		public int getInd() {
			return ind;
		}
		public int compareTo(cost o) {
			if (Integer.compare(p, o.p) == 0) {
                return Long.compare(ind, o.ind);
            } else {
                return Integer.compare(p, o.p);
            }
        }
		
	}
}

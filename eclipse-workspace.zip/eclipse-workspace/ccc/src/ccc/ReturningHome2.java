package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ReturningHome2 {
	static int n, m, s;
	static int [][][] list;
	static boolean [][][] notWork;
	static char [][]  words;
	public static int find(int a, int l, int r) {
		if (list[a][l][r] != 0) return list[a][l][r];
		else  {
			if (find(a, l+1, r-1) == 2 && words[a][l-1] == words[a][r-1]) {
				list[a][l][r] = 2;
			}
			else list[a][l][r] = 1;
			return list[a][l][r];
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		s = Integer.parseInt(st.nextToken());
		list = new int [n+1][s+2][s+1];
		notWork = new boolean [n+1][s+1][s+1];
		words = new char[n+1][s];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			words[i] = st.nextToken().trim().toCharArray();
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= s; j++) list[i][j][j] = 2;
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < s; j++) {
				if (words[i][j-1] == words[i][j]) list[i][j][j+1] = 2;
				else {
					list[i][j][j+1] = 1;
					notWork[i][j][j+1] = true;
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= s-2; j++) {
				for (int k = j+2; k <= s; k++) {
					if (find(i, j+1, k-1) == 1 || words[i][j-1] != words[i][k-1]) {
						notWork[i][j][k] = true;
					}
				}
			}
		}
		int count = 0;
		ArrayList<Integer []> check = new ArrayList<Integer []>();
		boolean [][] exists = new boolean [s+1][s+1];
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			Integer [] temp = new Integer [2];
			temp[0] = Integer.parseInt(st.nextToken());
			temp[1] = Integer.parseInt(st.nextToken());
			if (!exists[temp[0]][temp[1]]) {
				check.add(temp);
				exists[temp[0]][temp[1]] = true;
			}
		}
		boolean works = true;
		for (int i = 1; i <= n; i++) {
			works = true;
			for (int j = 0; j < check.size(); j++) {
				if (notWork[i][check.get(j)[0]][check.get(j)[1]]) {
					works = false; 
					break;
				}
			}
			if (works) count ++;
		}
		System.out.println(count);
	}
}

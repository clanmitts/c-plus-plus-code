package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class PermutationsPrimes3 {
	static ArrayList<Integer> prime;
	public static int binarySearch(int n) {
		int l = 1;
		int r =  prime.size()-1;
		while (l <= r) {
			int mid = (l+r)/2;
			if (prime.get(mid) == n) return mid;
			else if (prime.get(mid) < n) l = mid+1;
			else r = mid-1;
		}
		return r;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		boolean [] isprime = new boolean [100001];
		Arrays.fill(isprime, true);
		for (int i = 2; i <= 100000; i++) {
			if (isprime[i]) {
				for (int j = i+i; j <= 100000; j+= i) {
					isprime[j] = false;
				}
			}
		}
		isprime[1] = false;
		isprime[2] = true;
		prime = new ArrayList<Integer>();
		prime.add(0);
		for (int i = 1; i <= 100000; i++) {
			if (isprime[i]) prime.add(i);
		}
		int t = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= t; i++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			if (n <= 2) System.out.println(-1);
			else {
				int max = prime.get(binarySearch(n-1));
				System.out.print(1);
				for (int j = 2; j <= max; j++) {
					System.out.print(" " + j);
				}
				System.out.print(" " + n);
				for (int j = max+1; j < n; j++) {
					System.out.print(" " + j);
				}
				System.out.println();
			}
		}
	}
}

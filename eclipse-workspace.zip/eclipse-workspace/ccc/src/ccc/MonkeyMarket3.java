package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class MonkeyMarket3 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st= new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		Integer [] list = new Integer [n+1];
		st= new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		list[0] = 0;
		Arrays.sort(list);
		if (n%2 == 0) {
			for (int i = 1; i <= n/2; i++) {
				System.out.print(list[i]);
				System.out.print(" ");
				System.out.print(list[n-i+1]);
				if (i != n/2) System.out.print(" ");
			}
			System.out.println();
			for (int i = 1; i <= n; i++) {
				if (i %2 == 0) System.out.print("S");
				else if (i%2 == 1) System.out.print("B");
			}
			System.out.println();
		}
		else {
			System.out.print(list[n/2+1]);
			System.out.print(" ");
			for (int i = 1; i <= n/2; i++) {
				System.out.print(list[i]);
				System.out.print(" ");
				System.out.print(list[n-i+1]);
				if (i != n/2) System.out.print(" ");
			}
			System.out.println();
			System.out.print("E");
			for (int i = 2; i <= n; i++) {
				if (i % 2 == 0) System.out.print("B");
				else if (i%2 == 1) System.out.print("S");
			}
			System.out.println();
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.StringTokenizer;

public class DiverseArrays {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
		}
		HashMap<Integer, Integer> m = new HashMap<Integer, Integer>();
		long sum = (long)(n)*((long)(n)+1)/2;
		int index = 1;
		for (int i = 1; i <= n; i++) {
			if (m.containsKey(list[i])) m.put(list[i], m.get(list[i])+1);
			else m.put(list[i], 1);
			while (m.size() >= k) {
				if (m.get(list[index]) == 1) m.remove(list[index]);
				else {
					m.put(list[index], m.get(list[index])-1);
				}
				index ++;
			}
			sum -= (i-index+1);
		}
		System.out.println(sum);
	}
}

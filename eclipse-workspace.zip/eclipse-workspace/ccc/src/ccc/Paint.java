package ccc;

import java.util.*;


class Interval implements Comparable<Interval>  {
public long left;
public long right;
public Interval(long l, long r) {
 this.left = l;
 this.right = r;
}

public int compareTo(Interval that) {
 return Long.compare(this.right, that.right);
}

public long size() {
 return right - left + 1;
}
}


public class Paint {
public static void main(String[] args) {
 Scanner in = new Scanner(System.in);
 long n = in.nextLong();
 long k = in.nextLong();

 Interval[] intervals = new Interval[(int) k];
 for (int i = 0; i < k; i++) {
   intervals[i] = new Interval(in.nextLong(), in.nextLong());
 }

 Arrays.sort(intervals);

 long best = Integer.MIN_VALUE;

 TreeMap<Long, Long> dp = new TreeMap<>();
 for (Interval I : intervals) {
   Long left = dp.lowerKey(I.left);
   long leftValue = (left == null) ? 0 : dp.get(left);
   
   best = Math.max(best, leftValue + I.size());
   dp.put(I.right, best);
 }
 
 System.out.println(n-best);
}
}
package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class GrassPlanting3 {
	static int n;
	static ArrayList<Integer>[] list;
	static Queue<Integer> q = new LinkedList<Integer>();
	static int [] dis;
	static boolean vis[];
	public static void thing(int x) {
		for (int i: list[x]) {
			if (!vis[i]) {
				vis[i] = true;
				order.add(i);
				thing(i);
				order.add(x);
			}
		}
		return;
	}
	static ArrayList<Integer> order = new ArrayList<Integer>();
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new ArrayList[n+1];
		dis = new int [n+1];
		vis = new boolean [n+1];
		order.add(1);
		vis[1] = true;
		for (int i = 1; i <= n; i++) list[i] = new ArrayList<Integer>();
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			list[a].add(b);
			list[b].add(a);
		}
		int [] grass = new int [n+1];
		thing(1);
		Arrays.fill(vis, false);
		if (n == 1) System.out.println(1);
		else if (n == 2) System.out.println(2);
		else {
			grass[1] = 1;
			grass[order.get(1)] = 2;
			vis[1] = true;
			vis[order.get(1)] = true;
			for (int i = 2; i < order.size(); i++) {
				for (int j = 1; j <= 100000; j++) {
					if (!vis[order.get(i)]) {
						if (grass[order.get(i-1)] != j && grass[order.get(i-2)] != j) {
							grass[order.get(i)] = j;
							vis[order.get(i)] = true;
							break;
						}
					}
				}
			}
			int max = 0;
			for (int i: grass) max = Math.max(max, i);
			System.out.println(max);
		}
		for (int i: grass) System.out.println(i);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;

public class Gitara {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int p = Integer.parseInt(st.nextToken());
		Stack<Integer>[] list = new Stack[7];
		for (int i = 1; i <= 6; i++) list[i] = new Stack<Integer>();
		int count = 0;
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			while (!list[a].isEmpty() && list[a].peek() > b) {
				count ++;
				list[a].pop();
			}
			if (!list[a].isEmpty() && list[a].peek() == b);
			else {
				count ++;
				list[a].push(b);
			}
		}
		System.out.println(count);
	}
}

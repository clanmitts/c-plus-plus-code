package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class MonkeyMarket {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		Integer [] list = new Integer [n+1];
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		list[0] = 0;
		Arrays.sort(list);
		int [] a = new int [n+1];
		for (int i = 1; i <= n; i+=2) {
			a[i] = list[i/2+1];
		}
		for (int i = 2; i <= n; i+=2) {
			a[i] = list[(n/2)+(i/2)+1];
		}
	}
}

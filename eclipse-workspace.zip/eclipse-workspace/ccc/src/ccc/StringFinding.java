package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class StringFinding {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		String a = st.nextToken().trim();
		st = new StringTokenizer(br.readLine());
		String b = st.nextToken().trim();
		int [] kmp = new int [a.length()];
		for (int i = 1; i < b.length(); i++) {
			int j = kmp[i-1];
			while (j > 0 && a.charAt(j) != a.charAt(i)) {
				j = kmp[j-1];
			}
			if (a.charAt(i) == a.charAt(j) ) {
				j++;
			}
			kmp[i] = j;
		}
		for (int i: kmp) System.out.println(i);
	}
}

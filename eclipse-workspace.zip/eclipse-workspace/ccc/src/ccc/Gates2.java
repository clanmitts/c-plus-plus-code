package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Gates2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int g = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int p = Integer.parseInt(st.nextToken());
		int [] planes = new int [g+1];
		int total = 0;
		int i = 0;
		boolean thing = true;
		while (i < p && thing) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			while (n > 0 && planes[n] > 0) {
				int t = planes[n];
				planes[n] ++;
				n -= t;
			}
			if (n <= 0) thing = false;
			else {
				planes[n] = 1;
				total ++;
				i++;
			}
		}

		System.out.println(total);
	}
}

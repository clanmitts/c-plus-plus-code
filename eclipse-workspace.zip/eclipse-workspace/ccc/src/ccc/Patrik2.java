package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Patrik2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		long [] list = new long [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Long.parseLong(st.nextToken());
		}
		long sum = 0;
		long [][] s = new long [n+1][2];
		int pointer = 0;
		for (int i = 1; i <= n; i++) {
			while (s[pointer][0] < list[i] && pointer != 0) {
				sum += s[pointer][1];
				pointer --;
			}
			if (pointer == 0) {
				pointer ++;
				s[pointer][0] = list[i];
				s[pointer][1] = 1;
			}
			else if (s[pointer][0] > list[i]) {
				sum ++;
				pointer ++;
				s[pointer][0] = list[i];
				s[pointer][1] = 1;
			}
			else if (s[pointer][0] == list[i]) {
				sum += s[pointer][1];
				s[pointer][1] ++;
				if (pointer != 1) sum ++;
			}
		}
		System.out.println(sum);
	}
}

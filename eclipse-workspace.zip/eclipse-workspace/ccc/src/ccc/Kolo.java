package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Kolo {
	static int n, k;
	static char [] spinner;
	static int [] places;
	static char [] letter;
	static boolean [] used;
	static boolean works;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		works = true;
		spinner= new char [n+1];
		Arrays.fill(spinner, '?');
		places = new int [k+2];
		letter = new char [k+1];
		used = new boolean [26];
		for (int i = k; i >= 1; i--) {
			st = new StringTokenizer(br.readLine());
			places[i+1] = Integer.parseInt(st.nextToken());
			letter[i] = st.nextToken().charAt(0);
		}
		spinner[1] = letter[1];
		used[letter[1]-65] = true;
		int index = 1;
		for (int i = 2; i <= k; i++) {
			for (int j = 0; j < places[i]; j++) {
				index ++;
				if (index > n) index = 1;
			}
			if (spinner[index] == letter[i]);
			else if (spinner[index] == '?' && !used[letter[i]-65]) {
				used[letter[i]-65] = true;
				spinner[index] = letter[i];
			}
			else {
				works = false;
				break;
			}
		}
		if (works) {
			for (int i = 1; i <= n; i++) {
				System.out.print(spinner[i]);
			}
			System.out.println();
		}
		else System.out.println('!');
	}
}

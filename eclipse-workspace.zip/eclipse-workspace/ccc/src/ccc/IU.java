package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class IU {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		char [] list = st.nextToken().trim().toCharArray();
		int u = 0;
		int i = 0;
		int index = 0;
		char letter = 'I';
		int count = 0;
		int ucount = 0;
		int icount = 0;
		for (char j: list) {
			if (j == 'I') icount++;
			else ucount++;
		}
		if (ucount == icount) {
			while (index < list.length) {
				if (letter == 'I') {
					if (list[index] == letter) {
						letter = 'U';
						index++;
					}
					else {
						if (u > 0) {
							u--;
							index++;
						}
						else {
							i++;
							count ++;
							letter = 'U';
						}
					}
				}
				else {
					if (list[index] == letter) {
						letter = 'I';
						index++;
					}
					else {
						if (i > 0) {
							i--;
							index++;
						}
						else {
							u++;
							count ++;
							letter = 'I';
						}
					}
				}
			}
			System.out.println(count);
		}
		else System.out.println(-1);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class LazySort {
	static int n;
	static Deque<Integer> aa;
	static Deque<Integer> ba;
	static Deque<Integer> ab;
	static Deque<Integer> bb;
	public static boolean worksa() {
		ba.addFirst(aa.getFirst());
		aa.removeFirst();
		while (!aa.isEmpty()) {
			if (aa.getFirst() == ba.getFirst()-1) {
				ba.addFirst(aa.getFirst());
				aa.removeFirst();
			}
			else if (aa.getFirst() == ba.getLast()+1) {
				ba.addLast(aa.getFirst());
				aa.removeFirst();
			}
			else if (aa.getLast() == ba.getFirst()-1) {
				ba.addFirst(aa.getLast());
				aa.removeLast();
			}
			else if (aa.getLast() == ba.getLast()+1) {
				ba.addLast(aa.getLast());
				aa.removeLast();
			}
			else {
				return false;
			}
		}
		return true;
	}
	public static boolean worksb() {
		bb.addFirst(ab.getLast());
		ab.removeLast();
		while (!ab.isEmpty()) {
			if (ab.getFirst() == bb.getFirst()-1) {
				bb.addFirst(ab.getFirst());
				ab.removeFirst();
			}
			else if (ab.getFirst() == bb.getLast()+1) {
				bb.addLast(ab.getFirst());
				ab.removeFirst();
			}
			else if (ab.getLast() == bb.getFirst()-1) {
				bb.addFirst(ab.getLast());
				ab.removeLast();
			}
			else if (ab.getLast() == bb.getLast()+1) {
				bb.addLast(ab.getLast());
				ab.removeLast();
			}
			else {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int q = 1; q <= t; q++) {
			st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			st = new StringTokenizer(br.readLine());
			aa = new LinkedList<Integer>();
			ba = new LinkedList<Integer>();
			ab = new LinkedList<Integer>();
			bb = new LinkedList<Integer>();
			int [] list = new int [n];
			for (int i = 0; i < n; i++) {
				list[i] = Integer.parseInt(st.nextToken());
			}
			for (int i = 0; i < n; i++) {
				aa.addFirst(list[i]);
				ab.addFirst(list[i]);
			}
			if (worksa()) {
				System.out.println("Case #" + q + ": yes");
			}
			else if (worksb()) {
				System.out.println("Case #" + q + ": yes");
			}
			else System.out.println("Case #" + q + ": no");
		}
	}
}

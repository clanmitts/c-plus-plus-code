package ccc;

public class StrategyMeeting {

}

package ccc;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SearchingforSoulmates3 {
	public static long function(long a, long b) {
		if (a == b) return 0;
		if (a > b) {
			if (a%2 == 1) return 2+function((a+1)/2, b);
			else return 1+function((a+1)/2, b);
		}
		else {
			return Math.min(b-a, function(a, b/2)+1+(b%2));
		}	
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			long a = Long.parseLong(st.nextToken());
			long b = Long.parseLong(st.nextToken());
			System.out.println(function(a, b));
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ASubarrayProblem {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		int l = 1; 
		int r = n;
		int max = n;
		int count = 0;
		while (l <= r) {
			if (r-l+1 == max) count ++;
			if (list[l] > list[r]) {
				max = Math.min(list[l]-1, max);
				l++;
			}
			else {
				max = Math.min(list[r]-1, max);
				r--;
			}
		}
		System.out.println(count);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Sound2 {
	static StringTokenizer st;
	static BufferedReader br;
	static int readInt() throws IOException{
	    int x = 0, c;
	    while((c = br.read()) != ' ' && c != '\n')
	        x = x * 10 + (c - '0');
	    return x;
	}

	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		int n = readInt();
		int m = readInt();
		int c = readInt();
		Deque<Integer []> max = new LinkedList<Integer []>();
		Deque<Integer []> min = new LinkedList<Integer []>();
		int [] list = new int [n+1];
		ArrayList<Integer> works = new ArrayList<Integer>();
		for (int i = 1; i <= n; i++) {
			list[i] = readInt();
		}
		Integer [] temp = new Integer[2];
		for (int i = 1; i <= m; i++) {
			Integer maxtemp[] = new Integer[2];
			Integer mintemp[] = new Integer[2];
			while (!max.isEmpty() && list[i] >= max.getFirst()[0]) {
				max.removeFirst();
			}
			maxtemp[0] = list[i];
			maxtemp[1] = i;
			max.addFirst(maxtemp);
			while (!min.isEmpty() && list[i] <= min.getFirst()[0]) {
				min.removeFirst();
			}
			mintemp[0] = list[i];
			mintemp[1] = i;
			min.addFirst(mintemp);
		}
		if (max.getLast()[0] - min.getLast()[0] <= c) works.add(1);
		int index = 1;
		for (int i = m+1; i <= n; i++) {
			index++;
			if (min.getLast()[1] < index) min.removeLast();
			if (max.getLast()[1] < index) max.removeLast();
			Integer maxtemp[] = new Integer[2];
			Integer mintemp[] = new Integer[2];
			while (!max.isEmpty() && list[i] >= max.getFirst()[0]) {
				max.removeFirst();
			}
			maxtemp[0] = list[i];
			maxtemp[1] = i;
			max.addFirst(maxtemp);
			while (!min.isEmpty() && list[i] <= min.getFirst()[0]) {
				min.removeFirst();
			}
			mintemp[0] = list[i];
			mintemp[1] = i;
			min.addFirst(mintemp);
			if (max.getLast()[0] - min.getLast()[0] <= c) works.add(index);
		}
		if (works.size() > 0) for (int i: works) System.out.println(i);
		else System.out.println("NONE");
	}
}

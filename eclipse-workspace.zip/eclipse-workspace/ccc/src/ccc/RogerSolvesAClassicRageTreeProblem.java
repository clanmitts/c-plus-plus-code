package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class RogerSolvesAClassicRageTreeProblem {
	static public int [][] minsparse;
	static public int [][] maxsparse;
	static public int [] list;
	static int n;
	public static double log2(int N){
		return (Math.log(N) / Math.log(2));
	    }
	public static void mincreate() {
		for(int i = 1; i <= log2(n); i++){
			for(int j = 0; j + (1<<i) <= n; j++){
				minsparse[ i ][ j ] = Math.min( minsparse[ i - 1 ][ j ] , minsparse[ i - 1 ][ j + (1<<( i - 1 )) ] );
			}
		}
	}
	public static void maxcreate() {
		for(int i = 1; i <= log2(n); i++){
			for(int j = 0; j + (1<<i) <= n; j++){
				maxsparse[ i ][ j ] = Math.max( maxsparse[ i - 1 ][ j ] , maxsparse[ i - 1 ][ j + (1<<( i - 1 )) ] );
			}
		}
	}
	public static int minquery(int l, int r){
		int k=(int)log2(r-l+1);
		return Math.min(minsparse[k][l],minsparse[k][r-(1<<k)+1]);
	}
	public static int maxquery(int l, int r){
		int k=(int)log2(r-l+1);
		return Math.max(maxsparse[k][l],maxsparse[k][r-(1<<k)+1]);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		minsparse = new int [n+1][n+1];
		maxsparse = new int [n+1][n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= n; i++) {
			minsparse[0][i] = list[i];
			maxsparse[0][i] = list[i];
		}
		mincreate();
		maxcreate();
		for (int i = 0; i < q; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			System.out.println(maxquery(a, b) - minquery(a, b));
		}
	}
}

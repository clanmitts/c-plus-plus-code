package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;

public class Kas {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
		}
		int [] sum = new int [100001];
		ArrayList<Integer> num = new ArrayList<Integer>();
		num.add(0);
		boolean [] contains = new boolean [100001];
		for (int i = 1; i <= n; i++) {
			
		}
	}
}

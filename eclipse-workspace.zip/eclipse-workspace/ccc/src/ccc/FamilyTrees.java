package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FamilyTrees {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		for (int a = 0; a < 10; a++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			char [][] list = new char[n][20+1];
			for (int i = 0; i < n; i++) {
				st = new StringTokenizer(br.readLine());
				list[i] = st.nextToken().trim().toCharArray();
				
			}
		}
	}
}

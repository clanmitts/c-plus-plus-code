package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class CastleInvasion {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] column = new int [n+1];
		int [] row = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) column[i] = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) row[i] = Integer.parseInt(st.nextToken());
		int [] freq = new int [(int) (1e6 + 2)];
		Arrays.fill(freq, n);
		long [] psa = new long[(int) (1e6 + 2)];
		for (int i = 1; i <= n; i++) psa[column[i]] ++;
		for (int i = 1; i <= 1e6; i++) psa[i] += psa[i-1];
		for (int i = 1; i <= 1e6; i++) freq[i] -= psa[i-1];
		for (int i = 1; i <= 1e6; i++) psa[i] = 0;
		for (int i = 1; i <= n; i++) psa[column[i]] ++;
		for (int i = 1; i <= 1e6; i++) psa[i] *= i;
		for (int i = 1; i <= 1e6; i++) psa[i] += psa[i-1];
		long count = 0;
		for (int i = 1; i <= n; i++) count += (long)(freq[row[i]])*(long)(row[i]);
		for (int i = 1; i <= n; i++) count += psa[row[i]-1];
		int maxc = 0;
		int maxr = 0;
		for (int i = 1; i <= n; i++) if (column[i] > maxc) maxc = column[i];
		for (int i = 1; i <= n; i++) if (row[i] > maxr) maxr = row[i];
		if (maxc == maxr) System.out.println(count);
		else System.out.println(-1);
	}
}

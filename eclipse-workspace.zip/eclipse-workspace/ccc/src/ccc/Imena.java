package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Imena {
	public static boolean isName(String str) {
		if (str.charAt(0) >= 'A' && str.charAt(0) <= 'Z') {
			for (int i = 1; i < str.length(); i++) {
				if ((str.charAt(i) >= '0' && str.charAt(i) <= '9')
					|| str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') return false;
			}
			return true;
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.parseInt(sc.nextLine());
		int [] count = new int [n+1];
		String temp = sc.nextLine().trim();
		String [] list = temp.split(" ");
		int index = 1;
		for (String i: list) {
			if (i.charAt(i.length()-1) == '.' || i.charAt(i.length()-1) == '?' 
					|| i.charAt(i.length()-1) == '!') {
				if (isName(i)) count[index]++;
				index ++;
			}
			else {
				if (isName(i)) count[index] ++;
			}
		}
		for (int i = 1; i <= n; i++) {
			System.out.println(count[i]);
		}
	}
}

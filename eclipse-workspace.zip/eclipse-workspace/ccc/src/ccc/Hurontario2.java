package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Hurontario2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		String a = st.nextToken().trim();
		String b = st.nextToken().trim();
		int n = a.length();
		int m = b.length();
		for (int i = Math.min(n, m); i >= 0; i--) {
			if (a.substring(n-i, n).equals(b.substring(0, i))) {
				System.out.println(a.substring(0, n-i) + a.substring(n-i, n)
				+ b.substring(i, m));
				break;
			}
		}
	}
}

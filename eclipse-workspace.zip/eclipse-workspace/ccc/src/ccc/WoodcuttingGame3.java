package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class WoodcuttingGame3 {
	static int [][][][]dp = new int [3][301][3][301];
	static int f (int h1, int w1, int h2, int w2) {
		if(dp[h1][w1][h2][w2]!=0) return(dp[h1][w1][h2][w2]);
		if(h1==1 && w1==1 && h2==1 && w2==1) return dp[1][1][1][1]=-1;
		for(int i = 1; h1-i > 0; i++)
			if(f(i, w1, h1-i, w1)==-1) return dp[h1][w1][h2][w2] = 1;
		for(int i = 1; w1-i > 0; i++)
			if(f(h1, i, h1, w1-i)==-1) return dp[h1][w1][h2][w2] = 1; 
		for(int i = 1; h2-i > 0; i++)
			if(f(i, w2, h2-i, w2)==-1) return dp[h1][w1][h2][w2] = 1;
		for(int i = 1; w2-i > 0; i++)
			if(f(h2, i, h2, w2-i)==-1) return dp[h1][w1][h2][w2] = 1;
		if(h1==2) if(f(1, w1, h2, w2)==-1) return dp[h1][w1][h2][w2] = 1;
		if(h2==2) if(f(h1, w1, 1, w2)==-1) return dp[h1][w1][h2][w2] = 1;
		for(int k = 1; k <= 10 && w1-k >= 1; k++)
			if(f(h1, w1-k, h2, w2)==-1) return dp[h1][w1][h2][w2] = 1;
		for(int k = 1; k <= 10 && w2-k >= 1; k++)
			if(f(h1, w1, h2, w2-k)==-1) return dp[h1][w1][h2][w2] = 1;
		return dp[h1][w1][h2][w2] = -1;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int h1 = Integer.parseInt(st.nextToken());
		int w1 = Integer.parseInt(st.nextToken());
		int h2 = Integer.parseInt(st.nextToken());
		int w2 = Integer.parseInt(st.nextToken());
		if(f(h1,w1,h2,w2)==1)System.out.println("W");
		else System.out.println("L");
	}
}

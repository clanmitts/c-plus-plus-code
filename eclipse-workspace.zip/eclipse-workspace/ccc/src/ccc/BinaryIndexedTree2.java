package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BinaryIndexedTree2 {
	static int [] list, bit;
	static int n, m;
	public static void update(int index, int val) {
		while (index <= n+1) {
			bit[index] += val;
			index += (index & -index);
		}
	}
	public static int freqTo(int index) {
		int sum = 0;
		while (index > 0) {
			sum += bit[index];
			index -= (index & -index);
		}
		return sum;
	}
	public static int binarySearch(Integer [] arr, int l, int r, int x){
		if (r >= l) {
			int mid = l + (r - l) / 2;
			if (arr[mid] == x)
				return mid;
			if (arr[mid] > x)
				return binarySearch(arr, l, mid - 1, x);
			return binarySearch(arr, mid + 1, r, x);
	        }
	        return r;
	    }
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		bit = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
			update(i, list[i]);
		}
		for (int i: bit) System.out.print(i + " ");
		System.out.println();
		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().charAt(0);
			if (a == 'C') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				update(b, c-list[b]);
				list[b] = c;

			}
			else if (a == 'S') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				System.out.println(freqTo(c) - freqTo(b-1));
			}
			else {
				Integer [] temp = new Integer [n+1];
				temp[0] = 0;
				for (int j = 1; j <= n; j++) temp[j] = list[j];
				Arrays.sort(temp);
				for (int j: temp) System.out.print(j + " ");
				System.out.println();
				int b = Integer.parseInt(st.nextToken());
				System.out.println(binarySearch(temp, 0, n, b));
			}
		}
	}
}

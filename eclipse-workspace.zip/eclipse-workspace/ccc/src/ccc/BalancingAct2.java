package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BalancingAct2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		for (int i = 0; i < 5; i++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			boolean [] possible = new boolean [30*1000+1];
			Arrays.fill(possible, false);
			possible[0] = true;
			int total = 0;
			for (int j = 0; j < n; j++) {
				st = new StringTokenizer(br.readLine());
				int weight = Integer.parseInt(st.nextToken());
				total = total + weight;
				for (int k = possible.length-1; k >= 0; k--) {
					if (possible[k]) {
						possible[k+weight] = true;
					}
				}
			}
			for (int j = total/2; j >= 0; j--) {
				if (possible[j]) {
					System.out.println(total - j * 2);
					break;
				}
			}
		}
	}
}

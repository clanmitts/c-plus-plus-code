package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Hurontario3 {
	public static long firstHash[];
	public static long lastHash[];
	public static long firstPower[];
	public static long lastPower[];
	public static long firstInv[];
	public static long lastInv[];
	public static char [] a;
	public static char [] b;
	public static String x;
	public static String y;
	public static long fp (long x, long power) {
		long ans = 1;
		for (long i = 1; i <= power; i*= 2) {
			if ((power&i) > 0) ans = (long) (ans*x % (long)(1e9+7));
			x = x*x % (long)(1e9+7);
		}
		return ans;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		x = st.nextToken().trim();
		y = st.nextToken().trim();
		a = x.toCharArray();
		b = y.toCharArray();
		firstHash = new long[a.length];
		firstPower = new long[a.length];
		firstInv = new long[a.length];
		firstHash[0] = a[0]-'a'+1;
		firstPower[0] = 1;
		firstInv[0] = 1;
		for (int i = 1; i < a.length; i++) {
			firstPower[i] = firstPower[i-1]*31 % (long)(1e9+7);
			firstHash[i] = 
					(firstHash[i-1] + (a[i]-'a'+1) 
					* firstPower[i] % (long)(1e9+7)) % (long)(1e9+7);
			firstInv[i] = fp(firstPower[i], (long)(1e9+5));
		}
		lastHash = new long[b.length];
		lastPower = new long[b.length];
		lastInv = new long[b.length];
		lastHash[0] = b[0]-'a'+1;
		lastPower[0] = 1;
		lastInv[0] = 1;
		for (int i = 1; i < b.length; i++) {
			lastPower[i] = lastPower[i-1]*31 % (long)(1e9+7);
			lastHash[i] = 
					(lastHash[i-1] + (b[i]-'a'+1) 
					* lastPower[i] % (long)(1e9+7)) % (long)(1e9+7);
			lastInv[i] = fp(lastPower[i], (long)(1e9+5));
		}
		int n = a.length;
		int m = b.length;
		int min = Math.min(n, m)-1;
		boolean works = false;
		if (min == n && min == m) {
			if ((((firstHash[n-1]+(long)(1e9+7))
					*firstInv[min] % (long)(1e9+7)) % (long)(1e9+7))==
					(lastHash[m-1] * firstInv[min] 
							% (long)(1e9+7)) % (long)(1e9+7)) {
				System.out.println(x.substring(0, n-1)
				+ y.substring(min+1, m));
				works = true;
			}
		}
		if (min == m && n > m) {
			if ((((firstHash[n-1] - firstHash[n-min-2]+(long)(1e9+7))
					*firstInv[min] % (long)(1e9+7)) % (long)(1e9+7))==
					(lastHash[min] * firstInv[min] 
							% (long)(1e9+7)) % (long)(1e9+7)) {
				System.out.println(x.substring(0, n-1)
				+ y.substring(min+1, m));
				works = true;
			}
		}
		if (min == n && n < m) {
			if ((((firstHash[n-1]+(long)(1e9+7))
					*firstInv[min] % (long)(1e9+7)) % (long)(1e9+7))==
					(lastHash[min] * firstInv[min] 
							% (long)(1e9+7)) % (long)(1e9+7)) {
				System.out.println(x.substring(0, n-1)
				+ y.substring(min+1, m));
				works = true;
			}
		}
		else {
			for (int i = min-1; i >= 0; i--) {
				System.out.println(i);
				System.out.println(a[n-i-1]);
				System.out.println(b[i]);
				System.out.println((((firstHash[n-1] - firstHash[n-i-2]+(long)(1e9+7))
						*firstInv[i] % (long)(1e9+7)) % (long)(1e9+7)));
				System.out.println((lastHash[i] * firstInv[i] 
								% (long)(1e9+7)) % (long)(1e9+7));
				if ((((firstHash[n-1] - firstHash[n-i-2]+(long)(1e9+7))
						*firstInv[i] % (long)(1e9+7)) % (long)(1e9+7))==
						(lastHash[i] * firstInv[i] 
								% (long)(1e9+7)) % (long)(1e9+7)) {
					System.out.println(x.substring(0, n-1) + x.substring(n-i, n)
					+ y.substring(i, m));
					works = true;
					break;
				}
			}
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class LargestMinimumDistance {
	static int [] list;
	static int n, m;
	public static boolean works(int a) {
		int count = 1;
		int l = 1;
		int r = 1;
		while (r <= n) {
			if (list[r]-list[l] >= a) {
				count ++;
				l = r;
				r++;
			}
			else {
				r++;
			}
		}
		return (count >= m);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(list);
		int l = 1; 
		int r = (int)1e9;
		int max = 0;
		while (l <= r) {
			int mid = l + ((r-l)/2);
			if (works(mid)) {
				max = mid;
				l = mid+1;
			}
			else {
				r = mid-1;
			}
		}
		System.out.println(max);
	}
}

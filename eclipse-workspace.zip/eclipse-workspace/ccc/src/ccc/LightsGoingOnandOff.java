package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.StringTokenizer;

public class LightsGoingOnandOff {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int r = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int l = Integer.parseInt(st.nextToken());
		String [] list = new String[r+1];
		int [] num = new int [r+1];
		for (int i = 1; i <= r; i++) list[i] = "";
		for (int i = 1; i <= r; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= l; j++) {
				list[i] += st.nextToken().trim();
			}
		}
		for (int i = 1; i <= r; i++) num[i] = Integer.parseInt(list[i], 2);
		HashSet<Integer> possible = new HashSet<Integer>();
		possible.add(num[1]);
		for (int i = 2; i <= r; i++) {
			HashSet<Integer> temp = new HashSet<Integer>();
			temp.add(num[i]);
			for (int j: possible) temp.add(j^num[i]);
			possible = new HashSet<Integer>();
			for (int j: temp) possible.add(j);
		}
		System.out.println(possible.size());
	}
}

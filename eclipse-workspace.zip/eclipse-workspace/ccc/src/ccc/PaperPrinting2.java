package ccc;

import java.util.Scanner;

public class PaperPrinting2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int [] psa = new int [2001];
		int n;
		int m;
		n = input.nextInt();
		m = input.nextInt();
		int a;
		a = input.nextInt();
		for (int i = 1; i <= a; i++) {
			int x;
			int y;
			x = input.nextInt();
			y = input.nextInt();
			psa[x] += y;
		}
		psa[0] = n;
		for (int i = 1; i <= 2000; i++) {
			psa[i] = psa[i-1] + psa[i] - 1;
		}
		for (int i = 1; i <= 2000; i++) {
			if (psa[i] == 0) {
				System.out.println("The printer melts at " + (i+1) + " second(s).");
				break;
			}
			if (psa[i] > m) {
				System.out.println("The printer jams at " + i + " second(s).");
				break;
			}
		}
	}
}

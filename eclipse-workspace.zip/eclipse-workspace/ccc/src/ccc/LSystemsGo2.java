package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class LSystemsGo2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		for (int w = 0; w < 10; w++) {
			st = new StringTokenizer(br.readLine());
			int r = Integer.parseInt(st.nextToken());
			int t = Integer.parseInt(st.nextToken());
			String before = st.nextToken().trim();
			String start = before;
			String [][] change = new String [r][2];
			for (int i = 0; i < r; i++) {
				st = new StringTokenizer(br.readLine());
				change[i][0] = st.nextToken().trim();
				change[i][1] = st.nextToken().trim();
			}
			String after = "";
			for (int i = 0; i < t; i++) {
				for (int j = 0; j < r; j++) {
					before = before.replaceAll(change[j][0], change[j][1]);
					System.out.println(before);
					after = before;
					before = start;
				}
				start = after;
				before = start;
			}
			System.out.println(after.charAt(0) + " " + after.charAt(after.length()-1) + " " 
					+ after.length());
		}
	}
}

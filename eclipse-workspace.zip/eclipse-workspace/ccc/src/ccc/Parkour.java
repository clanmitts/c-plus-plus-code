package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Parkour {
	static int x, y, h, v, t;;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int x = Integer.parseInt(st.nextToken());
		int y = Integer.parseInt(st.nextToken());
		int h = Integer.parseInt(st.nextToken());
		int v = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		int a = 0;
		int b = 0;
		int count = 0;
		while (a < x || b < y) {
			if (x-a < y-b) {
				a++;
				b+=2;
				count ++;
			}
			else {
				a+=2;
				b++;
				count ++;
			}
		}
		if (count < t && a-x <= h && b-y <= v) System.out.println("YES");
		else System.out.println("NO");
	}
}

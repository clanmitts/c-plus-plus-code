package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class OutofSorts {
	static int n;
	static int [] list;
	static int [] finish;
	public static int binarySearchLeft (int l, int r, int x) {
		int min = Integer.MAX_VALUE;
		while (l <= r) {
			int mid = (l+r)/2;
			if (finish[mid] == x) {
				min = Math.min(min, mid);
				r = mid-1;
			}
			else if (finish[mid] < x) {
				l = mid+1;
			}
			else if (finish[mid] > x) {
				r = mid-1;
			}
		}
		return min;
	}
	public static int binarySearchRight (int l, int r, int x) {
		int max = 0;
		int mid = 0;
		while (l <= r) {
			mid = (l+r)/2;
			if (finish[mid] == x) {
				max = Math.max(max, mid);
				l = mid+1;
			}
			else if (finish[mid] < x) {
				l = mid+1;
			}
			else if (finish[mid] > x) {
				r = mid-1;
			}
		}
		return max;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		finish = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
			finish[i] = list[i];
		}
		Arrays.sort(finish);
		int max = 0;
		for (int i = 1; i <= n;i ++) {
			if (binarySearchLeft(1, n, list[i]) <= i && binarySearchRight(1, n, list[i]) >= i) {
				continue;
			}
			max = Math.max(max, 
				Math.min(i - binarySearchLeft(1, n, list[i]), 
						 i - binarySearchRight(1, n, list[i])));
		}
		System.out.println(max+1);
	}
}

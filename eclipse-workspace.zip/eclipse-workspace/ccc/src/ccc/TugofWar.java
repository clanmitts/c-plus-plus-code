package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class TugofWar {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n];
		int [] prefix = new int [n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) list[i] = Integer.parseInt(st.nextToken());
		prefix[0] = list[0];
		for (int i = 1; i < n; i++) prefix[i] = list[i-1];
		int sum = 0;
        for (int i = 0; i < n; i++) sum += list[i];
        int min = Integer.MAX_VALUE;
        int index = 0;
        for (int i = 0; i < n - 1; i++) {
            int dif = Math.abs((sum - prefix[i]) - prefix[i]);
            if (dif < min) {
            	min = dif;
            	index = i;
            }
        }
	}
}

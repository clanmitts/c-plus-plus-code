package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobandCanada {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int q = 0; q < t; q++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			st = new StringTokenizer(br.readLine());
			char [] list = st.nextToken().trim().toCharArray();
			int [] w = new int[n+1];
			int [] r = new int [n+1];
			for (int i = 1; i <= n; i++) {
				if (list[i-1] == 'W') w[i] ++;
				else r[i] ++;
			}
			for (int i = 1; i <= n; i++) {
				w[i] += w[i-1];
				r[i] += r[i-1];
			}
			int[] minimum = new int [n+1];
			minimum[0] = 1000000000;
			for (int i = 1; i <= n; i++) {
				minimum[i] = Math.min(minimum[i-1], w[i]-r[i]);
			}
			int min = 1000000000;
			for (int i = 2; i < n; i++) {
				min = Math.min(w[n]-w[i]+r[i] + minimum[i-1], min);
			}
			System.out.println(min);
		}
	}
}

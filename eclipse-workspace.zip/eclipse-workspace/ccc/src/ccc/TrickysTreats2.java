package ccc;
import java.io.*;
import java.util.*;
  
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class TrickysTreats2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int t = Integer.parseInt(st.nextToken());
		List<pair> a = new ArrayList<>();
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			a.add(new pair(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken())));
		}
		Collections.sort(a);
		PriorityQueue<Integer> q = new PriorityQueue<>();
		int ans = 0, sum = 0;
		for (pair e: a) {
			if (e.p * 2 + t > m) break;
			int lmt = (m-e.p*2)/t;
			while (q.size() > lmt) {
				sum -= q.poll();
			}
			ans = Math.max(ans,  sum);
		}
		System.out.println(ans);
	}
	static class pair implements Comparable<pair> {
		int p, c;
		pair(int p0, int c0) {
			p = p0;
			c = c0;
		}
		public int compareTo(pair x) {
			return Integer.compare(p, x.p);
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SwapitySwapitySwap {
	static int n, m, k;
	static int [] list;
	static int [] start, end;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		start = new int[n+1];
		end = new int[n+1]; 
		list = new int[n+1];
		for(int i = 1; i <= n; i++) list[i] = i;
		for (int i = 1; i <= m; i++){
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			for (int j = 0; j <= (b-a)/2; j++) {
				int temp = list[a+j];
				list[a] = list[b-j];
				list[b] = temp;
			}
		}
		for(int i = 1; i <= n; i++) end[i] = list[i];
		for(int i = 1; i <= n; i++) start[i] = i;
		for (int i = k; i > 0; i /=2) {
			if(k%2 == 1) {
				start = change(start, end);
			}
			if(k/2 > 0) {
				end = change(end, end);
			}
		}
		for (int i = 1; i <= n; i++) System.out.println(start[i]);
	}
	public static int[] change(int[] l, int[] op) {
		int[] temp = new int[l.length];
		for(int i = 1; i < temp.length; i++) {
			temp[i] = l[op[i]];
		}
		return temp;
	}
}
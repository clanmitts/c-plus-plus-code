package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;

public class GoodGroups2 {
	static int x, y, g, count;
	static HashMap<String, HashSet<String>> same = new HashMap<String, HashSet<String>>();
	static HashMap<String, HashSet<String>> diff = new HashMap<String, HashSet<String>>();
	static String [] list = new String [4];
	static void notSame(String str) {
		for (int i = 1; i <= 3; i++) {
			if (!same.get(str).add(list[i])) count--;
		}
	}
	static void notDiff(String str) {
		for (int i = 1; i <= 3; i++) {
			if (!diff.get(str).add(list[i])) count ++;
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		x = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= x; i++) {
			st = new StringTokenizer(br.readLine());
			String a = st.nextToken().trim();
			String b = st.nextToken().trim();
			if (same.containsKey(a)) {
				same.get(a).add(b);
			}
			else {
				same.put(a, new HashSet<String>());
				same.get(a).add(b);
			}
			if (same.containsKey(b)) {
				same.get(b).add(a);
			}
			else {
				same.put(b, new HashSet<String>());
				same.get(b).add(a);
			}
		}
		st = new StringTokenizer(br.readLine());
		y = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= y; i++) {
			st = new StringTokenizer(br.readLine());
			String a = st.nextToken().trim();
			String b = st.nextToken().trim();
			if (diff.containsKey(a)) {
				diff.get(a).add(b);
			}
			else {
				diff.put(a, new HashSet<String>());
				diff.get(a).add(b);
			}
			if (diff.containsKey(b)) {
				diff.get(b).add(a);
			}
			else {
				diff.put(b, new HashSet<String>());
				diff.get(b).add(a);
			}
		}
		st = new StringTokenizer(br.readLine());
		g = Integer.parseInt(st.nextToken());
		count = 2*x;
		for (int i = 1; i <= g; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= 3; j++) {
				list[j] = st.nextToken().trim();
			}
			for (int j = 1; j <= 3; j++) {
				if (same.containsKey(list[j])) {
					notSame(list[j]);
				}
				if (diff.containsKey(list[j])) {
					notDiff(list[j]);
				}
			}
		}
		System.out.println(count/2);
	}
}

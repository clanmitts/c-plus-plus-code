package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class UnnecessaryTrashPush {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int q = 0; q < t; q++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			int k = Integer.parseInt(st.nextToken());
			int trash = 0;
			int count = 0;
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < n; i++) {
				int temp = Integer.parseInt(st.nextToken());
				trash += temp;
				if (trash >= k) {
					count ++;
					trash =0;
				}
			}
			System.out.println(count);
		}
	}
}

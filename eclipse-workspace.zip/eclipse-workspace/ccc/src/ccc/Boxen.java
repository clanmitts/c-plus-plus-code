package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Boxen {
	public static int n;
	public static int [] list;
	public static int [] leader;
	public static boolean [] vis;
	public static void combine(int a, int b) {
		int aleader = findLeader(a);
		int bleader = findLeader(b);
		if (aleader == bleader) return;
		leader[bleader] = aleader;
	}
	public static int findLeader(int a) {
		if (leader[a] == a) return a;
		else {
			leader[a] = findLeader(leader[a]);
			return leader[a];
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		leader = new int [n+1];
		vis = new boolean [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
			leader[i] = i;
		}
		for (int i = 1; i <= n; i++) {
			combine(list[i], i);
		}
		int count = 0;
		for (int i = 1; i <= n; i++) {
			if (!vis[findLeader(i)]) {
				count ++;
				vis[findLeader(i)] = true;
			}
		}
		System.out.print(count + " ");
		st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		leader = new int [n+1];
		vis = new boolean [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
			leader[i] = i;
		}
		for (int i = 1; i <= n; i++) {
			combine(list[i], i);
		}
		count = 0;
		for (int i = 1; i <= n; i++) {
			if (!vis[findLeader(i)]) {
				count ++;
				vis[findLeader(i)] = true;
			}
		}
		System.out.println(count);
	}
}

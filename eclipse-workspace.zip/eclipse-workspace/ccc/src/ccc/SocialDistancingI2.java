package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class SocialDistancingI2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		char [] list = st.nextToken().trim().toCharArray();
		ArrayList <Integer> dif = new ArrayList<Integer>();
		int count = 0, left= 0, right=0;
		for (int i = 0; i < n; i++) {
			if (list[i] == 1) {
				left = i;
				break;
			}
		}
		for (int i = n-1; i >= 0; i--) {
			if (list[i] == '1') {
				right = i;
				break;
			}
		}
		for (int i = left+1; i <= right; i++) {
			count ++;
			if (list[i] == '1') {
				dif.add(count);
				count = 0;
			}
		}
		right = n-right-1;
		if (dif.size() > 0) {
			Collections.sort(dif, Collections.reverseOrder());
			if (dif.get(0)%2 == 1) {
				dif.add(dif.get(0)/2);
				dif.add(dif.get(0)/2+1);
				dif.remove(0);
			}
			else {
				dif.add(dif.get(0)/2);
				dif.add(dif.get(0)/2);
				dif.remove(0);
			}
			Collections.sort(dif, Collections.reverseOrder());
			if (dif.get(0)%2 == 1) {
				dif.add(dif.get(0)/2);
				dif.add(dif.get(0)/2+1);
				dif.remove(0);
			}
			else {
				dif.add(dif.get(0)/2);
				dif.add(dif.get(0)/2);
				dif.remove(0);
			}
			for (int i = dif.size()-1; i >= 0; i--) {
				
			}
		}
		Collections.sort(dif, Collections.reverseOrder());
		int min = dif.get(dif.size()-1);
		if (right <= 1 && left <= 1) {
			System.out.println(min);
		}
		else if (left <= 1) {
			System.out.println(Math.min(right, min));
		}
		else if (right <= 1) {
			System.out.println(Math.min(left, min));
		}
		else {
			System.out.println(Math.min(min, Math.min(right, left)));
		}
	}
}

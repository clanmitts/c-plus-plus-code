package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ORdeal {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		long n = Long.parseLong(st.nextToken());
		if (n == 0) System.out.println(0);
		String str = "";
		for (long i = 1; i <= n; i *= 2) {
			str += "1";
		}
		System.out.println(str);
	}
}

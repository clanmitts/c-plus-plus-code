package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class WoodcuttingGame2 {
	static int h1, w1, h2, w2;
	static boolean [][][][] list;
	public static boolean check(int a, int b, int c, int d) {
		if (b == 2) {
			if (!check(a, 1, a, 1)) return true;
			if (!check(a, 1, c, d)) return true;
		}
		if (d == 2) {
			if (!check(c, 1, c, 1)) return true;
			if (!check(a, b, c, 1)) return true;
		}
		return true;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		h1 = Integer.parseInt(st.nextToken());
		w1 = Integer.parseInt(st.nextToken());
		h2 = Integer.parseInt(st.nextToken());
		w2 = Integer.parseInt(st.nextToken());
		list = new boolean [h1+1][w1+1][h2+1][w2+1];
		if (check(h1, w1, h2, w2)) System.out.println('W');
		else System.out.println('L');
	}
}

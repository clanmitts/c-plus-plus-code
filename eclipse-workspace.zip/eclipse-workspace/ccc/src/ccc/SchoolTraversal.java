package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SchoolTraversal {
	static int n;
	static int [][] lift;
	static int [] parent;
	static ArrayList<Integer[]>[] list;
	static boolean vis[];
	static long dis[];
	static int height[];
	static Queue<Integer> q;
	public static void createLCA() {
		for (int i = 1; i <= 31-Integer.numberOfLeadingZeros(n); i++) {
			for (int j = 1; j <= n; j++) {
				lift[i][j] = lift[i-1][lift[i-1][j]];
			}
		}
	}
	public static int findLCA(int a, int b) {
		if (a == b) return a;
		for (int i = 31-Integer.numberOfLeadingZeros(n); i >= 0; i--) {
			if (lift[i][a] != lift[i][b]) {
				a = lift[i][a];
				b = lift[i][b];
			}
		}
		return lift[0][a];
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new ArrayList[n+1];
		for (int i = 1; i <= n; i++) list[i] = new ArrayList<Integer[]>();
		parent = new int [n+1];
		vis = new boolean [n+1];
		vis[1] = true;
		dis = new long [n+1];
		height = new int [n+1];
		q = new LinkedList<Integer>();
		q.add(1);
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken())+1;
			int b = Integer.parseInt(st.nextToken())+1;
			int w = Integer.parseInt(st.nextToken());
			Integer[] temp = {b, w};
			list[a].add(temp);
			Integer [] temp1  = {a, w};
			list[b].add(temp1);
		}
		while (!q.isEmpty()) {
			Integer cur = q.poll();
			for (Integer[] i: list[cur]) {
				if (!vis[i[0]]) {
					q.add(i[0]);
					parent[i[0]] = cur;
					vis[i[0]] = true;
					dis[i[0]] = dis[cur]+i[1];
					height[i[0]] = height[cur]+1;
				}
			}
		}
		lift = new int [31-Integer.numberOfLeadingZeros(n)+1][n+1];
		for (int i = 1; i <= n; i++) {
			lift[0][i] = parent[i];
		}
		createLCA();
		st = new StringTokenizer(br.readLine());
		int q=  Integer.parseInt(st.nextToken());
		for (int i = 1; i <= q; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken())+1;
			int b = Integer.parseInt(st.nextToken())+1;
			int a1 = a;
			int b1 = b;
			if (height[a1] > height[b1]) {
				for (int j = 31-Integer.numberOfLeadingZeros(n); j >= 0; j--) {
					if ((1 << j) <= height[a1]-height[b1]) {
						a1 = lift[j][a1];
					}
				}
			}
			else if (height[b1] > height[a1]) {
				for (int j = 31-Integer.numberOfLeadingZeros(n); j >= 0; j--) {
					if ((1 << j) <= height[b1]-height[a1]) {
						b1 = lift[j][b1];
					}
				}
			}
			int lowest = findLCA(a1, b1);
			System.out.println(dis[a]-dis[lowest] + dis[b]-dis[lowest]);
		}
	}
}

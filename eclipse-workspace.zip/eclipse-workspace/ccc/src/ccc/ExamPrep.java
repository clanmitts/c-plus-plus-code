package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ExamPrep {
	public static int n;
	public static int q;
	public static int [] list;
	public static int [] leader;
	public static long [] notes;
	public static int [] size;
	public static void combine(int a, int b) {
		int aleader = findLeader(a);
		int bleader = findLeader(b);
		if (size[aleader] < size[bleader]) {
			int temp = aleader;
			aleader = bleader;
			bleader = temp;
		}
		if (aleader == bleader) return;
		notes[aleader] += notes[bleader];
		size[aleader] += size[bleader];
		leader[bleader] = aleader;
	}
	public static int findLeader(int a) {
		if (leader[a] == a) return a;
		else {
			leader[a] = findLeader(leader[a]);
			return leader[a];
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		leader = new int [n+1];
		notes = new long [n+1];
		size = new int [n+1];
		for (int i = 1; i <= n; i++) leader[i] = i;
		for (int i = 1; i <= n; i++) size[i] = 1;
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) list[i] = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) notes[i] = list[i];
		for (int i = 1; i <= q; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			if (a == 1) {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				combine(b, c);
			}
			else if (a == 2) {
				int b = Integer.parseInt(st.nextToken());
				System.out.println(size[findLeader(b)]);
			}
			else if (a == 3) {
				int b = Integer.parseInt(st.nextToken());
				System.out.println(notes[findLeader(b)]);
			}
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BrucesHomework {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int t = Integer.parseInt(st.nextToken());
		int [] problems = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) problems[i] = Integer.parseInt(st.nextToken());
		double [] good = new double [n+1];
		int temp;
		int extra = 0;
		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine());
			double a = Double.parseDouble(st.nextToken());
			if (a == 0) extra ++;
			for (int j = 0; j < a; j++) {
				temp = Integer.parseInt(st.nextToken());
				good[temp] += 1/a;
			}
		}
		double [][] dp = new double [n+1][t+1];
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= t; j++) {
				if (j - problems[i] >= 0) {
					dp[i][j] = Math.max(good[i] + dp[i-1][j-problems[i]], dp[i-1][j]);
				}
				else {
					dp[i][j] = dp[i-1][j];
				}
			}
		}
		System.out.printf("%.2f", (dp[n][t]+extra));
	}
}
package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BinaryIndexedTree3 {
	static long [] bit, freq;
	static int [] list;
	static int n, m;
	public static void update(int index, long val) {
		while (index <= n) {
			bit[index] += val;
			index += (index & -index);
		}
	}
	public static long freqTo(int index) {
		long sum = 0;
		while (index > 0) {
			sum += bit[index];
			index -= (index & -index);
		}
		return sum;
	}
	public static void update2(int list2, long val) {
		while (list2 <= 100000) {
			freq[list2] += val;
			list2 += (list2 &-list2);
		}
	}
	public static long freqTo2(int index) {
		long sum = 0;
		while (index > 0) {
			sum += freq[index];
			index -= (index & -index);
		}
		return sum;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		bit = new long [n+1];
		freq = new long[100001];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
			update(i, list[i]);
			update2(list[i], 1);
		}
		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().charAt(0);
			if (a == 'C') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				update2(list[b], -1);
				update(b, c-list[b]);
				list[b] = c;
				update2(c, 1);

			}
			else if (a == 'S') {
				int b = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				System.out.println(freqTo(c) - freqTo(b-1));
			}
			else {
				int b = Integer.parseInt(st.nextToken());
				System.out.println(freqTo2(b));
			}
		}
	}
}

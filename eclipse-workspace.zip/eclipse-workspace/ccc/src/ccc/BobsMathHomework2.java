package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsMathHomework2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		long n = Long.parseLong(st.nextToken());
		int count = 0;
		for (long length = 1; length*(length+1)/2 <= n; length ++) {
			long temp = (2*n - length*length-1)/(2*length);
			if (2*temp*length + length*(length+1) == 2*n) count ++;
		}
		System.out.println(count);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class StrategyMeeting2 {
	public static ArrayList<Integer>[] list;
	public static int CountPaths (int start, int end, int count) {
		if (start == end) count ++;
		else {
			if (list[start].size() > 0) {
				for (int i: list[start]) {
				}
			}
		}
		return count;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int q = 0; q < t; q++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			list = new ArrayList[n+1];
			for (int i = 1; i <= n; i++) list[i] = new ArrayList<Integer>();
			for (int i = 1; i <= n; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 1; j <= n; j++) {
					int temp = Integer.parseInt(st.nextToken());
					if (temp == 1) list[i].add(j);
				}
			}
			System.out.println(CountPaths(1, n, 0));
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class SleepyCowHerding2 {
	static int n;
	static int [] list;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = 3;
		int [] list = new int [n];
		for (int i = 0; i < n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(list);
		int temp = list[0];
		for (int i = 0; i < n; i++) list[i] -= temp;
		int [] dif = new int [n];
		for (int i = 0; i < n-1; i++) dif[i] = list[i+1]-list[i];
		int max = list[n-1]-n-Math.min(dif[0], dif[n-2])+2;
		int l = 0; 
		int r = 0;
		int templ = 0;
		int tempr = 0;
		int min = Integer.MIN_VALUE;
		while (true) {
			if (list[r]-list[l]+1 <= n) {
				if (r-l+1 > min) {
					min = r-l+1;
					templ = l;
					tempr = r;
				}
				r++;
			}
			else {
				l++;
			}
			if (r == n) break;
		}
		if (tempr == n)
		if (min == n-1 && list[tempr]-list[templ]+1 == n-1
				&& (tempr == n-1 || list[tempr+1]-list[tempr] >= 3)
				&& (templ == 0 || list[templ]-list[templ-1] >= 3)) min = 2;
		else min = n-min;
		System.out.println(min);
		System.out.println(max);
	}
}

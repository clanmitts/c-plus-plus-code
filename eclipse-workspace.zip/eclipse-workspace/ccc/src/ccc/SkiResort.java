package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SkiResort {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		ArrayList<hill>[] list = new ArrayList[n+1];
		for (int i = 1; i <= n; i++) {
			list[i] = new ArrayList<hill>();
		}
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int w = Integer.parseInt(st.nextToken());
			list[a].add(new hill(a, b, w, 0));
			list[b].add(new hill(b, a, w, 0));
		}
		boolean [] vis = new boolean [n+1];
		vis[1] = true;
		Queue<hill> q = new LinkedList<hill>();
		q.add(new hill(1, 1, 0, 0));
		vis[1] = true;
		while (!q.isEmpty()) {
			hill temp = q.poll();
			for (hill i: list[temp.b]) {
				if (!vis[i.b]) {
					i.level = temp.level+1;
					vis[i.b]= true;
					q.add(i);
				}
			}
		}
		ArrayList<hill>[] level = new ArrayList[n];
		for (int i = 1; i <= n-1; i++) {
			level[i] = new ArrayList<hill>();
		}
		for (int i = 1; i <= n; i++) {
			for (hill j: list[i]) {
				if (j.level != 0) {
					list[j.level].add(j);
				}
			}
		}
		int [] people = new int [k+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= k; i++) {
			people[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(people);
		for (int i = 1; i <= n-1; i++) {
			Collections.sort(level[i]);
		}
		int [] count = new int [n+1];
		for (int i = 1; i <= n-1; i++) {
			if (level[i].size() == 0) break;
			int index = 1;
			for (hill j: level[i]) {
			}
		}
	}
	public static class hill implements Comparable<hill>{
		int a;
		int b;
		int w;
		int level;
		public hill (int x, int y, int z, int w) {
			a = x;
			b = y;
			w = z;
			level = w;
		}
		public int compareTo(hill o) {
			return Integer.compare(w, o.w);
		}
	}
}

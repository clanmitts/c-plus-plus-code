package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class InterpretiveArt3 {
	static int n;
	static int [] current;
	static int [] want;
	static ArrayList<Integer> a;
	static ArrayList<Integer> b; 
	static ArrayList<int []> clumps;
	public static boolean works() {
		if (a.size() != b.size()) return false;
		for (int i = 0; i < a.size(); i++) if (a.get(i) < b.get(i)) return false;
		return true;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		current = new int [n+1];
		want = new int [n+1];
		a = new ArrayList<Integer>();
		b = new ArrayList<Integer>();
		st = new StringTokenizer(br.readLine());
		current[0] = 1;
		want[0] = 1;
		for (int i = 1; i <= n; i++) current[i] = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) want[i] = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) if (current[i] == 0) a.add(i);
		for (int i = 1; i <= n; i++) if (want[i] == 0) b.add(i);
		if (works()) {
			clumps = new ArrayList<int []>();
			if (b.size() != 0) {
				clumps.add(new int [3]);
				clumps.get(clumps.size()-1)[0] = b.get(0);
				clumps.get(clumps.size()-1)[1] = 0;
				for (int i = 1; i < b.size(); i++) {
					if (b.get(i)-b.get(i-1) == 1) {
						clumps.get(clumps.size()-1)[1]++;
					}
					else {
						clumps.add(new int [3]);
						clumps.get(clumps.size()-1)[0] = b.get(i);
						clumps.get(clumps.size()-1)[1] = 0;
					}
				}
				int index = 0;
				for (int i = 0; i < clumps.size(); i++) {
					clumps.get(i)[2] = a.get(index + clumps.get(i)[1]);
					index += clumps.get(i)[1]+1;
				}
			}
			int count = 0;
			ArrayList<int []> need = new ArrayList<int []>();
			for (int i = 0; i < clumps.size(); i++) {
				if (clumps.get(i)[2] - clumps.get(i)[0] != 0) {
					count ++;
					need.add(clumps.get(i));
				}
			}
			System.out.println(clumps.size());
			for (int i = 0; i < need.size(); i++) {
				System.out.println(need.get(i)[0] + " " + need.get(i)[2]);
			}
		}
		else {
			System.out.println(-1);
		}
	}
}

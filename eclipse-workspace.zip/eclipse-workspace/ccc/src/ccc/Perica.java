package ccc;

import java.util.Arrays;

public class Perica {
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Cereal {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		boolean [] used = new boolean [m+1];
		int [][] cows = new int [n+1][2];
		int [] take = new int [m+1];
		int [] ans = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			cows[i][0] = Integer.parseInt(st.nextToken());
			cows[i][1] = Integer.parseInt(st.nextToken());
		}
		take[cows[n][0]] = n;
		used[cows[n][0]] = true;
		int index = 0;
		for (int i = n-1; i >= 1; i--) {
			ans[i] = ans[i+1];
			index = i;
			if (used[cows[index][0]]) {
				int temp = take[cows[index][0]];
				take[cows[index][0]] = index;
				while (true) {
					if (cows[temp][0] == cows[index][0]) {
						if (used[cows[temp][1]]) {
							int temp2 = take[cows[temp][1]];
							take[cows[temp][1]] = temp;
							temp = temp2;
							if (index == n) break;
							else index++;
						}
						else {
							used[cows[temp][1]] = true;
							take[cows[temp][1]] = temp;
						}
					}
					else {
						used[cows[temp][0]] = true;
						take[cows[temp][0]] = temp;
						break;
					}
				}
			}
			else {
				used[cows[index][0]] = true;
				take[cows[index][0]] = index;
				ans[i]++;
			}
		}
		for (int i = 1; i <= n-1; i++) {
			System.out.println(ans[i]);
		}
		}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SegmentTreeTest {
	static int n;
	static int m;
	static int [][] segtree;
	static int [] list;
	public static int gcf (int a, int b) {
		if (b == 0) return a;
		else return gcf(b, a%b);
	}
	public static void makesegtree(int ind, int le, int ri){
		if(le==ri){
				segtree[ind][0]=list[le];
				segtree[ind][1] = list[le];
				segtree[ind][2] = 1;
				return;
		}
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		makesegtree(left,le,mid);
		makesegtree(right,mid+1,ri);
		segtree[ind][0] = Math.min(segtree[left][0],segtree[right][0]);
		segtree[ind][1] = gcf(segtree[left][1], segtree[right][1]); 
		if (segtree[left][0] == segtree[right][0]) 
			segtree[ind][2] = segtree[left][2] + segtree[right][2];
		else if (segtree[left][0] < segtree[right][0])
			segtree[ind][2] = segtree[left][2];
		else
			segtree[ind][2] = segtree[right][2];
	}
	public static void update(int ind, int le, int ri, int loc, int newvalue){
		if(le==ri){
			segtree[ind][0] = newvalue;
			segtree[ind][1] = newvalue;
			segtree[ind][2] = 1;
			return;
		}
		int mid = (le + ri) / 2; 
		int left = ind + 1; 
		int right = ind + (mid - le + 1) * 2;
		if(loc <= mid){
			update(left, le, mid, loc, newvalue);
		}
		else{
			update(right, mid+1, ri, loc, newvalue);
		}
		segtree[ind][0]= Math.min(segtree[left][0],segtree[right][0]);
		segtree[ind][1] = gcf(segtree[left][1],segtree[right][1]);
		if (segtree[left][0] == segtree[right][0]) 
			segtree[ind][2] = segtree[left][2] + segtree[right][2];
		else if (segtree[left][0] < segtree[right][0])
			segtree[ind][2] = segtree[left][2];
		else
			segtree[ind][2] = segtree[right][2];
	}
	public static int querymin(int ind, int le, int ri, int l, int r){
		if (ri < l || le > r)return Integer.MAX_VALUE;
		if (le >= l && ri <= r)return segtree[ind][0];
		int mid = (le + ri) / 2; 
		int left = ind + 1; 
		int right = ind + (mid - le + 1) * 2;
		return Math.min(querymin(left,le,mid,l,r),querymin(right,mid+1,ri,l,r));
	}
	public static int querygcf(int ind, int le, int ri, int l, int r){
		if(ri < l || le > r)return 0;
		if(le >= l && ri <= r)return segtree[ind][1];
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		return gcf(querygcf(left,le,mid,l,r),querygcf(right,mid+1,ri,l,r));
	}
	public static int[] queryminmin(int ind, int le, int ri, int l, int r) {
		if(ri < l || le > r) {
			int [] temp = new int [2];
			temp[0] = Integer.MAX_VALUE;
			temp[1] = Integer.MAX_VALUE;
			return temp;
		}
		if(le >= l && ri <= r) {
			int [] temp = {Integer.MAX_VALUE, Integer.MAX_VALUE};
			temp[0] = segtree[ind][1];
			temp[1] = segtree[ind][2];
			return temp;
		}
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2; 
		int[] a = queryminmin(left, le, mid, l, r);
		int[] b = queryminmin(right, mid+1, ri, l, r);
		if (a[0] == b[0]) {
			int [] temp = new int [2];
			temp[0] = a[0];
			temp[1] = a[1]+b[1];
			return temp;
		}
		else if (a[0] < b[0]) {
			int [] temp = new int [2];
			temp[0] = a[0];
			temp[1] = a[1];
			return temp;
		}
		else {
			int [] temp = new int [2];
			temp[0] = b[0];
			temp[1] = b[1];
			return temp;
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		segtree = new int [n*2+1][3];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) list[i] = Integer.parseInt(st.nextToken());
		makesegtree(1, 1, n);
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().trim().charAt(0);
			int b = Integer.parseInt(st.nextToken());
			int c = Integer.parseInt(st.nextToken());
			if (a == 'C') update(1, 1, n, b, c);
			else if (a == 'M') System.out.println(querymin(1, 1, n, b, c));
			else if (a == 'G') System.out.println(querygcf(1, 1, n, b, c));
			else if (a == 'Q') {
				if (querymin(1, 1, n, b, c) == querygcf(1, 1, n, b, c)) 
					System.out.println(queryminmin(1, 1, n, b, c)[1]);
				else System.out.println(0);
			}
		}
	}
}

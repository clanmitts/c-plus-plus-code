package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Selection2 {
	public static void sortbyColumn(long arr[][], int col){
        Arrays.sort(arr, new Comparator<long[]>() {
          public int compare(final long[] entry1, 
                             final long[] entry2) {
            if (entry1[col] > entry2[col])
                return 1;
            else
                return -1;
          }
        }); 
    }
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		long [][] list = new long [n+1][2];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i][0] = Long.parseLong(st.nextToken());
			list[i][1] = Long.parseLong(st.nextToken());
		}		
		sortbyColumn(list, 0);
		long [] psa = new long [n+1];
		for (int i = 1; i <= n; i++) psa[i] = psa[i-1] + list[i][1];
		long max = psa[n] - list[n][0] + list[1][0];
		int temp = 0;
		for (int i = 1; i < n; i++) {
			if (psa[n] - psa[i] - list[n][0] + list[i+1][0] > max) {
				max = psa[n] - psa[i] - list[n][0] + list[i+1][0];
				temp = i;
			}
		}
		for (int j = n-1; j > temp; j--) {
			if (psa[j] - psa[temp] - list[j][0] + list[temp+1][0] > max) {
				max = psa[j] - psa[temp] - list[j][0] + list[temp+1][0];
			}
		}
		temp = n;
		for (int j = n-1; j > 0; j--) {
			if (psa[j] - psa[0] - list[j][0] + list[1][0] > max) {
				max = psa[j] - psa[0] - list[j][0] + list[1][0];
				temp = j;
			}
		}
		for (int i = 1; i < temp; i++) {
			if (psa[temp] - psa[i] - list[temp][0] + list[i][0] > max) {
				max = psa[temp] - psa[i] - list[temp][0] + list[i][0];
			}
		}
		System.out.println(max);
	}
}

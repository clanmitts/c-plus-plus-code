package ccc;

import java.util.Scanner;

public class test {
	static int [][] grid = new int [9][9];
	static int win() {
		for (int i = 1; i <= 6;i ++) {
			for (int j = 1; j <= 4; j++) {
				if (grid[i][j]==1 && 
					grid[i][j]==grid[i+1][j+1] && 
					grid[i][j]==grid[i+2][j+2] &&
					grid[i][j]==grid[i+1][j+3] &&
					grid[i][j]==grid[i+0][j+4]) {
					return 1;
				}
				if (grid[i][j]==2 && 
					grid[i][j]==grid[i+1][j+1] && 
					grid[i][j]==grid[i+2][j+2] &&
					grid[i][j]==grid[i+1][j+3] &&
					grid[i][j]==grid[i+0][j+4]) {
					return 2;
				}
				if (grid[i+2][j]==1 &&
					grid[i+2][j]==grid[i+1][j+1] &&
					grid[i+2][j]==grid[i+0][j+2] &&
					grid[i+2][j]==grid[i+1][j+3] &&
					grid[i+2][j]==grid[i+2][j+4]) {
					return 1;
				}
				if (grid[i+2][j]==1 &&
					grid[i+2][j]==grid[i+1][j+1] &&
					grid[i+2][j]==grid[i+0][j+2] &&
					grid[i+2][j]==grid[i+1][j+3] &&
					grid[i+2][j]==grid[i+2][j+4]) {
					return 1;
				}
			}
		}
		return 0;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		for (int i = 1; i<= 8; i++) {
			for (int j = 1; j <= 8; j++) {
				grid[i][j] = input.nextInt();
			}
		}
		System.out.println(win());
	}
}
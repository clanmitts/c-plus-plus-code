package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class PermutationsPrimes {
	static boolean notPrime(int n) {
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n%i == 0) return true;
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		if (n == 1) System.out.println(1);
		else if (n <= 4) System.out.println(-1);
		else if (n == 5) {
			System.out.println("1 3 5 4 2");
		}
		else {
			if (n%2 == 0) {
				int count = 0;
				int num = 0;
				if (notPrime(n+1)) num = n+1;
				else if (notPrime(n+3)) num = n+3;
				else num = n+5;
				int a = n;
				int b = num-n;
				for (int i = 2; i < n; i+=2) {
					count ++;
					if (i != a) System.out.print(i+" ");
				}
				System.out.print(a+" ");
				System.out.print(b+ " ");
				for (int i = 1; i <= n; i+=2) {
					count ++;
					if (i != b) {
						if (count == n-1) System.out.print(i);
						else System.out.print(i+" ");
					}
				}
				System.out.println();
			}
			else {
				int num = 0;
				if (notPrime(n+2)) num = n+2;
				else if (notPrime(n+4)) num = n+4;
				else num = n+6;
				int a = n;
				int b = num-n;
				int count = 0;
				for (int i = 1; i <= n; i+= 2) {
					count ++;
					if (i != a) System.out.print(i+ " ");
				}
				System.out.print(a+ " ");
				System.out.print(b + " ");
				for (int i = 2; i <= n; i+= 2) {
					count ++;
					if (i != b) {
						if (count == n) System.out.print(i);
						else System.out.print(i+ " ");
					}
				}
				System.out.println();
			}
		}
	}
}

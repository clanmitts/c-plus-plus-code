package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class PermutationsProducts {
	public static long gcd(long a, long b) {
		if (b == 0)
        return a;
    else
        return gcd(b, a % b);
}
	 public static void main(String[] args) throws IOException {
	        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	        StringTokenizer st = new StringTokenizer(br.readLine());
	        int n = Integer.parseInt(st.nextToken());
	        long [] list = new long [n+1];
	        for (int i = 2; i <= n; i++) {
	            System.out.println("? 1 " + i);
	            System.out.flush();
	            st = new StringTokenizer(br.readLine());
	            list[i] = Long.parseLong(st.nextToken());
	        }
	        long gcd = list[2];
	        for (int i = 3; i <= n; i++) {
	            gcd = gcd(gcd, list[i]);
	        }
	        list[1] = gcd;
	        for (int i = 2; i <= n; i++) {
	            list[i] /= gcd;
	        }
	        System.out.print("!");
	        for (int i = 1; i <= n; i++) {
	            System.out.print(" " + list[i]);
	        }
	        System.out.println();
	        System.out.flush();
	 }
}

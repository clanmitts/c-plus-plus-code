package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class RedistributingGifts2 {
	static int n;
	static ArrayList<Integer>[] list;
	static Queue<Integer> q;
	static int [] ans;
	static boolean [] vis;
	static boolean [] place;
	public static boolean works () {
		while (!q.isEmpty()) {
			int cur = q.poll();
			if (place[cur]) return true;
			place[cur] = true;
			for (int i: list[cur]) {
				if (!vis[i]) {
					q.add(i);
					vis[i] = true;
				}
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new ArrayList[n+1];
		for (int i = 1; i <= n; i++) {
			list[i] = new ArrayList<Integer>();
		}
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= n; j++) {
				int temp = Integer.parseInt(st.nextToken());
				if (temp == i) break;
				list[i].add(temp);
			}
		}
		ans = new int [n+1];
		for (int i = 1; i <= n; i++) {
			ans[i] = i;
		}
		for (int i = 1; i <= n; i++) {
			for (int j: list[i]) {
				q = new LinkedList<Integer>();
				q.add(j);
				vis = new boolean [n+1];
				vis[j] = true;
				place = new boolean [n+1];
				place[i] = true;
				if (works()) {
					ans[i] = j;
					break;
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			System.out.println(ans[i]);
		}
	}
}

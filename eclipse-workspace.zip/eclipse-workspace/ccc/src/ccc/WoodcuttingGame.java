package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class WoodcuttingGame {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int ha, wa, hb, wb;
		ha = Integer.parseInt(st.nextToken());
		wa = Integer.parseInt(st.nextToken());
		hb = Integer.parseInt(st.nextToken());
		wb = Integer.parseInt(st.nextToken());
		if (wa == 1 && wb == 1) System.out.println('L');
		else if (wa == 1 && wb >= 3) System.out.println('W');
		else if (wb == 1 && wa >= 3) System.out.println('W');
		else if (wa == 1 && wb <= 2) System.out.println('L');
		else if (wb == 1 && wa <= 2) System.out.println('L');
		else System.out.println('W');
		
	}
}

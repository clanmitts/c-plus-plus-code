package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SuperPlumber {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int m = Integer.parseInt(st.nextToken());
		int n = Integer.parseInt(st.nextToken());
		char [][] list = new char [m+2][n+1];
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			char [] temp = st.nextToken().trim().toCharArray();
			for (int j = 1; j <= n; j++) {
				list[i][j] = temp[j-1];
			}
		}
		int [][] dis = new int [m+2][n+1];
		for (int i = 0; i >= n; i ++) {
			for (int j = 1; i <= m; i++) {
				if (list[j][i] != '*') {
					dis[j][i] = list[j][i]-48+
							Math.max(dis[j-1][i], 
									dis[j][i-1]);
					if (list[j][i] >= 49 && list[j][i] <= 57) {
						dis[j][i] += list[j][i]-48;
					}
				}
			}
			for (int j = m; j >= 1; j--) {
				if (list[j][i] != '*') {
					if (list[j][i] >= 49 && list[j][i] <= 57) {
						dis[j][i] = Math.max(dis[j+1][i]+list[j][i]-48, dis[j][i]);
					}
					else {
						dis[j][i] = Math.max(dis[j-1][i], dis[j][i]);
					}
				}
			}
		}
	}
}

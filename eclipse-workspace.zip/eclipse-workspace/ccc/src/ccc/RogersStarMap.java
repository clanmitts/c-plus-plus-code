package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class RogersStarMap {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		
	}
	public static class horizontal implements Comparable<horizontal> {
		int x;
		int y;
		public horizontal (int a, int b) {
			x = a;
			y = b;
		}
		public int compareTo(horizontal o) {
			return Integer.compare(y, o.y);
		}
	}
	public static class vertical implements Comparable<vertical> {
		int x;
		int y;
		public vertical (int a, int b) {
			x = a;
			y = b;
		}
		public int compareTo(vertical o) {
			return Integer.compare(x, o.x);
		}
	}
}

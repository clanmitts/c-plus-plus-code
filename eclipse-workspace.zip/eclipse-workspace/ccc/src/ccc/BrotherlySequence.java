package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BrotherlySequence {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) list[i] = Integer.parseInt(st.nextToken());
		int [] count = new int [n];
		Arrays.fill(count, 1);
		for (int i = 1; i < n; i++) 
			if (Math.abs(list[i]-list[i-1]) <= 2) count[i] = count[i-1]+1;
		int max = 0;
		for (int i: count) max = Math.max(max, i);
		System.out.println(max);
	}
}

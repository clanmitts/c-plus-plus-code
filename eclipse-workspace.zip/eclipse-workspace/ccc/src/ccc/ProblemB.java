package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ProblemB {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		int [] r = new int [1414215];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			long a = Integer.parseInt(st.nextToken());
			long b = Integer.parseInt(st.nextToken());
			a *= a;
			b *= b;
			
			double rad = a+b;
			rad = Math.sqrt(rad);
			r[(int)(Math.ceil(rad))] ++;
		}
		for (int i = 1; i <= 1414214; i++) {
			r[i] += r[i-1];
		}
		for (int i = 0; i < q; i++) {
			st = new StringTokenizer(br.readLine());
			int thing = Integer.parseInt(st.nextToken());
			System.out.println(r[thing]);
		}
	}
}

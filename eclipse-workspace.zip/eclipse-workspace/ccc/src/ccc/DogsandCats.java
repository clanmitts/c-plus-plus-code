package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DogsandCats {
	static long total = 0;
	static long factorial (long total, int n) {
		if (n == 0) return 1;
		if (n == 1) return total;
			return (long) ((total * factorial (total, n-1))% (1e9 + 7));
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int N = Integer.parseInt(st.nextToken());
		int M = Integer.parseInt(st.nextToken());
		int[] dp = new int[N + 1];
		dp[0] = 1; 
		for (int i = 1; i <= N; i++) {
			dp[i] = dp[i - 1]; 
	           
			if (i >= M) {
				dp[i] += dp[i - M]; 
			}
		}
        System.out.println(dp[N]+1);
	}

}

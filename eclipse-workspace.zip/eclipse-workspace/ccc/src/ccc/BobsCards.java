package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsCards {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		boolean [] list = new boolean [200001];
		int count = 0;
		list [0] = true;
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (list[temp] == false && list[temp-1] == true) {
				list[temp] = true;
				count ++;
			}
		}
		if (count == 0) System.out.println(-1);
		else System.out.println(n-count);
	}
}

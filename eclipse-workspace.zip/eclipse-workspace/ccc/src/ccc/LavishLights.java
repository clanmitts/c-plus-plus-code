package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class LavishLights {
	static int n;
	static int q;
	static long [] list;
	static long gcd(long a, long b) {
	  if (b == 0)
	    return a;
	  return (long) (gcd(b, a % b));
	}
	static long lcm(long a, long b){
	    return (long) (((a / gcd(a, b)) * b));
	}
	static int binarySearch(int a) {
		if (a == 0) return n+1;
		int l = 1;
		int r = n;
		while (l <= r) {
			int mid = (l+r)/2;
			if (a%list[mid] == 0) {
				if (a%list[mid+1] != 0) return mid+1;
				l = mid+1;
			}
			else if (a%list[mid] != 0) {
				if (a%list[mid-1] == 0) return mid;
				r = mid-1;
			}
		}
		return 0;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		// number of numbers
		n = Integer.parseInt(st.nextToken());
		// number of queries 
		q = Integer.parseInt(st.nextToken());
		// a prefix list containing the lcm of the numbers from index 1 to index i;
		list = new long [n+2];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Long.parseLong(st.nextToken());
		
		}
		//list[0] equals 1 so that I know to output 1;
		list[0] = 1;
		// list[n+1] equals a number with no common multiple with anything, so I know if it gets here, I print -1;
		list[n+1] = Integer.MAX_VALUE;
		int max = n+1;
		for (int i = 2; i <= n; i++)  {
			list[i] = lcm(list[i], list[i-1]);
			if (list[i] > 1e9) {
				max = i;
				break;
			}
		}
		for (int i = max; i <= n; i++) list[i] = Integer.MAX_VALUE;
		for (int i = 1; i <= q; i++) {
			st = new StringTokenizer(br.readLine());
			int t = Integer.parseInt(st.nextToken());
			int temp = binarySearch(t);
			if (temp == n+1) System.out.println(-1);
			else if (temp == 0) System.out.println(1);
			else System.out.println(temp);
		}
	}
}

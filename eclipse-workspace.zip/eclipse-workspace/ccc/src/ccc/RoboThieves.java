package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class RoboThieves {
	static int n, m;
	static char [][] list;
	static int [][] dis;
	static boolean [][] vis;
	static point s;
	static Deque<point> q;
	static int [] xaxis;
	static int [] yaxis;
	static point next;
	static char [] directions = new char[] {'U', 'D', 'L', 'R'};
	static point [] path = new point[] 
			{new point(-1, 0), new point(1, 0), new point(0, -1), new point(0, 1)};
	public static boolean contains(char a) {
		for (int i = 0; i < directions.length; i++) {
			if (a == directions[i]) return true;
		}
		return false;
	}
	public static int indexOf(char a) {
		for (int i = 0; i < 4; i++) {
			if (directions[i] == a) {
				return i;
			}
		}
		return -1;
	}
	public static void camera(int i, int j) {
		up(i, j);
		down(i, j);
		left(i, j);
		right(i, j);
	}
	public static void up(int i, int j) {
		if (contains(list[i][j])) {
			up(i-1, j);
		}
		else if (list[i][j] != 'W') {
			vis[i][j] = true;
			up(i-1, j);
		}
	}
	public static void down(int i, int j) {
		if (contains(list[i][j])) {
			down(i+1, j);
		}
		else if (list[i][j] != 'W') {
			vis[i][j] = true;
			down(i+1, j);
		}
	}
	public static void left(int i, int j) {
		if (contains(list[i][j])) {
			left(i, j-1);
		}
		else if (list[i][j] != 'W') {
			vis[i][j] = true;
			left(i, j-1);
		}
	}
	public static void right(int i, int j) {
		if (contains(list[i][j])) {
			right(i, j+1);
		}
		else if (list[i][j] != 'W') {
			vis[i][j] = true;
			right(i, j+1);
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		list = new char[n][m];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = st.nextToken().trim().toCharArray();
		}
		dis = new int [n][m];
		vis = new boolean [n][m];
		s = new point(0, 0);
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (list[i][j] == 'W') vis[i][j] = true;
				if (list[i][j] == 'S') s = new point(i, j);
				if (list[i][j] == 'C') camera(i, j);
			}
		}
		for (int i = 0; i < n; i++) {
			Arrays.fill(dis[i], -1);
		}
		dis[s.a][s.b] = 0; 
		if (!vis[s.a][s.b]) {
			xaxis = new int[] {1, -1, 0, 0};
			yaxis = new int[] {0, 0, 1, -1};
			q = new LinkedList<point>();
			q.add(new point(s.a, s.b));
			while (!q.isEmpty()) {
				point cur = q.pollFirst();
				if (!vis[cur.a][cur.b]) {
					vis[cur.a][cur.b] = true;
					if (contains(list[cur.a][cur.b])) {
						next = new point(cur.a + path[indexOf(list[cur.a][cur.b])].a, 
								cur.b + path[indexOf(list[cur.a][cur.b])].b);
						if (!vis[next.a][next.b]) {
							dis[next.a][next.b] = dis[cur.a][cur.b]; 
							q.addFirst(next);
						}
					}
					else {
						for (int i = 0; i < 4; i++) {
							next = new point(cur.a+xaxis[i], cur.b+yaxis[i]);
							if (!vis[next.a][next.b]) {
							    if(dis[next.a][next.b]==-1||dis[next.a][next.b]>dis[cur.a][cur.b]+1) {
							        dis[next.a][next.b]= dis[cur.a][cur.b]+1; 
							    }
								q.add(next);
							}
						}
					}
				}
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (list[i][j] == '.') System.out.println(dis[i][j]);
			}
		}
	}
	public static class point {
		int a, b;
		point(int x, int y) {
			a = x;
			b = y;
		}
	}
}

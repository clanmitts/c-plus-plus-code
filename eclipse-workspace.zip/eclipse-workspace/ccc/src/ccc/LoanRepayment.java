package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class LoanRepayment {
	static long n;
	static long m;
	static long k;
	static long left = 1;
	static long right = (long) 1e12;
	static long middle;
	static long milk;
	static long y;
	static long max;
	static long days;
	public static boolean works() {
		milk = 0;
		while (k > 0 && milk < n) {
			y = (n-milk)/middle;
			if (y < m) {
				long temp = (n-milk+m-1)/m;
				if (temp <= k) return true;
				else return false;
			}
			max = n - (middle*y);
			days = (max-milk)/y + 1;
			if (days > k) days = k;
			milk += y*days;
			k -= days;
		}
		if (milk >= n) return true;
		else return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Long.parseLong(st.nextToken());
		k = Long.parseLong(st.nextToken());
		m = Long.parseLong(st.nextToken());
		while (left < right) {
			middle = ((left + right + 1)/2);
			if (works()) {
				left = middle;
			}
			else {
				right = middle -1;
			}
		}
		System.out.println(left);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;

public class Pohlepko3 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		char [][] list = new char [n][n];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = st.nextToken().trim().toCharArray();
		}
		String str = Character.toString(list[0][0]);
		int min = 'z';
		ArrayList<int []> [] s = new ArrayList[n+m];
		for (int i = 1; i <= n+m-1; i++) s[i] = new ArrayList<int []>();
		int [] temp2 = new int [2];
		s[1].add(temp2);
		boolean [][] vis = new boolean [n][m];
		vis[0][0] = true;
		for (int i = 1; i < n+m-1; i++) {
			min = 'z';
			for (int [] cur: s[i]) {
				if (cur[0]+1 < n) {
					min = Math.min(min, list[cur[0]+1][cur[1]]);
				}
				if (cur[1]+1 < m) {
					min = Math.min(min, list[cur[0]][cur[1]+1]);
				}
			}
			str += (Character.toString((char)min));
			for (int [] cur: s[i]) {
				if (cur[0]+1 < n && !vis[cur[0]+1][cur[1]] && 
						min == (char)list[cur[0]+1][cur[1]]) {
					int [] temp = new int [2];
					temp[0] = cur[0]+1;
					temp[1] = cur[1];
					s[i+1].add(temp);
					vis[cur[0]+1][cur[1]] = true;;
				}
				if (cur[1]+1 < m && !vis[cur[0]][cur[1]+1] && 
						min == (char)list[cur[0]][cur[1]+1]) {
					int [] temp = new int [2];
					temp[0] = cur[0];
					temp[1] = cur[1]+1;
					s[i+1].add(temp);
					vis[cur[0]][cur[1]+1] = true;
				}
			}
		}
		System.out.println(str);
	}
}

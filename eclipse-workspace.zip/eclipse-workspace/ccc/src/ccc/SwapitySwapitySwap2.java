package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SwapitySwapitySwap2 {
	static int n, m, k;
	static ArrayList<ArrayList<Integer>> cycles;
	static int [] start, end;
	static boolean [] vis;
	static int [] oneSwap;
	static int [] finalArray;
	static int [] connection;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		cycles = new ArrayList<ArrayList<Integer>>();
		vis = new boolean [n+1];
		oneSwap = new int [n+1];
		finalArray = new int [n+1];
		connection = new int [n+1];
		for(int i = 1; i <= n; i++) oneSwap[i] = i;
		for (int i = 1; i <= m; i++){
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			for (int j = 0; j <= (b-a)/2; j++) {
				int temp = oneSwap[a+j];
				oneSwap[a+j] = oneSwap[b-j];
				oneSwap[b-j] = temp;
			}
		}
		for (int i = 1; i <= n; i++) connection[oneSwap[i]] = i;
		for (int i = 1; i <= n; i++) {
			if (!vis[i]) {
				vis[i] = true;
				cycles.add(new ArrayList<Integer>());
				int temp = i;
				cycles.get(cycles.size()-1).add(i);
				while (true) {
					temp = connection[temp];
					if (!vis[temp]) {
						cycles.get(cycles.size()-1).add(temp);
						vis[temp] = true;
					}
					else {
						break;
					}
				}
			}
		}
		for (ArrayList<Integer> cycle: cycles) {
			for (int i = 0; i < cycle.size(); i++) {
				finalArray[cycle.get((i+k) % cycle.size())] = cycle.get(i);
			}
		}
		for (int i = 1; i <= n; i++) {
			System.out.println(finalArray[i]);
		}
	}
}

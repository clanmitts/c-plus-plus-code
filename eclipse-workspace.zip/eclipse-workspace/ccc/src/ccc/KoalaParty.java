package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.StringTokenizer;

public class KoalaParty {
	static int n;
	static Integer [] list;
	static HashMap<Integer, Boolean> exists;
	public static boolean triple() {
		for (int i = 1; i < n; i++) {
			for (int j = i+2; j <= n; j++) {
				if ((list[i]+list[j]) % 2 == 0 && exists.containsKey((list[i]+list[j])/2))
					return true;
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new Integer[n+1];
		list[0] = 0;
		exists = new HashMap<Integer, Boolean>();
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
			exists.put(list[i], true);
		}
		Arrays.sort(list);
		if (triple()) System.out.println(3);
		else if (n == 1) System.out.println(1);
		else if (n == 2 && (list[1]+list[2])%2 == 1) System.out.println(1);
		else System.out.println(2);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Palindrome2 {
	static char [] notReverse, reverse;
	static int n;
	static int [][] dp;
	public static int longestCommonSubsequence () {
		int where = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (notReverse[i-1] == reverse[j-1])
					dp[where][j] = 1+dp[Math.abs(where-1)][j-1];
				else dp[where][j] = Math.max(dp[Math.abs(where-1)][j], dp[where][j-1]);
			}
			where = Math.abs(where-1);
		}
		return dp[Math.abs(where-1)][n];
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		dp = new int [2][n+1];
		st = new StringTokenizer(br.readLine());
		notReverse = new char[n+1];
		reverse = new char[n+1];
		notReverse = st.nextToken().trim().toCharArray();
		for (int i = 0; i < n; i++) {
			reverse[i] = notReverse[n-i-1];
		}
		int lcs = longestCommonSubsequence();
		System.out.println(n-lcs);
	}
}

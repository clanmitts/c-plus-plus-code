package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class MinimumCostFlow {
	static int n, m, d;
	static int [] leader;
	static edge [] list;
	static ArrayList<Integer> pipe = new ArrayList<Integer>();
	public static void join(int a, int b) {
		leader[leader(a)] = leader(b); 
	}
	public static int leader(int a) {
		if (leader[a] == a) return a;
		leader[a] = leader(leader[a]);
		return leader[a];
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int d = Integer.parseInt(st.nextToken());
		list = new edge[m+1];
		list[0] = new edge(0, 0, 0, 0);
		leader = new int [n+1];
		for (int i = 1; i <= n; i++) leader[i] = i;
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int c = Integer.parseInt(st.nextToken());
			list[i] = new edge(a, b, c, i);
		}
		Arrays.sort(list);
		for (int i = 1; i <= m; i++) {
			if (leader(list[i].a) != leader(list[i].b)) {
				join(list[i].a, list[i].b);
				pipe.add(i);
			}
		}
		int ans = 0;
		for (int i: pipe) {
			if (list[i].c > n-1) ans++;
		}
		int count = 0;
		int max = list[pipe.get(n-2)].w;
		for (int i = n-2; i >= 0; i--) {
			if (list[pipe.get(i)].w == list[pipe.get(n-2)].w && list[pipe.get(i)].c >= n) {
				count ++;
			}
			else break;
		}
	
		leader = new int [n+1];
		for (int i = 1; i <= n; i++) leader[i] = i;
		int counter = 0;
		for (int i = 1; i <= m; i++) {
			if (leader(list[i].a) != leader(list[i].b)) {
				counter ++;
				join(list[i].a, list[i].b);
				pipe.add(list[i].c);
			}
			if (counter == n-1-count) break;
		}
		boolean change = false;
		for (edge i: list) {
			if (leader(i.a) != leader(i.b) && i.c <= n-1 && i.w > max && i.w <= d) {
				System.out.println(ans-1);
				change = true;
				break;
			}
		}
		if (!change) System.out.println(ans);
	}
	public static class edge implements Comparable<edge> {
		int a;
		int b;
		int w;
		int c;
		public edge (int x, int y, int z, int q) {
			a = x;
			b = y;
			w = z;
			c = q;
		}
		public int compareTo(edge o) {
			if (Integer.compare(w, o.w) == 0) {
                return Long.compare(c, o.c);
            } 
			else {
				return Long.compare(w, o.w);
			}
		}
	}
}

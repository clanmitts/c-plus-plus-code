package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Acowdemia {
	static int n, k, l;
	static Integer [] list;
	static ArrayList<Integer> num;
	public static int binarySearch(int l, int r, int x) {
		if (r >= l) {
            int mid = l + (r - l) / 2;
            if (list[mid] == x)
                return mid;
            if (list[mid] > x)
                return binarySearch(l, mid - 1, x);
            return binarySearch(mid + 1, r, x);
        }
        return r;
	}
	public static void find(int l, int r) {
		if (r >= l) {
			int mid = l + (r-1)/2;
			if (works(mid)) {
				num.add(mid);
				find(mid+1, r);
				return;
			}
			find(l, mid-1);
			return;
		}
	}
	public static boolean works (int x) {
		int p = binarySearch(0, list.length-1, x);
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		l = Integer.parseInt(st.nextToken());
		num = new ArrayList<Integer>();
		list = new Integer [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
			
		}
	}
}

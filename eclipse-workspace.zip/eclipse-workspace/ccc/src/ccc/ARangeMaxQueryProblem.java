package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ARangeMaxQueryProblem {
	static int n = 100001;
	static int m;
	static int [][] segtree;
	static int [] list;
	public static int gcf (int a, int b) {
		if (b == 0) return a;
		else return gcf(b, a%b);
	}
	public static void makesegtree(int ind, int le, int ri){
		if(le==ri){
				segtree[ind][0]=list[le];
				segtree[ind][1] = list[le];
				segtree[ind][2] = 1;
				return;
		}
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		makesegtree(left,le,mid);
		makesegtree(right,mid+1,ri);
		segtree[ind][0] = Math.min(segtree[left][0],segtree[right][0]);
		segtree[ind][1] = gcf(segtree[left][1], segtree[right][1]); 
		if (segtree[left][0] == segtree[right][0]) 
			segtree[ind][2] = segtree[left][2] + segtree[right][2];
		else if (segtree[left][0] < segtree[right][0])
			segtree[ind][2] = segtree[left][2];
		else
			segtree[ind][2] = segtree[right][2];
	}
	public static void update(int ind, int le, int ri, int loc, int newvalue){
		if(le==ri){
			segtree[ind][0] = newvalue;
			segtree[ind][1] = newvalue;
			segtree[ind][2] = 1;
			return;
		}
		int mid = (le + ri) / 2; 
		int left = ind + 1; 
		int right = ind + (mid - le + 1) * 2;
		if(loc <= mid){
			update(left, le, mid, loc, newvalue);
		}
		else{
			update(right, mid+1, ri, loc, newvalue);
		}
		segtree[ind][0]= Math.min(segtree[left][0],segtree[right][0]);
		segtree[ind][1] = gcf(segtree[left][1],segtree[right][1]);
		if (segtree[left][0] == segtree[right][0]) 
			segtree[ind][2] = segtree[left][2] + segtree[right][2];
		else if (segtree[left][0] < segtree[right][0])
			segtree[ind][2] = segtree[left][2];
		else
			segtree[ind][2] = segtree[right][2];
	}
	public static int query(int ind, int le, int ri, int l, int r){
		if (ri < l || le > r)return Integer.MIN_VALUE;
		if (le >= l && ri <= r)return segtree[ind][0];
		int mid = (le + ri) / 2; 
		int left = ind + 1; 
		int right = ind + (mid - le + 1) * 2;
		return Math.max(query(left,le,mid,l,r),query(right,mid+1,ri,l,r));
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		m = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		segtree = new int [n*2+1][3];
		int index = 0;
		st = new StringTokenizer(br.readLine());
		makesegtree(1, 1, n);
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().trim().charAt(0);
			int b = Integer.parseInt(st.nextToken());
			if (a == 'A')  {
				index ++;
				update(1, 1, n, index, b);
			}
			else if (a == 'Q') System.out.println(query(1, 1, n, index-b+1, index));
		}
	}
}

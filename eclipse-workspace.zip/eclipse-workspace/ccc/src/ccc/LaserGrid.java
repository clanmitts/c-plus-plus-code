package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class LaserGrid {
	public static int binarySearchr(int[] list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return l;
	}
	public static int binarySearchl(int[] list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return h;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int x = Integer.parseInt(st.nextToken());
		int y = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int c = Integer.parseInt(st.nextToken());
		int [] v = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			v[i] = Integer.parseInt(st.nextToken());
		}
		int [] h = new int [m+1];
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			h[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(v);
		Arrays.sort(h);
		int hv, lv, hh, lh;
		hv = binarySearchr(v, x+1, 1, n);
		lv = binarySearchl(v, x-1, 1, n);
		hh = binarySearchr(h, y+1, 1, m);
		lh = binarySearchl(h, y-1, 1, m);
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			if (true) System.out.println("y");
		}
	}
}

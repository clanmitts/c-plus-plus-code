package ccc;
	

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class ConnectingTwoBarns {
	static long binarySearchLeft(ArrayList<Integer> list, int l, int r, int x) {
	    if (r >= l) {
	        int mid = l + (r - l) / 2;
	        if (list.get(mid-1) == x)
	            return list.get(mid-1);
	        if (list.get(mid-1) > x)
	            return binarySearchLeft(list, l, mid - 1, x);
	        return binarySearchLeft(list, mid + 1, r, x);
	    }
	    if (r-1 == -1) return Integer.MAX_VALUE;
	    
	    return list.get(r-1);
	}
	static long binarySearchRight(ArrayList<Integer> list, int l, int r, int x) {
	    if (r >= l) {
	        int mid = l + (r - l) / 2;
	        if (list.get(mid-1) == x)
	            return list.get(mid-1);
	        if (list.get(mid-1) > x)
	            return binarySearchRight(list, l, mid - 1, x);
	        return binarySearchRight(list, mid + 1, r, x);
	    }
	    if (l-1 == list.size()) return Integer.MAX_VALUE;
	    return list.get(l-1);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int w = 1; w <= t; w++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			int m = Integer.parseInt(st.nextToken());
			ArrayList<ArrayList<Integer>> subset = new ArrayList<ArrayList<Integer>>();
			ArrayList<Integer>[] list = new ArrayList[n+1];
			for (int i = 1; i <= n; i++) list[i] = new ArrayList<Integer>();
			for (int i = 1; i <= m; i++) {
				st = new StringTokenizer(br.readLine());
				int a = Integer.parseInt(st.nextToken());
				int b = Integer.parseInt(st.nextToken());
				list[a].add(b);
				list[b].add(a);			
			}
			int index = -1;
			boolean [] vis = new boolean [n+1];
			int start = 0; int end = 0;
			for (int i = 1; i <= n; i++) {
				if (!vis[i]) {
					index ++;
					vis[i] = true;
					subset.add(new ArrayList<Integer>());
					subset.get(index).add(i);
					Queue<Integer> q = new LinkedList<Integer>();
					q.add(i);
					if (i == 1) start = index;
					if (i == n) end = index;
					while (!q.isEmpty()) {
						int cur = q.poll();
						for (int j: list[cur]) {
							if (!vis[j]) {
								vis[j] = true;
								subset.get(index).add(j);
								if (j == 1) start = index;
								if (j == n) end = index;
								q.add(j);
							}
						}
					}
				}
			}
			Collections.sort(subset.get(start));
			Collections.sort(subset.get(end));
			long min = Long.MAX_VALUE;
			for (ArrayList<Integer> i: subset) {
				long min1 = Integer.MAX_VALUE;
				long min2 = Integer.MAX_VALUE;
				for (int j: i) {
					min1 = Math.min(min1, Math.abs(binarySearchLeft(subset.get(start), 1, subset.get(start).size(), j)-j));
					min1 = Math.min(min1, Math.abs(binarySearchRight(subset.get(start), 1, subset.get(start).size(), j)-j));
					min2 = Math.min(min2, Math.abs(binarySearchRight(subset.get(end), 1, subset.get(end).size(), j)-j));
					min2 = Math.min(min2, Math.abs(binarySearchLeft(subset.get(end), 1, subset.get(end).size(), j)-j));
				}
				min = Math.min(min, (min1*min1) + (min2*min2));
			}
			System.out.println(min);
		}
	}
}

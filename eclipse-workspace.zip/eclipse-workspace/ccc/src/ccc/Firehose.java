package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Firehose {
	static int [] house;
	static int h;
	public static int check(int x) {
		int count = Integer.MAX_VALUE;
		for (int i = 1; i <= h; i++) {
			int temp = 1;
			int l = i;
			int r = i;
			while (r < h+i) {
				if ((house[r]-house[l]+1)/2 <= x) {
					r++;
				}
				else {
					temp ++;
					l = r;
					r++;
				}
			}
			count = Math.min(count, temp);
		}
		int count2 = Integer.MAX_VALUE;
		for (int i = 1; i <= h; i++) {
			int temp = 1;
			int r = h+i;
			int l = h+i;
			while (l >= 1+i) {
				if ((house[r]-house[l]+1)/2 <= x) {
					l--;
				}
				else {
					temp ++;
					r = l;
					l--;
				}
			}
			count2 = Math.min(count2, temp);
		}
		return Math.min(count, count2);
	}
	public static int binarySearch(int[] list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return h;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		h = Integer.parseInt(st.nextToken());
		house = new int [2*h+1];
		Arrays.fill(house, Integer.MAX_VALUE);
		house[0] = 0;
		for (int i = 1; i <= h; i++) {
			st = new StringTokenizer(br.readLine());
			house[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(house);
		for (int i = 1; i <= h; i++) {
			house[h+i] = 1000000 + house[i];
		}
		st = new StringTokenizer(br.readLine());
		int k = Integer.parseInt(st.nextToken());
		if (h <= k) System.out.println(0);
		else {
			int l = 1;
			int r = 1000000;
			int min = Integer.MAX_VALUE;
			while (l <= r) {
				int mid = l + ((r - l) / 2);
				int dis = check(mid);
				if (dis <= k) {
					min = mid;
					r = mid-1;
					if (check(mid-1) > k) break;
				}
				else {
					l = mid+1;
				}
			}
			System.out.println(min);
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsAverage3 {
	static int n, x;
	static int [] list;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st= new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		x = Integer.parseInt(st.nextToken());
		list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) list[i] = x-Integer.parseInt(st.nextToken());
		long [][] dp = new long [n+1][10000];
		dp[0][5000] = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 100; j <= 9900; j++) {
				dp[i][j] += dp[i-1][j];
				dp[i][j+list[i]] += dp[i-1][j];
			}
		}
		System.out.println(dp[n][5000]-1);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class GrassPlanting4 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [100001];
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			list[Integer.parseInt(st.nextToken())] ++;
			list[Integer.parseInt(st.nextToken())] ++;
		}
		int count = 0;
		for (int i: list) {
			if (i > count) count = i;
		}
		System.out.println(count+1);
	}
}

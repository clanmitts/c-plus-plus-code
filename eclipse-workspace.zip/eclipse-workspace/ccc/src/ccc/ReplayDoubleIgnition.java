package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ReplayDoubleIgnition {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int m = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		ArrayList<Character> str = new ArrayList<Character>();
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(1);
		str.add('1');
		str.add('1');
		while (true) {
			list.add((list.get(list.size()-1) + list.get(list.size()-2))%m);
			for (int i = 0; i < Integer.toString(list.get(list.size()-1)).length(); i++) {
				str.add(Integer.toString(list.get(list.size()-1)).charAt(i));
			}
			if (list.get(list.size()-1) == 1 && list.get(list.size()-2) == 1) break;
		}
		int n = str.size()-2;
		for (int i = 0; i < q; i++) {
			st = new StringTokenizer(br.readLine());
			long temp = Long.parseLong(st.nextToken());
			temp--;
			temp = temp%n;
			System.out.println(str.get((int) temp));
		}
	}
}

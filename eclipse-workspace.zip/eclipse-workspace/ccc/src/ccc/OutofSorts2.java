package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class OutofSorts2 {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		end [] finished = new end [n+1];
		for (int i = 0; i <= n; i++) finished[i] = new end(0, 0);
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			finished[i].a = Integer.parseInt(st.nextToken());
			finished[i].b = i;
		}
		Arrays.sort(finished);
		int max = 0;
		for (int i = 1; i <= n; i++) {
			max = Math.max(finished[i].b - i, max);
		}
		System.out.println(max+1);
	}
	public static class end implements Comparable <end>{
		int a;
		int b;
		public end (int x, int y) {
			this.a = x;
			this.b = y;
		}
		public int getb() {
			return this.b;
		}
		public int geta() {
			return this.a;
		}
		public int compareTo(end x) {
			if (Integer.compare(a, x.a) == 0) {
				return Integer.compare(b, x.b);
			} else {
				return Integer.compare(a, x.a);
			}
		}
	}
}

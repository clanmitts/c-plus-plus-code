package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Cereal2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		boolean [] used = new boolean [m+1];
		int [][] cows = new int [n+1][2];
		int [] take = new int [m+1];
		Arrays.fill(take, Integer.MAX_VALUE);
		int [] ans = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			cows[i][0] = Integer.parseInt(st.nextToken());
			cows[i][1] = Integer.parseInt(st.nextToken());
		}
		take[cows[n][0]] = n;
		used[cows[n][0]] = true;
		ans[n] = 1;
		for (int i = n-1; i >= 1; i--) {
			ans[i] = ans[i+1];
			if (used[cows[i][0]]) {
				int temp = take[cows[i][0]];
				take[cows[i][0]] = i;
				int temp2;
				while (true) {
					if (take[cows[temp][0]] > temp) {
						temp2 = take[cows[temp][0]];
						take[cows[temp][0]] = temp;
						temp = temp2;
					}
					else {
						if (take[cows[temp][1]] == Integer.MAX_VALUE) {
							ans[i] ++;
							take[cows[temp][1]] = temp;
							used[cows[temp][1]] = true;
						}
						
						else if (take[cows[temp][1]] > temp) {
							temp2 = take[cows[temp][1]];
							take[cows[temp][1]] = temp;
							temp = temp2;
						}
						else break;
					}
				}
			}
			else {
				used[cows[i][0]] = true;
				take[cows[i][0]] = i;
				ans[i]++;
			}
		}
		for (int i = 1; i <= n; i++) System.out.println(ans[i]);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ScramblingSwaps {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int q = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		for (int i = 1; i <= n; i++)list[i] = i;
		int [] place = new int [n+1];
		for (int i = 1; i <= n; i++) place[i] = i;
		for (int i = 1; i <= q; i++) {
			st = new StringTokenizer(br.readLine());
			char temp = st.nextToken().trim().charAt(0);
			if (temp == 'E') {
				int a = Integer.parseInt(st.nextToken());
				int b = Integer.parseInt(st.nextToken());
				int temp2 = list[a];
				list[a] = list[b];
				list[b] = temp2;
				place[list[a]] = a;
				place[list[b]] = b;
			}
			else if (temp == 'B') {
				int a = Integer.parseInt(st.nextToken());
				int b = Integer.parseInt(st.nextToken());
				int temp2 = list[place[a]];
				list[place[a]] = list[place[a]];
				list[place[b]] = temp2;
				temp2 = place[a];
				place[a] = b;
				place[b] = temp2;
			}
			else if (temp == 'Q') {
				int [] temp2 = new int [n+1];
				for (int j = 1; j <= n; j++) temp2[j] = Integer.parseInt(st.nextToken());
				for (int j = 1; j <= n; j++) System.out.print(temp2[place[j]]);
				System.out.println();
			}
		}
	}
}

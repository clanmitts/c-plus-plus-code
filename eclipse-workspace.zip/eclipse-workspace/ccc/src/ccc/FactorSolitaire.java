package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FactorSolitaire {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		boolean [] pow = new boolean [24];
		for (int i = 0; i <= 23; i++) {
			if ((n&(int)Math.pow(2, i)) != 0) pow[i] = true;
		}
		int max = 0;
		for (int i = 0; i <= 23; i++) {
			if (pow[i]) max = i;
		}
		int num = (int)Math.pow(2, max);
		int sum = max;
		for (int i = 0; i < max; i++) {
			if (pow[i]) {
				sum += num/(int)Math.pow(2, i);
				num += (int)Math.pow(2, i);
			}
		}
		System.out.println(sum);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Sound {
	static StringTokenizer st;
	static BufferedReader br;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int c = Integer.parseInt(st.nextToken());
		Deque<Integer []> max = new LinkedList<Integer []>();
		Deque<Integer []> min = new LinkedList<Integer []>();
		int [] list = new int [n+1];
		ArrayList<Integer> works = new ArrayList<Integer>();
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		Integer [] temp = new Integer[2];
		for (int i = 1; i <= m; i++) {
			Integer maxtemp[] = new Integer[2];
			Integer mintemp[] = new Integer[2];
			while (!max.isEmpty() && list[i] >= max.getFirst()[0]) {
				max.removeFirst();
			}
			maxtemp[0] = list[i];
			maxtemp[1] = i;
			max.addFirst(maxtemp);
			while (!min.isEmpty() && list[i] <= min.getFirst()[0]) {
				min.removeFirst();
			}
			mintemp[0] = list[i];
			mintemp[1] = i;
			min.addFirst(mintemp);
		}
		if (max.getLast()[0] - min.getLast()[0] <= c) works.add(1);
		int index = 1;
		for (int i = m+1; i <= n; i++) {
			index++;
			if (min.getLast()[1] < index) min.removeLast();
			if (max.getLast()[1] < index) max.removeLast();
			Integer maxtemp[] = new Integer[2];
			Integer mintemp[] = new Integer[2];
			while (!max.isEmpty() && list[i] >= max.getFirst()[0]) {
				max.removeFirst();
			}
			maxtemp[0] = list[i];
			maxtemp[1] = i;
			max.addFirst(maxtemp);
			while (!min.isEmpty() && list[i] <= min.getFirst()[0]) {
				min.removeFirst();
			}
			mintemp[0] = list[i];
			mintemp[1] = i;
			min.addFirst(mintemp);
			if (max.getLast()[0] - min.getLast()[0] <= c) works.add(index);
			System.out.println(max.getLast()[0]);
			System.out.println(min.getLast()[0]);
			System.out.println(max.getLast()[0] - min.getLast()[0]);
			System.out.println(c);
		}
		if (works.size() > 0) for (int i: works) System.out.println(i);
		else System.out.println("NONE");
	}
}
package ccc;

import java.util.Scanner;

public class PaperPrinting3 {
	public static boolean fine = true;;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n;
		int m;
		n = input.nextInt();
		m = input.nextInt();
		int a;
		a = input.nextInt();
		int paperPrev; // how much paper was in the printer the last time we added or took away paper
		int prevAddition; // when we last added to took away paper
		int paperCur = 0; // how much paper we have currently
		paperPrev = n;
		prevAddition = 0;
		int x = 0;
		int y;
		for (int i = 1; i <= a; i++) {
			x = input.nextInt();
			y = input.nextInt();
			paperCur = paperPrev - (x-prevAddition);
			if (paperCur < 0) {
				System.out.println("The printer melts at " + (x + paperCur + 1) + " second(s).");
				fine = false;
				break;
			}
			paperCur += y;
			if (paperCur > m) {
				System.out.println("The printer jams at " + x + " second(s).");
				fine = false;
				break;
			}
			paperPrev = paperCur;
			prevAddition = x;
		}
		if (fine) {
			System.out.println("The printer melts at " + (x + paperCur + 1) + " seconds(s).");
		}
	}
}

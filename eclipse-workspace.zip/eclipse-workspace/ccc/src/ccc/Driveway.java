package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Driveway {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		Deque<String> d = new LinkedList<String>();
		for (int i = 0; i < t; i++) {
			st = new StringTokenizer(br.readLine());
			String a = st.nextToken().trim();
			String b = st.nextToken().trim();
			if (b.equals("in")) d.addLast(a);
			else {
				if (d.getLast().equals(a)) d.removeLast();
				else if (d.getFirst().equals(a) && m >= 1) {
					d.removeFirst();
					m --;
				}
			}
		}
		while (!d.isEmpty()) {
			System.out.println(d.getFirst());
			d.removeFirst();
		}
		
	}
}

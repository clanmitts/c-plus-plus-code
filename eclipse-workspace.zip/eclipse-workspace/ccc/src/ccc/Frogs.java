package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;

public class Frogs {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] bale = new int [n+1];
		int [] jump = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			bale[i] = Integer.parseInt(st.nextToken());
		}
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i <= n; i++) {
			jump[i] = Integer.parseInt(st.nextToken());
		}
		int [] ans = new int [n+1];
		ans[n] = -1;
		Stack<Integer> s = new Stack<Integer>();
		s.push(bale[n]);
		for (int i = n-1; i >= 1; i--) {
			while (!s.isEmpty() && s.peek() <= bale[i]) {
				s.pop();
			}
			ans[i] = s.isEmpty()? -1:s.peek();
			s.push(ans[i]);
		}
	}
}

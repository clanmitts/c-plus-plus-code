package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class CowFrisbee {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		point [] list = new point [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			list[i] = new point(temp, i);
		}
		Stack <point> s = new Stack<point>();
		long count = 0;
		s.add(list[1]);
		for (int i = 2; i <= n; i++) {
			while (!s.isEmpty()) { 
				count += (i-s.peek().ind+1);
				if (s.peek().num < list[i].num) {
					s.pop();
				}
				else {
					break;
				}
			}
			s.add(list[i]);
		}
		System.out.println(count);
	}
	public static class point {
		int num;
		int ind;
		public point (int x, int y) {
			num = x;
			ind = y;
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class TinCanTelephone {
	static int gcd(int a, int b){
	    if (b == 0)
	        return a;
	    return gcd(b, a % b);
	}
	 static int lcm(int a, int b) {
	        return (a / gcd(a, b)) * b;
	 }
	 static slope create(int x1, int y1, int x2, int y2) {
		int a = y1-y2;
		int b = x1-x2;
		int temp = gcd(a, b);
	    a /= temp;
	    b /= temp;
		temp = y1*b;
		int c1 = temp - (a*x1);
		int c2 = b;
	   	slope original = new slope(a, b, c1, c2, x1, x2, y1, y2);
	   	return original;
	}
	static boolean intersect(slope a, slope b) {
		if (a.a == b.a && b.a == b.b) {
			if (a.c1 == b.c1) {
				if ((b.x2 >= a.x1 && a.x2 >= b.x1) || (b.x2 <= a.x1 && a.x2 <= b.x1)) {
					return true;
				}
				if ((a.x2 >= b.x1 && b.x2 <= a.x1) || (a.x2 <= b.x1 && b.x2 <= a.x1)) {	
					return true;
				}
				if ((a.x2 >= b.x2 && b.x1 >= a.x1) || (a.x2 <= b.x2 && b.x1 <= a.x1)) {
					return true;
				}
				if ((a.x1 >= b.x1 && b.x2 >= a.x2) || (a.x1 <= b.x1 && b.x2 <= a.x2)) {
					return true;
				}
				return false;
			}
			return false;
		}
		if (a.b == 0) {
			a.a = 0;
			a.b = 1;
		}
		if (b.b == 0) {
			b.a = 0;
			b.b = 1;
		}
		int lcm = lcm(a.b, b.b);
		a.a *= (lcm/a.b);
		b.a *= (lcm/b.b);
		a.b = lcm;
		b.b = lcm;
		int lefta = a.a-b.a;
		int leftb = lcm;
		if (a.c2 == 0) {
			a.c1 = 0;
			a.c2 = 1;
		}
		if (b.c2 == 0) {
			b.c1 = 0;
			b.c2 = 1;
		}
		lcm = lcm(a.c2, b.c2);
		a.c1 *= (lcm/a.c2);
		b.c1 *= (lcm/b.c2);
		a.c2 = lcm;
		b.c2 = lcm;
		int righta = b.c1-a.c1;
		int rightb = lcm;
		double ans = (double)(righta) / (double)(rightb) * (double)(leftb) / (double)(lefta);
		if (((a.x1 <= ans && ans <= a.x2) || (a.x1 >= ans && ans >= a.x2)) || 
				((b.x1 <= ans && ans <= b.x2) || (b.x1 >= ans && ans >= b.x2))) {
			return true;
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int x1 = Integer.parseInt(st.nextToken());
		int y1 = Integer.parseInt(st.nextToken());
		int x2 = Integer.parseInt(st.nextToken());
		int y2 = Integer.parseInt(st.nextToken());
		slope original = create(x1, y2, x2, y2);
	   	int count = 0;
		st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			int m = Integer.parseInt(st.nextToken());
			int [][] list = new int [m+1][3];
			for (int j = 0; j < m; j++) {
				list[j][1] = Integer.parseInt(st.nextToken());
				list[j][2] = Integer.parseInt(st.nextToken());
			}
			list[m][1] = list[0][1];
			list[m][2] = list[0][2];
			for (int j = 0; j < m; j++) {
				slope test = create(list[j][1], list[j][2], list[j+1][1], list[j+1][2]);
				if (intersect(original, test)) {
					count ++;
					break;
				}
			}
		}
		System.out.println(count);
	}
	public static class slope  {
		int a;
		int b;
		int c1;
		int c2;
		int x1;
		int y1;
		int x2;
		int y2;
		public slope(int w, int x, int y, int z, int q, int r, int s, int t) {
			a = w;
			b = x;
			c1 = y;
			c2 = z;
			x1 = q;
			y1 = r;
			x2 = s;
			y2 = t;
		}
	}
}

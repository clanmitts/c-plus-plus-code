package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class GoodSamples3 {
	public static long triangle (int n) {
		long count = 0;
		for (int i = 1; i <= n; i++) count += i;
		return count;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		long k = Long.parseLong(st.nextToken());
		if (k < n || k > triangle(m) + (long)m*(n-m)) System.out.println(-1);
		else {
			int [] list = new int [n+1];
			long count = 1;
			list[1] = 1;
			int ind = 1;
			for (int i = 1; i < n-1; i++) {
				if (count+Math.min(m, ind+1)+(n-i-1) <= k) {
					count += Math.min(m, ind+1);
					list[i+1] = list[i]+1;
					ind ++;
				}
				else {
					count ++;
					list[i+1] = list[i];
					ind = 1;
				}
			}
			list[n] = list[n-(int)(k-count)];
			for (int i = 1; i <= n; i++) System.out.print(list[i]%m+1 + " ");
			System.out.println();
		}
		
	}
}

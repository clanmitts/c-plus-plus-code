package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsHistogram {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) list[i] = Integer.parseInt(st.nextToken());
		long min = Long.MAX_VALUE;
		int num = 0;
		for (int i = -100; i <= 100; i++) {
			long temp = 0;
			for (int j: list) {
				temp += (i-j) * (i-j);
			}
			if (temp < min) {
				min = temp;
				num = i;
			}
		}
		System.out.println(min);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MatrixOperation {
	static int n;
	static int [][] grid;
	static int [][] dis;
	public static int dfs(int i, int j) {
		if (dis[i][j] != -1) return dis[i][j];
		dis[i][j] = 0;
		if (i < n-1 && grid[i+1][j] < grid[i][j]) dis[i][j] = dfs(i+1, j) + 1;
		if (i > 0 && grid[i-1][j] < grid[i][j]) dis[i][j] = dfs(i-1, j)+1;
		if (j < n-1 && grid[i][j+1] < grid[i][j]) dis[i][j] = dfs(i, j+1) +1;
		if (j > 0 && grid[i][j-1] < grid[i][j]) dis[i][j] = dfs(i, j-1) + 1;
		return dis[i][j];
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		grid = new int [n][n];
		dis = new int [n+1][n+1];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 0; j < n; j++) {
				grid[i][j] = Integer.parseInt(st.nextToken());
				dis[i][j] = -1;
			}
		}
		int best = -1;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				best = Math.max(best, dfs(i, j));
			}
		}
		System.out.println(best);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Smarties {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		int [] m = new int [1000001];
		int count = 0;
		long sum = (long)(n)*((long)(n)+1)/2;
		int index = 1;
		for (int i = 1; i <= n; i++) {
			if (m[list[i]] == 0) count ++;
			m[list[i]] ++;
			while (count >= k) {
				if (m[list[index]] == 1) {
					m[list[index]] = 0;
					count --;
				}
				else {
					m[list[index]] --;
				}
				index ++;
			}
			sum -= (i-index+1);
		}
		System.out.println(sum);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class CounterfeitDetection {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		char [] list = st.nextToken().trim().toCharArray();
		int two = 0;
		int five = 0;
		for (char i: list) {
			if (i == '2') two += 1;
			else if (i == '5') five += 1;
		}
		System.out.println(two-five);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Segment {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int [] count = new int [26];
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		char [] list = st.nextToken().trim().toCharArray();
		for (int i = 0; i < n; i++) count[list[i]-97] ++;
		int counter = 0;
		for (int i = 0; i < 26; i++) {
			if (count[i]%2 == 1) counter ++;
		}
		System.out.println(Math.max(1, counter));
	}
}

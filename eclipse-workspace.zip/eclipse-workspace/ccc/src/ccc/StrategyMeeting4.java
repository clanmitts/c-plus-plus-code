package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class StrategyMeeting4 {
	public static int n;
	public static int [][] dp;
	public static ArrayList<Integer>[] list;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int q = 0; q < t; q++) {
			st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			dp = new int [n+1][(1 << n)];
			dp[1][1] = 1;
			list = new ArrayList[n+1];
			for (int i = 1; i <= n; i++) list[i] = new ArrayList<Integer>();
			for (int i = 1; i <= n; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 1; j <= n; j++) {
					int temp = Integer.parseInt(st.nextToken());
					if (temp == 1) list[j].add(i);
				}
			}
			for (int i = 1; i < (1 << n); i++) {
				for (int j = 0; j < n; j++) {
					if ((i & (1 << j)) > 0) {
						for (int k: list[j+1]) {
							if ((i & (1 << (k-1))) > 0) {
								dp[j+1][i] += dp[k][i - (1 << j)];
							}
						}
					}
				}
			}
			int sum = 0;
			for (int i = 1; i < (1 << n); i++) {
				sum += dp[n][i];
			}
			System.out.println(sum);
		}
	}
}

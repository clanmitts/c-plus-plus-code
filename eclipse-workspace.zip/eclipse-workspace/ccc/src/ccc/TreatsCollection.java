package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class TreatsCollection {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		ArrayList<Long> neg = new ArrayList<Long>();
		ArrayList<Long> pos = new ArrayList<Long>();
		neg.add((long) 0);
		pos.add((long) 0);
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			long a = Long.parseLong(st.nextToken());
			if (a <= 0) neg.add(Math.abs(a));
			else pos.add(a);
		}
		Collections.sort(neg);
		long min = Integer.MAX_VALUE;
		for (int i = 0; i < Math.min(pos.size(), k+1); i++) {
			if (k-i < neg.size()) min = Math.min(min, pos.get(i) + neg.get(k-i) + Math.min(pos.get(i), neg.get(k-i)));
		}
		System.out.println(min);
	}
}

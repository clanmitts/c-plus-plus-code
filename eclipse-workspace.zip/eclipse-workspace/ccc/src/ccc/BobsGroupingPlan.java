package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class BobsGroupingPlan {
	public static int choose(int n) {
		int temp = (n-1)*n;
		temp /= 2;
		return (int) temp; 
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		boolean works = false;
		int groups = 0;
		for (int i = 2; i < 500; i++) {
			if (n == choose(i)) {
				groups = i;
				works = true;
			}
		}
		ArrayList<Integer> [] list = new ArrayList[groups+1];
		for (int i = 1; i <= groups; i++) list[i] = new ArrayList<Integer>();
		if (works) {
			int count = 1;
			System.out.println("Yes");
			System.out.println(groups);
			for (int i = 1; i < groups; i++) {
				for (int j = i+1; j <= groups; j++) {
					list[i].add(count);
					list[j].add(count);
					count ++;
				}
			}
			for (int i = 1; i <= groups; i++) {
				System.out.print(list[i].size() + " ");
				for (Integer j: list[i]) System.out.print(j + " ");
				System.out.println();
			}
		}
		else {
			System.out.println("No");
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class GoodTriplets4 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int c = Integer.parseInt(st.nextToken());
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(0);
		int [] count = new int [2000001];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (count[temp] == 0) list.add(temp);
			count[temp]++;
			count[temp+c]++;
		}
		for (int i = 1; i <= n; i++) {
			list.add(list.get(i)+c);
		}
		int sum = 0;
		Collections.sort(list);
		int [] psa = new int [list.size()];
		for (int i = 1; i < list.size(); i++) {
			psa[i] = psa[i-1]+count[list.get(i)];
		}
		int l = 1; int r = 1;
		while (list.get(l) < c) {
			if (r-l+1 < 3) r++;
			if (list.get(r)-list.get(l) < (c+1)/2) r++;
			else if (list.get(r)-list.get(l) >= (c+1)/2) {
				sum += count[list.get(r-1)]*(psa[r-2]-psa[l-1])*(psa[r-2]-psa[l-1]-1)/2;
				l++;
			}
		}
		// I deleted the part where I check for points opposite to each other
		System.out.println(n*(n-1)*(n-2)/6 - sum);
	}
}

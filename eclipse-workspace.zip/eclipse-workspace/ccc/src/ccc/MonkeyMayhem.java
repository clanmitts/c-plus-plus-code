package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MonkeyMayhem {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int [] row = new int [n+1];
		int [] column = new int [m+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (temp == -1);
			else if (i > temp) {
				row[i-temp] ++;
			}
		}
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= m; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (temp == -1);
			else if (i > temp) {
				column[i-temp]++;
			}
		}
		int count = 0;
		for (int i = 1; i <= Math.min(n, m); i++) {
			count += Math.min(row[i], column[i]);
		}
		System.out.println(count);
	}
}

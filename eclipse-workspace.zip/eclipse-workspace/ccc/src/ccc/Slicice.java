package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class Slicice {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		int [] p = new int [m+1];
		int [] amount = new int [m+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			p[temp] ++;
			amount[temp] ++;
		}
		for (int i = m-1; i >= 0; i--) p[i] += p[i+1];
		order [] b = new order [m+1];
		st = new StringTokenizer(br.readLine());
		order temp = new order(0, 0);
		temp.points = Integer.parseInt(st.nextToken());
		b[0] = temp;
		int [] point = new int [m+1];
		for (int i = 1; i <= m; i++) {
			temp = new order(0, 0);
			int thing = Integer.parseInt(st.nextToken());
			temp.size = i;
			temp.points = thing - b[i-1].points;
			b[i] = temp;
			point[i] = thing;
		}
		Arrays.sort(b, Collections.reverseOrder());
		for (int i = 0; i < k; i++) {
			for (int j = 0; j <= m; j++) {
				if (b[j].size != 0 && p[b[j].size] < p[b[j].size-1]) {
					p[b[j].size] ++;
					amount[b[j].size] ++;
					amount[b[j].size-1] --;
					break;
				}
			}
		}
		int count = 0;
		for (int i = 0; i <= m; i++) {
			count += (amount[i]*point[i]);
		}
		System.out.println(count);
	}
	public static class order implements Comparable<order> {
		int size, points;
		order(int x, int y) {
			size = x;
			points = y;
		}
		public int compareTo(order x) {
			return Integer.compare(points, x.points);
		}
	}
}

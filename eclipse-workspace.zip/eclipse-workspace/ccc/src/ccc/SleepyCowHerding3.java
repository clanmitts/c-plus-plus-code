package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class SleepyCowHerding3 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int [] list = new int [3];
		list[0] = Integer.parseInt(st.nextToken());
		list[1] = Integer.parseInt(st.nextToken());
		list[2] = Integer.parseInt(st.nextToken());
		Arrays.sort(list);
		int a = list[1]-list[0]-1;
		int b = list[2]-list[1]-1;
		if (Math.min(a, b) == 0) {
			if (a == b) {
				System.out.println(0);
				System.out.println(0);
			}
			else {
				System.out.println(Math.min(2, Math.max(a, b)));
				System.out.println(Math.max(a, b));
			}
		}
		else {
			System.out.println(Math.min(2, Math.min(a, b)));
			System.out.println(Math.max(a, b));
		}
	}
}

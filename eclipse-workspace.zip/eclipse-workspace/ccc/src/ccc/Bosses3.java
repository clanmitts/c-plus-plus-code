package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Bosses3 {
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int h = Integer.parseInt(st.nextToken());
		int p = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		int max = 0;
		for (int i: list) max = Math.max(max, i);
		int [] element = new int [(int)(1e6) + 2];
		long [] height = new long [(int)(1e6)+2];
		for (int i = 1; i <= n; i++) {
			element[list[i]] ++;
			height[list[i]] ++;
		}
		for (int i = 1; i <= 1e6; i++) height[i] *= i;
		for (int i = (int)(1e6)-1; i >= 1; i--) {
			element[i] += element[i+1];
			height[i] += height[i+1];
		}
		long min = Long.MAX_VALUE;
		for (int i = 0; i <= max; i++) {
			min = Math.min(min, (long)((long)(h)*(long)(i)) + (long)(p*(height[i+1] - (long)(i)*(long)(element[i+1]))));
		}
		System.out.println(min);
	}
}

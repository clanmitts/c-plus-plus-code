package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class ClosestCowWins {
	static int k, m, n;
	static one[] patch;
	static long [] patchPSA;
	static grass [] oneCow;
	static long [] twoCow;
	static int [] nhoj;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		k = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		n = Integer.parseInt(st.nextToken());
		patch = new one[k+1];
		patchPSA = new long [k+1];
		oneCow = new grass [m+1];
		twoCow = new long [m+1];
		nhoj = new int [m+1];
		for (int i = 0; i <= k; i++) patch[i] = new one(0, 0);
		for (int i = 1; i <= k; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			patch[i] = new one(a, b);
		}
		Arrays.sort(patch);
		for (int i = 1; i <= k; i++) patchPSA[i] = (patchPSA[i-1] + patch[i].tastiness);
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			nhoj[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(nhoj);
		for (int i = 0; i <= m; i++) {
			   oneCow[i] = new grass(i, 0);
			}
			for (int i = 1; i <= k; i++) {
			   if (patch[i].index > nhoj[1]) break;
			   oneCow[0].tastiness += patch[i].tastiness;
		}


		
		int r = 0;
		int l = 1;
		
		for (int i = 1; i < m; i++) {
			while (l <= k && patch[l].index <= nhoj[i]) {
				l++;
			}
			while (r+1 <= k && patch[r+1].index <= nhoj[i+1]) {
				r++;
			}
			twoCow[i] = (patchPSA[r]-patchPSA[l-1]);
			
			int left = l;
			for (int right = l; right <= r; right ++) {
				while (nhoj[i+1]-nhoj[i]<=2*patch[right].index-2*patch[left].index) {
					left ++;
				}
				oneCow[i].tastiness =Math.max(oneCow[i].tastiness, patchPSA[right]-patchPSA[left-1]);
			}
		}
		oneCow[m].tastiness = patchPSA[k]-patchPSA[r];

		long total = 0;
		PriorityQueue<grass> q = new PriorityQueue<grass>(Collections.reverseOrder());
		for (int i = 0; i <= m; i++) q.add(oneCow[i]);
		for (int i = 1; i <= n; i++) {
			grass temp = q.poll();
			total += temp.tastiness;
			if (temp.index != 0 && temp.index != m) {
				q.add(new grass (0, (oneCow[temp.index].tastiness-twoCow[temp.index]) * -1));
			}
		}
		System.out.println(total);
	}
	public static class grass implements Comparable<grass> {
		int index;
		long tastiness;
		public grass (int a, long l) {
			index = a;
			tastiness = l;
		}
		public int getIndex() {
			return index;
		}
		public long getTastiness() {
				return tastiness;
		}
		public int compareTo(grass o) {
			if (Long.compare(tastiness, o.tastiness) == 0) {
                return Integer.compare(index, o.index);
            } else {
                return Long.compare(tastiness, o.tastiness);
            }
        }
	}
	public static class one implements Comparable<one> {
		int index;
		long tastiness;
		public one (int a, long b) {
			index = a;
			tastiness = b;
		}
		public int getIndex() {
			return index;
		}
		public long getTastiness() {
				return tastiness;
		}
		public int compareTo(one o) {
			if (Integer.compare(index, o.index) == 0) {
                return Long.compare(tastiness, o.tastiness);
            } else {
                return Integer.compare(index, o.index);
            }
        }
	}
}

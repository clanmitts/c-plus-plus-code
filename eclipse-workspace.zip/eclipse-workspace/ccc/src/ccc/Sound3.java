package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Sound3 {
	static StringTokenizer st;
	static BufferedReader br;
	static int readInt() throws IOException{
	    int x = 0, c;
	    while((c = br.read()) != ' ' && c != '\n')
	        x = x * 10 + (c - '0');
	    return x;
	}

	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		int n = readInt();
		int m = readInt();
		int c = readInt();
		int [] max = new int [n+1];
		int [] min = new int [n+1];
		int maxa, maxb, mina, minb;
		int [] list = new int [n+1];
		boolean works = false;
		for (int i = 1; i <= n; i++) {
			list[i] = readInt();
		}
		maxa = 0;
		maxb = -1;
		mina = 0;
		minb = -1;
		for (int i = 1; i <= m; i++) {
			while (maxa <= maxb && list[i] >= list[max[maxb]]) {
				max[maxb] = 0;
				maxb--;
			}
			maxb++;
			max[maxb] = i;
			while (mina <= minb && list[i] <= list[min[minb]]) {
				minb--;
			}
			minb++;
			min[minb] = i;
		}
		if (list[max[maxa]] - list[min[mina]] <= c) {
			System.out.println(1);
			works = true;
		}
		for (int i = m+1; i <= n; i++) {
			if (max[maxa] <= i-m) maxa++;
			if (min[mina] <= i-m) mina++;
			while (maxa <= maxb && list[i] >= list[max[maxb]]) {
				max[maxb] = 0;
				maxb--;
			}
			maxb++;
			max[maxb] = i;
			while (mina <= minb && list[i] <= list[min[minb]]) {
				minb--;
			}
			minb++;
			min[minb] = i;
			if (list[max[maxa]] - list[min[mina]] <= c) {
				System.out.println(i-m+1);
				works = true;
			}
		}
		if (!works) System.out.println("NONE");
	}
}
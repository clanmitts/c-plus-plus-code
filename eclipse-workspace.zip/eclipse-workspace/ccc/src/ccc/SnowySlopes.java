package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

public class SnowySlopes {
	static int n;
	static int m;
	static long [][] list;
	static long [][] endPoints;
	static long[][] slopes;
	static HashSet<ArrayList<Integer>> vis = new HashSet<ArrayList<Integer>>();
	static long gcd(long a, long b) {
		  if (b == 0)
		    return a;
		  return (long) (gcd(b, a % b));
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		list = new long [n+1][m+1];
		endPoints = new long [n+1][3];
		slopes = new long [m+1][3];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			endPoints[i][1] = Integer.parseInt(st.nextToken());
			endPoints[i][2] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			if (b < 0) {
				b *= -1;
				a *= -1;
			}
			long temp = gcd(a, b);
			a /= temp;
			b /= temp;
			ArrayList<Integer> r = new ArrayList<Integer>();
			r.add(a);
			r.add(b);
			if (vis.add(r)) {
				slopes[i][1] = a;
				slopes[i][2] = b;
			}
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (slopes[j][1] == 0) continue;
				list[i][j] = endPoints[i][1]*slopes[j][1] - endPoints[i][2]*slopes[j][2];
			}
		}
		long count = 0;
		for (int i = 1; i <= m; i++) {
			if (slopes[i][1] == 0) continue;
			HashMap<Long, Integer> h = new HashMap<Long, Integer>();
			for (int j = 1; j <= n; j++) {
				if (!h.containsKey(list[j][i])) {
					h.put(list[j][i], 0);
				}
				h.put(list[j][i], h.get(list[j][i])+1);
			}
			for (HashMap.Entry<Long, Integer> j: h.entrySet()) {
				long temp = j.getValue();
				count += temp * (temp-1)/2;
			}
		}
		System.out.println(count);
	}
}

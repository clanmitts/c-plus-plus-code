package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;


public class CastleInvasion2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] column = new int [n+1];
		int [] row = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) column[i] = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) row[i] = Integer.parseInt(st.nextToken());
		Arrays.sort(column);
		Arrays.sort(row);
		int left = 0;
		long count = 0;
		long sum = 0;
		long ans = 0;
		for (int right = 1; right <= n; right++) {
			while (left+1 <= n && column[left+1] < row[right]) {
				left ++;
				count ++;
				sum += column[left];
			}
			ans += sum+row[right]*(n-count);
		}
		int maxc = 0;
		int maxr = 0;
		for (int i = 1; i <= n; i++) if (column[i] > maxc) maxc = column[i];
		for (int i = 1; i <= n; i++) if (row[i] > maxr) maxr = row[i];
		if (maxc == maxr) System.out.println(ans);
		else System.out.println(-1);
	}
}

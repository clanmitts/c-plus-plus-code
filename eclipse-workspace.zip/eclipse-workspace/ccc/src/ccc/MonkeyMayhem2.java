package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

public class MonkeyMayhem2 {
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		HashMap<Integer, Integer> row = new HashMap<Integer, Integer>();
		HashMap<Integer, Integer> column = new HashMap<Integer, Integer>();
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (temp != -1) {
				temp = i-temp;
				if (row.containsKey(temp)) row.put(temp, row.get(temp)+1);
				else row.put(temp, 1);
			}
		}
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= m; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (temp != -1) {
				temp = i-temp;
				if (column.containsKey(temp)) column.put(temp, column.get(temp)+1);
				else column.put(temp, 1);
			}		
		}
		int count = 0;
		ArrayList<Integer> list = new ArrayList<Integer>();
		row.forEach((k, v) -> {
			if (column.containsKey(k)) {
				list.add(Math.min(column.get(k), v));
			}
		});
		for (int i: list) count += i;
		System.out.println(count);
	}
}

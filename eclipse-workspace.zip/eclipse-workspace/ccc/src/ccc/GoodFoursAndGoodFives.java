package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class GoodFoursAndGoodFives {
	public static void main(String[]args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int count = 0;
		int four = 0;
		while (four <= n) {
			if ((n-four)%5 == 0) count ++;
			four += 4;
		}
		System.out.println(count);
	}
}

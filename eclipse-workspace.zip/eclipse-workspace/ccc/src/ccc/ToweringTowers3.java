package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Deque;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class ToweringTowers3 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		Deque<int []> d = new LinkedList<int []>();
		int [] temp = {list[1], 1};
		d.addFirst(temp);
		System.out.print(0 + " ");
		for (int i = 2; i <= n; i++) {
			if (d.getLast()[0] <= list[i]) {
				System.out.print(i-1 + " ");
				d = new LinkedList<int []>();
				int [] temp2 = {list[i], i};
				d.addFirst(temp2);
			}
			else {
				while (list[i] >= d.getFirst()[0]) {
					d.removeFirst();
				}
				System.out.print(i-d.getFirst()[1] + " ");
				int[] temp2 = {list[i], i};
				d.addFirst(temp2);
			}
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FastExponents {
	static boolean isPowerOfTwo(long n)
    {
        return ((n&(n-1)) == 0);
    }
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		long n = Long.parseLong(st.nextToken());
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			Long temp = Long.parseLong(st.nextToken());
			if (isPowerOfTwo(temp)) System.out.println("T");
			else System.out.println("F");
		}
	}
}

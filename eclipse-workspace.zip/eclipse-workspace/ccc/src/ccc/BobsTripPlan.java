package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsTripPlan {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+2];
		int [] diff = new int [n+2];
		int total = 0;
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i<= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= n+1; i++) total += Math.abs(list[i]-list[i-1]);
		for (int i = 1; i <= n; i++) diff[i] = Math.abs(Math.abs(list[i+1]-list[i-1]) - 
				Math.abs(list[i]-list[i-1]) - Math.abs(list[i+1]-list[i]));
		for (int i = 1; i <= n; i++) {
			System.out.println(total - diff[i]);
		}
	}
}

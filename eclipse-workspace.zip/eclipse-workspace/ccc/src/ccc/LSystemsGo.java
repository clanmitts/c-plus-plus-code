package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class LSystemsGo {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		for (int q = 0; q < 10; q++) {
			st = new StringTokenizer(br.readLine());
			int r = Integer.parseInt(st.nextToken());
			int t = Integer.parseInt(st.nextToken());
			String a = st.nextToken().trim();
			String [][] list = new String[r][2];
			for (int i = 0; i < r; i++) {
				st = new StringTokenizer(br.readLine());
				list[i][0] = st.nextToken().trim();
				list[i][1] = st.nextToken().trim();
			}
			for (int i = 0; i < t; i++) {
				for (int j = 0; j < r; j++) {
					a = a.replaceAll(list[j][0], list[j][1]);
				}
				System.out.println(a);
			}
			System.out.print(a.charAt(0));
			System.out.print(a.charAt(a.length()-1));
			System.out.print(" ");
			System.out.println(a.length());
		}
	}
}

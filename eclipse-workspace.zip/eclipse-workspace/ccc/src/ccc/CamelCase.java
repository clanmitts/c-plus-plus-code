package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class CamelCase {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		String [] words = new String [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			words[i] = st.nextToken().trim();
		}
		for (int i = 0; i < 10; i++) {
			st = new StringTokenizer(br.readLine());
			String str = st.nextToken().trim();
			int [][] dp = new int [n+1][str.length()+1];
			Arrays.fill(dp[0], 10000);
			for (int j = 1; j <= n; j++) {
				for (int k = 1; k <= str.length(); k++) {
					if (k-words[j].length() >= 0 && 
							str.substring(k-words[j].length(), k).equals(words[j])) {
						dp[j][k] = Math.min(dp[j-1][k], dp[j-1][k-words[j].length()]+1);
					}
					else {
						dp[j][k] = dp[j-1][k];
					}
				}
			}
			System.out.println(dp[n][str.length()]-1);
		}
	}
}

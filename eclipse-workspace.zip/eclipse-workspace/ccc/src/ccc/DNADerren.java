package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class DNADerren {
	static char [] letter = {'A', 'E', 'I', 'O', 'U'};
	public static boolean contains(char a) {
		for (char i: letter) if (a == i) return true;
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		String list = st.nextToken().trim();
		ArrayList<Integer> point = new ArrayList<Integer>();
		point.add(0);
		for (int i = 1; i < list.length(); i++) {
			if ((contains(list.charAt(i)) && contains(list.charAt(i-1)) ||
					!contains(list.charAt(i)) && !contains(list.charAt(i-1)))) point.add(i);
		}
		for (int i = 1; i < point.size(); i++) {
			System.out.print(list.substring(point.get(i-1), point.get(i)) + " ");
		}
		System.out.println(list.substring(point.get(point.size()-1)));
	}
}

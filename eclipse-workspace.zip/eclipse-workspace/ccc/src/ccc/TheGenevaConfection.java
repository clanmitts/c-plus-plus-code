package ccc;

import java.util.Scanner;
import java.util.Stack;

public class TheGenevaConfection {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	    int tt; 
	    tt = input.nextInt();
	    for (int j = 1; j <= tt; j++) {
	        int n; 
	        n = input.nextInt();
	        Stack<Integer> branch = new Stack<Integer>();
	        Stack <Integer> mountain = new Stack<Integer>();
	        int target = 1;
	        for(int i = 0; i < n; ++i) {
	            int a; 
	            a = input.nextInt();
	            mountain.push(a);
	        }
		    while(!mountain.empty() || !branch.empty()){
	            if(!mountain.empty() && mountain.peek() == target){
	                mountain.pop();
	                if(target < n)
	                    target++;
	            }
	            else if (!branch.empty() && branch.peek() == target)
	            {
	                branch.pop();
	                if(target < n)
	                    target++;
	            }
	            else if(mountain.size() > 1){
	                branch.push(mountain.peek());
	                mountain.pop();
	            }
	            else
	            {
	                System.out.println("N");
	                break;
	            }
		    }
	        if(target == n)
	        {
	            System.out.println("Y");
	        }
	    }
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class InterpretiveArt2 {
	public static boolean works(ArrayList<Integer> a, ArrayList<Integer>b, int n) {
		for (int i = 0; i < a.size(); i++) {
			if (a.get(i) < b.get(i)) return false;
		}
		return true;
	}
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] a = new int [n+1];
		int [] b = new int [n+1];
		ArrayList<Integer> wherea = new ArrayList<Integer>();
		ArrayList<Integer> whereb = new ArrayList<Integer>();
		ArrayList<int []> stroke = new ArrayList<int []>();
		ArrayList<Integer> clumps = new ArrayList<Integer>();
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) a[i] = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) b[i] = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) 
			if (a[i] == 0) wherea.add(i);
		for (int i = 1; i <= n; i++)
			if (b[i] == 0) whereb.add(i);
		for (int i = 1; i <= n; i++) {
			int count = 0;
			if (b[i] == 0) count ++;
			else if (i != 1) clumps.add(count);
		}
		if (works(wherea, whereb, n)) {
			int [] temp = new int [2];
			for (int i = 1; i <= n; i++) {
				
			}
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Palindrome {
	static char [] notReverse, reverse;
	static int n;
	static int [][] dp;
	public static int longestCommonSubsequence (char [] a, char [] b, int x, int y) {
		if (dp[x][y] != -1) return dp[x][y];
		if (x == 0 || y == 0) return 0;
		if (a[x-1] == b[y-1]) {
			dp[x][y] = 1+longestCommonSubsequence(a, b, x-1, y-1);
			return dp[x][y];
		}
		else {
			dp[x][y] = Math.max(longestCommonSubsequence(a, b, x, y-1), 
					longestCommonSubsequence(a, b, x-1, y));
			return dp[x][y];
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		dp = new int [n+1][n+1];
		for (int i = 0; i <= n; i++) Arrays.fill(dp[i], -1);
		st = new StringTokenizer(br.readLine());
		notReverse = new char[n+1];
		reverse = new char[n+1];
		notReverse = st.nextToken().trim().toCharArray();
		for (int i = 0; i < n; i++) {
			reverse[i] = notReverse[n-i-1];
		}
		int lcs = longestCommonSubsequence(reverse, notReverse, n, n);
		System.out.println(n-lcs);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class MultiplayerMoo {
	static int n;
	static int [][] grid = new int [252][252];
	static int [] x = {1, -1, 0, 0};
	static int [] y = {0, 0, 1, -1};
	static int [][][] clump = new int [252][252][2];
	static int ind = 0; 
	static boolean [][] vis = new boolean [252][252];
	static ArrayList<Integer>[] adj = new ArrayList[62502];
	static int [] size = new int [62502];
	static boolean [] used = new boolean [62502];
	static int [] id = new int [62502];
	static HashMap<Integer, ArrayList<Integer>>[] m = new HashMap[62502];
	static HashSet<edge> s = new HashSet<edge>();
	static int ans = 0;
	public static void explore (int a, int b) {
		Queue<int []> q = new LinkedList<int []>();
		int [] temp = new int [2];
		vis[a][b] = true;
		temp[0] = a;
		temp[1] = b;
		q.add(temp);
		while (!q.isEmpty()) {
			int [] cur = q.poll();
			for (int i = 0; i < 4; i++) {
				if (!vis[cur[0] + x[i]][cur[1] + y[i]]) {
					if (grid[cur[0] + x[i]][cur[1] + y[i]] ==
							grid[cur[0]][cur[1]]) {
						vis[cur[0] + x[i]][cur[1] + y[i]] = true;
						clump[cur[0] + x[i]][cur[1] + y[i]][0] = ind;
						clump[cur[0] + x[i]][cur[1] + y[i]][1] = clump[cur[0]][cur[1]][1];
						size[ind]++;
						int [] temp2 = new int [2];
						temp2[0] = cur[0] + x[i];
						temp2[1] = cur[1] + y[i];
						q.add(temp2);
					}
				}
				else if (vis[cur[0] + x[i]][cur[1] + y[i]]) {
					if (grid[cur[0] + x[i]][cur[1] + y[i]] !=
							grid[cur[0]][cur[1]]) {
						adj[clump[cur[0] + x[i]][cur[1] + y[i]][0]].add(clump[cur[0]][cur[1]][0]);
						adj[clump[cur[0]][cur[1]][0]].add(clump[cur[0] + x[i]][cur[1] + y[i]][0]);
					}
				}
			}
		}
	}
	public static void one() {
		int max = 0;
		for (int i = 1; i <= ind; i++) {
			max = Math.max(max, size[i]);
		}
		System.out.println(max);
	}
	public static void two() {
		edge temp;
		for (int i = 1; i <= ind; i++) {
			for (int j: adj[i]) {
				temp = new edge(i, j);
				if (s.add(temp)) {
					int a = id[i];
					int b = id[j];
					int sum = 0;
					Queue<Integer> q = new LinkedList<Integer>();
					q.add(i);
					HashSet<Integer> vis = new HashSet<Integer>();
					vis.add(i);
					while (!q.isEmpty()) {
						int cur = q.poll();
						sum += size[cur];
						if (m[cur].containsKey(a)) {
							for (int k: m[cur].get(a)) {
								if (vis.add(k)) {
									q.add(k);
									edge temp2 = new edge (cur, k);
								}
							}
						}
						if (m[cur].containsKey(b)) {
							for (int k: m[cur].get(b)) {
								if (vis.add(k)) {
									q.add(k);
									edge temp2 = new edge (cur, k);
								}
							}
						}
					}
					ans = Math.max(ans, sum);
				}
			}
		}
		System.out.println(ans);
	}
	public static class edge {
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + a;
			result = prime * result + b;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			edge other = (edge) obj;
			if (a != other.a)
				return false;
			if (b != other.b)
				return false;
			return true;
		}
		int a;
		int b;
		public edge (int d, int f) {
			a = Math.min(d, f);
			b = Math.max(d, f);
		}
		public int geta () {
			return this.a;
		}
		public int getb () {
			return b;
		}
	}
	public static void main(String[] args) throws IOException {
		for (int i = 1; i <= 62500; i++) {
			adj[i] = new ArrayList<Integer>();
		}
		Arrays.fill(size, 1);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= n; j++) {
				grid[i][j] = Integer.parseInt(st.nextToken())+1;
			}
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (!vis[i][j]) {
					ind ++;
					clump[i][j][0] = ind;
					clump[i][j][1] = grid[i][j];
					id[ind] = grid[i][j];
					explore(i, j);
				}
			}
		}
		for (int i = 1; i <= ind; i++) {
			m[i] = new HashMap<Integer, ArrayList<Integer>>();
		}
		for (int i = 1; i <= ind; i++) {
			for (int j: adj[i]) {
				if (!m[i].containsKey(id[j])) {
					m[i].put(id[j], new ArrayList<Integer>());
				}
				m[i].get(id[j]).add(j);
			}
		}
		one();
		two();
	}
}

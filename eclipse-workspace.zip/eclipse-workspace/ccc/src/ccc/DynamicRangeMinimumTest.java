package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DynamicRangeMinimumTest {
	public static int [] segtree;
	public static int [] list;
	public static void makesegtree(int ind, int le, int ri){
		if(le==ri){
				segtree[ind]=list[le];
				return;
		}
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		makesegtree(left,le,mid);
		makesegtree(right,mid+1,ri);
		segtree[ind]= Math.min(segtree[left],segtree[right]);
	}
	public static void update(int ind, int le, int ri, int loc, int newvalue){
		if(le==ri){
			segtree[ind]=newvalue;
			return;
		}
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		if(loc<=mid){
			update(left,le,mid,loc,newvalue);
		}
		else{
			update(right,mid+1,ri,loc,newvalue);
		}
		segtree[ind]= Math.min(segtree[left],segtree[right]);
	}
	public static int query(int ind, int le, int ri, int l, int r){
		if(ri < l || le > r)return Integer.MAX_VALUE;
		if(le >= l && ri <= r)return segtree[ind];
		int mid=(le+ri)/2; 
		int left=ind+1; 
		int right=ind+(mid-le+1)*2;
		return Math.min(query(left,le,mid,l,r),query(right,mid+1,ri,l,r));
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		segtree = new int [2*n];
		list = new int [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = Integer.parseInt(st.nextToken());
		}
		makesegtree(1, 1, n);
		for (int i = 1; i <= m; i++) {
			st = new StringTokenizer(br.readLine());
			char a = st.nextToken().trim().charAt(0);
			if (a == 'Q') {
				int b = Integer.parseInt(st.nextToken())+1;
				int c = Integer.parseInt(st.nextToken())+1;
				System.out.println(query(1, 1, n, b, c));
			}
			else if (a == 'M') {
				int b = Integer.parseInt(st.nextToken())+1;
				int c = Integer.parseInt(st.nextToken());
				update(1, 1, n, b, c);
			}
		}
	}
}

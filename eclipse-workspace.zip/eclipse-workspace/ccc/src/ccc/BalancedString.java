package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class BalancedString {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner scan = new Scanner(System.in);
		char [] list = scan.nextLine().trim().toCharArray();
		int counta = 0;
		int countb = 0;
		for (char i: list) {
			if ('a' <= i && i <= 'z') counta ++;
			else if ('A' <= i && i <= 'Z') countb ++;
		}
		if (counta == countb) System.out.println("YES");
		else System.out.println("NO");
	}
}

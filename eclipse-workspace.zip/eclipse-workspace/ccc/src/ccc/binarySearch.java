package ccc;

public class binarySearch {
	public static int binarySearchr(int[] list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return l;
	}
	public static int binarySearchl(int[] list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return h;
	}
}

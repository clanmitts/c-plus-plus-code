package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BinaryIndexedTree2d {
	static int [][] bit;
	static int n;
	public static void update(int x, int y, int v) {
		for(;x<=n;x+=x&-x){
			for(int tey=y;tey<=n;tey+=tey&-tey){
				bit[x][tey]+=v;
			}
		}
	}
	public static int freqTo(int x, int y) {
		int val=0;
		for(;x>0;x-=x&-x){
			for(int tey=y;tey>0;tey-=tey&-tey){
				val+=bit[x][tey];
			}
		}
		return val;

	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		st.nextToken();
		n = Integer.parseInt(st.nextToken());
		bit = new int [n+1][n+1];
		while (true) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			if (a == 3) break;
			else if (a == 1) {
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				int v = Integer.parseInt(st.nextToken());
				update(x+1, y+1, v);
			}
			else if (a == 2) {
				int l = Integer.parseInt(st.nextToken());
				int b = Integer.parseInt(st.nextToken());
				int r = Integer.parseInt(st.nextToken());
				int t = Integer.parseInt(st.nextToken());
				System.out.println(freqTo(r+1, t+1) - 
					freqTo(l, t+1) - freqTo(r+1, b) + freqTo(l, b));
			}
			
		}
	}
}

package ccc;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class Main {
	public static void main(String[] args) {
		for (int i = 1; i <= 10000; i++) {
			int count = 0;
			for (int j = 1; j <= i; j++) {
				if (i%j == 0) count ++;
			}
			if (i == 272) System.out.println(count);
			if (count == 5) System.out.println(i);
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class TinCanTelephone2 {
    public static void main (String[] args)throws IOException{
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    	StringTokenizer st = new StringTokenizer(br.readLine());
    	int x1 = Integer.parseInt(st.nextToken());
    	int y1 = Integer.parseInt(st.nextToken());
    	int x2 = Integer.parseInt(st.nextToken());
    	int y2 = Integer.parseInt(st.nextToken());
    	st = new StringTokenizer(br.readLine());
    	int n = Integer.parseInt(st.nextToken());
    	int count = 0;
    	for (int i = 0 ; i < n ; i++) {
    		st = new StringTokenizer(br.readLine());
    		boolean works = false;
    		int m = Integer.parseInt(st.nextToken());
    		int [][] list = new int [m+1][3];
    		for (int j = 0 ; j < m; j++){
    			list[j][1] = Integer.parseInt(st.nextToken());
    			list[j][2] = Integer.parseInt(st.nextToken());
    		}
    		list[m][1] = list[0][1];
    		list[m][2] = list[0][2];
    		for (int j = 0; j < m; j++) {
    			if (intersect(x1, y1, x2, y2, list[j][1], list[j][2], list[j+1][1], list[j+1][2])) {
    				works = true;
    			}
    		}
    		if (works) count ++;
    	}
    	System.out.println(count);
    }


    public static boolean intersect (int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
    	double a1, a2, b1, b2, x, y;
    	if (x1 == x2) {
    		a1 = Double.MAX_VALUE;
    		b1 = 0;
    	}
    	else {
    		a1 = (y1 - y2) / (x1 - x2);
    		b1 = -a1 * x2 + y2;
    	}
    	if (x3 == x4){
    		a2 = Double.MAX_VALUE;
    		b2 = 0;
    	}
    	else{
    		a2 = (y3 - y4) / (x3 - x4);
    		b2 = -a2 * x4 + y4;
    	}
    	if (a1 == a2) {
    		if (a1 != Double.MAX_VALUE && a2 != Double.MAX_VALUE) {
    			return b1 == b2 && (between(x3, x1, x2) || between(x4, x1, x2));
    		}
    		else {
    			return x1 == x3 && (between(y3, y1, y2) || between(y4, y1, y2));
    		}
    	}
    	else {
    		if (a1 != Double.MAX_VALUE && a2 != Double.MAX_VALUE) {
    			x = (b2 - b1) / (a1 - a2);
    			y = a1 * x + b1;
    			return between(x, x1, x2) && between(y, y1, y2) && between(x, x3, x4) && between(y, y3, y4);
    		}
    		else{
    			if (a1 == Double.MAX_VALUE){
    				x = x1;
    				y = a2 * x + b2;
    			}
    			else{
    				x = x3;
    				y = a1 * x + b1;
    			}
    			return between(x, x1, x2) && between(y, y1, y2) && between(x, x3, x4) && between(y, y3, y4);
    		}
    	}
    }
    public static boolean between (double x, int a, int b) {
    	return (x >= a && x <= b) || (x <= a && x >= b);
    }
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class ColourtheFlag {
	// white is 0 and red is 1
	static int n, m;
	static char [][] list;
	static Queue<int [] > q;
	public static boolean works() {
		while (!q.isEmpty()) {
			int [] cur = q.poll();
			if (cur[2] == 0) {
				if (cur[0] != 0) {
					if (list[cur[0]-1][cur[1]] == 'W') return false;
					else if (list[cur[0]-1][cur[1]] == '.') {
						list[cur[0]-1][cur[1]] = 'R';
						int [] temp = {cur[0]-1, cur[1], 1};
						q.add(temp);
					}
				}
				if (cur[0] < n-1) {
					if (list[cur[0]+1][cur[1]] == 'W') return false;
					else if (list[cur[0]+1][cur[1]] == '.') {
						list[cur[0]+1][cur[1]] = 'R';
						int [] temp = {cur[0]+1, cur[1], 1};
						q.add(temp);
					}
				}
				if (cur[1] != 0) {
					if (list[cur[0]][cur[1]-1] == 'W') return false;
					else if (list[cur[0]][cur[1]-1] == '.') {
						list[cur[0]][cur[1]-1] = 'R';
						int [] temp = {cur[0], cur[1]-1, 1};
						q.add(temp);
					}
				}
				if (cur[1] < m-1) {
					if (list[cur[0]][cur[1]+1] == 'W') return false;
					else if (list[cur[0]][cur[1]+1] == '.') {
						list[cur[0]][cur[1]+1] = 'R';
						int [] temp = {cur[0], cur[1]+1, 1};
						q.add(temp);
					}
				}
			}
			else {
				if (cur[0] != 0) {
					if (list[cur[0]-1][cur[1]] == 'R') return false;
					else if (list[cur[0]-1][cur[1]] == '.') {
						list[cur[0]-1][cur[1]] = 'W';
						int [] temp = {cur[0]-1, cur[1], 0};
						q.add(temp);
					}
				}
				if (cur[0] < n-1) {
					if (list[cur[0]+1][cur[1]] == 'R') return false;
					else if (list[cur[0]+1][cur[1]] == '.') {
						list[cur[0]+1][cur[1]] = 'W';
						int [] temp = {cur[0]+1, cur[1], 0};
						q.add(temp);
					}
				}
				if (cur[1] != 0) {
					if (list[cur[0]][cur[1]-1] == 'R') return false;
					else if (list[cur[0]][cur[1]-1] == '.') {
						list[cur[0]][cur[1]-1] = 'W';
						int [] temp = {cur[0], cur[1]-1, 0};
						q.add(temp);
					}
				}
				if (cur[1] < m-1) {
					if (list[cur[0]][cur[1]+1] == 'R') return false;
					else if (list[cur[0]][cur[1]+1] == '.') {
						list[cur[0]][cur[1]+1] = 'W';
						int [] temp = {cur[0], cur[1]+1, 0};
						q.add(temp);
					}
				}
			}
		}
		return true;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		for (int w = 0; w < t; w++) {
			st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			m = Integer.parseInt(st.nextToken());
			list = new char [n][m];
			q = new LinkedList<int []>();
			for (int i = 0; i < n; i++) {
				st = new StringTokenizer(br.readLine());
				list[i] = st.nextToken().trim().toCharArray();
				for (int j = 0; j < m; j++) {
					if (list[i][j] == 'W') {
						int [] temp =  {i, j, 0};
						q.add(temp);
					}
					else {
						int [] temp = {i, j, 1};
						q.add(temp);
					}
				}
			}
			if (works()) {
				System.out.println("YES");
				for (char [] i: list) {
					for (char j: i) {
						System.out.print(j);
					}
					System.out.println();
				}
			}
			else {
				System.out.println("NO");
				for (char [] i: list) {
					for (char j: i) {
						System.out.print(j);
					}
					System.out.println();
				}
			}
		}
	}
}

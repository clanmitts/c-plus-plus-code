package ccc;

import java.util.*;
import java.io.*;
public class CamelCase3 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
        int n = readInt(); Set<String> set = new TreeSet();
        for(int i=1; i<=n; i++) set.add((readLine()));
        for(int t=1; t<=10; t++) {
            String s = readLine(); int dp[] = new int[s.length() + 1];
            Arrays.fill(dp, Integer.MAX_VALUE/2); dp[0] = 0;
            for(int j=0; j < s.length(); j++) {
                StringBuilder cur = new StringBuilder();
                for(int i=j; i < s.length(); i++) {
                    cur.append(s.charAt(i));
                    if(set.contains(cur.toString())) {
                        dp[i+1] = Math.min(dp[i+1], dp[j]+1);
                    }
                }
            }
            
            System.out.println(dp[s.length()] - 1);
        }
    }
    static long hash(String s) {
        long h = 0, base = 131;
        for(int i=0; i<s.length(); i++) {
            h = h*base + s.charAt(i);
        }
        return h;
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}
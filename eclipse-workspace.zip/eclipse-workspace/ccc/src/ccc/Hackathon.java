package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Hackathon {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		for (int i = 0; i < k; i++) {
			st = new StringTokenizer(br.readLine());
			double s = Integer.parseInt(st.nextToken());
			double t = Integer.parseInt(st.nextToken());
			double r = Integer.parseInt(st.nextToken());
			int hours = (int)(Math.ceil(n/s));
			hours += (int)(Math.floor((hours-1)/t)*r);
			System.out.println(hours);
		}
	}
}

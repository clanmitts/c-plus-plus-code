package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsReverseNumber {
	public static char [] reverse(char [] a, int n) {
		char[] b = new char[n]; 
        int j = n; 
        for (int i = 0; i < n; i++) { 
            b[j - 1] = a[i]; 
            j = j - 1; 
        } 
        return b;
        }
	public static void compare(char[] a, char[] b) {
		for (int i = a.length-1; i >= 0; i--) {
			if (a[i] < b[i]) {
				printthing(a);
				return;
			}
			else if (a[i] > b[i]) {
				printthing(b);
				return;
			}
		}
	}
	public static void printthing(char [] a) {
		long count = 0;
		reverse(a, a.length);
		for (int i = 0; i < a.length; i++) {
			count += ((a[i]-48)*Math.pow(10, i));
		}
		System.out.println(count);
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		char [] a = st.nextToken().trim().toCharArray();
		char [] b = st.nextToken().trim().toCharArray();
		if (b.length < a.length) printthing(b);
		else if (b.length > a.length) printthing(a);
		else compare(a, b);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ToweringTowers2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] towers = new int [n];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) towers[i] = Integer.parseInt(st.nextToken());
		int [] see = new int [n];
		int count = 0;
		for (int i = n-1; i >= 0; i--) {
			count = 0;
			for (int j = i-1; j >=0; j--) {
				count += 1;
				if (towers[j] > towers[i]) break;
			}
			see[i] = count;
		}
		for (int i = 0; i < n; i++) {
			System.out.print(see[i] + " ");
		}
		System.out.println();
	}
}

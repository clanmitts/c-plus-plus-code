package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class TheMostImportantSkillinBiology {
	public static void main(String[] args) throws IOException {
		BufferedReader br  = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [][] list = new int [n+2][3];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i][1] = Integer.parseInt(st.nextToken());
			list[i][2] = Integer.parseInt(st.nextToken());
		}
		list[n+1][1] = list[1][1];
		list[n+1][2] = list[1][2];
		int ans = 0;
		for (int i =1; i <= n; i++) {
			ans += (list[i][2]*list[i+1][1]);
			ans -= (list[i][1]*list[i+1][2]);
		}
		if (ans % 2 == 0) System.out.println(Math.abs(ans/2));
		else System.out.println(Math.abs(ans/2+1));
	}
}

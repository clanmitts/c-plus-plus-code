package ccc;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;

public class bfs {
	static ArrayList<Integer>[] arr = new ArrayList[101];
	static int prev;
	static int n;
	static Deque<Integer> q = new LinkedList();
	static int [] dis = new int [101];
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		n = input.nextInt();
		for (int i = 1;  i <= n; i++) arr[i] = new ArrayList<Integer>();
		for (int i = 1; i < n; i++) {
			int a = input.nextInt();
			int b = input.nextInt();
			arr[a].add(b);
			arr[b].add(a);
		}
		prev = 1;
		q.push(1);
		System.out.println(34324);
		while (!q.isEmpty()) {
			int cur = q.peekFirst();
			prev = cur;
			q.removeFirst();
			for (int i: arr[cur]) {
				if (i != cur) {
					dis[i] = dis[cur]+1;
					q.push(i);
				}
			}
		}
		System.out.println(dis[n]);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class ToweringTowers {
	static int n;
	static Integer [][] list;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new Integer [n+1][2];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i][0] = Integer.parseInt(st.nextToken());
		}
		for (int i = 1; i <= n; i++) {
			list[i][1] = i;
		}
		int sum = 0;
		int [] ans = new int [n+1];
		Stack<Integer []> s = new Stack<Integer []>();
		s.push(list[1]);
		for (int i = 2; i <= n; i++) {
			while (!s.isEmpty() && s.peek()[0] <= list[i][0]) {
				s.pop();
			}
			if (!s.isEmpty()) ans[i] = list[i][1]-s.peek()[1];
			else ans[i] = list[i][1];
			s.push(list[i]);
		}
		for (int i = 1; i <= n; i++) {
			System.out.print(ans[i] + " ");
		}
		System.out.println();
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class StringHashing {
	static long[] hsh, pw; static long mod = (long)(1e9+7);
	public static void main(String[] args) throws IOException { 
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		String s = st.nextToken().trim();
		String t = st.nextToken().trim();
		hsh = new long[s.length()+1]; pw = new long [s.length()+1];
		long hshT = 0, base = 131;
		hsh[0] = 0; pw[0] = 1;
		for (int i = 1; 1 <= s.length(); i++) {
			hsh[i] = (hsh[i-1]*base + s.charAt(i-1))%mod;
			pw[i] = pw[i-1]*base%mod;
		}
		for (int i = 0; i <t.length(); i++) {
			hshT = (hshT*base+t.charAt(i))%mod;
		}
		for (int i = 0; i+t.length() <= s.length(); i++) {
			if (getSubStringHash(i+1, i+t.length()) == hshT) {
				System.out.println(i); return;
			}
		}
		System.out.println(-1);
	}
	static long getSubStringHash(int l, int r) {
		return (hsh[r] - hsh[l-1]*pw[r-l+1]%mod + mod)%mod;
	}
}

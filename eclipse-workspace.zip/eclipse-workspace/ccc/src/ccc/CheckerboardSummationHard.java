package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class CheckerboardSummationHard {
	static int m, n;
	static long [][] bit;
	static long [][] list;
	public static void update(int x, int y, long l) {
		for(;x<=m;x+=x&-x){
			for(int tey=y;tey<=n;tey+=tey&-tey){
				bit[x][tey]+=l;
			}
		}
	}
	public static long freqTo(int x, int y) {
		long val=0;
		for(;x>0;x-=x&-x){
			for(int tey=y;tey>0;tey-=tey&-tey){
				val+=bit[x][tey];
			}
		}
		return val;

	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		m = Integer.parseInt(st.nextToken());
		n = Integer.parseInt(st.nextToken());
		bit = new long [m+1][n+1];
		list = new long [m+1][n+1];
		while (true) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			if (a == 0) break;
			else if (a == 1) {
				int r = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				int x = Integer.parseInt(st.nextToken());
				if ((r+c)%2 == 0) {
					update(r, c, x-list[r][c]);
					list[r][c] = x;
				}
				else {
					update(r, c, -list[r][c]-x);
					list[r][c] = -x;
				}
			}
			else if (a == 2) {
				int w = Integer.parseInt(st.nextToken());
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				int z = Integer.parseInt(st.nextToken());
				if ((w+x) % 2 == 0) {
					System.out.println(freqTo(y, z) - 
							freqTo(y, x-1) - freqTo(w-1, z) + freqTo(w-1, x-1));
				}
				else {
					System.out.println(-(freqTo(y, z) - 
							freqTo(y, x-1) - freqTo(w-1, z) + freqTo(w-1, x-1)));
				}
			}
		}
	}
}

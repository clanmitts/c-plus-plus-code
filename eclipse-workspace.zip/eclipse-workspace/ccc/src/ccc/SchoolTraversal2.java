package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SchoolTraversal2 {
	static int n;
	static int [] firstAppearance;
	static ArrayList<Integer> order;
	static ArrayList<int []>[] list;
	static Queue<int []> q;
	static boolean [] vis;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new ArrayList[n+1];
		firstAppearance = new int [n+1];
		order = new ArrayList<Integer>();
		for (int i = 1; i <= n; i++) {
			list[i] = new ArrayList<int []>();
		}
		for (int i = 1; i < n; i++) {
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int w = Integer.parseInt(st.nextToken());
			int[] temp = new int [2];
			temp[0] = a;
			temp[1] = w;
			list[b].add(temp);
			temp[0] = b;
			list[a].add(temp);
		}
		q = new LinkedList<int []>();
		vis = new boolean [n+1];
		int [] dis = new int [n+1];
		int []temp = new int [2];
		q.add(temp);
		while (!q.isEmpty()) {
			int [] cur = q.poll();
			
		}
	}
}

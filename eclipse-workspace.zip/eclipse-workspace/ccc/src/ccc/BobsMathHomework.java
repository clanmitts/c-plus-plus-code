package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BobsMathHomework {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [] list = new int [n+1];
		for (int i = 1; i <= n; i++) list[i] = i;
		for (int i = 1; i <= n; i++) list[i] += list[i-1];
		int index = 0;
		int count = 0;
		for (int i = 1; i <= n; i++) {
			while (list[i] - list[index] >= n) {
				if (list[i]-list[index] == n) count ++;
				index ++;
			}
		}
		System.out.println(count);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class StringFinding3 {
	public static long prefixHash[];
	public static long power[];
	public static long inv[];
	public static char [] s;
	public static char [] t;
	public static long fp (long a, long power) {
		long ans = 1;
		for (long i = 1; i <= power; i*= 2) {
			if ((power&i) > 0) ans = (long) (ans*a % (long)(1e9+7));
			a = a*a % (long)(1e9+7);
		}
		return ans;
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		s = st.nextToken().trim().toCharArray();
		st = new StringTokenizer(br.readLine());
		t = st.nextToken().trim().toCharArray();
		if (t.length > s.length) System.out.println(-1);
		else {
			prefixHash = new long[s.length];
			power = new long[s.length];
			inv = new long[s.length];
			prefixHash[0] = s[0]-'a'+1;
			power[0] = 1;
			inv[0] = 1;
			for (int i = 1; i < s.length; i++) {
				power[i] = power[i-1]*113 % (long)(1e9+7);
				prefixHash[i] = 
						(prefixHash[i-1] + (s[i]-'a'+1) 
						* power[i] % (long)(1e9+7)) % (long)(1e9+7);
				inv[i] = fp(power[i], (long)(1e9+5));
			}
			long tvalue = 0;
			long currentPower = 1;
			for (int i = 0; i < t.length; i++) {
				tvalue = (tvalue + (t[i]-'a'+1) * currentPower % (long)(1e9+7)) % (long)(1e9+7);
				currentPower = currentPower*113 % (long)(1e9+7);
			}
			boolean works = false;
			if (tvalue == ((prefixHash[t.length-1] + (long)(1e9+7)) * inv[0] % (long)(1e9+7))
					%(long)(1e9+7)) {
				System.out.println(0);
				works = true;
			}
			else {
				for (int i = 1; i <= s.length-t.length; i++) {
					if (tvalue == ((prefixHash[i+t.length-1] - prefixHash[i-1] + (long)(1e9+7))
							*inv[i] % (long)(1e9+7)) % (long)(1e9+7)) {
						System.out.println(i);
						works = true;
						break;
					}
				}
			}
			if (!works) System.out.println(-1);
		}
	}
}
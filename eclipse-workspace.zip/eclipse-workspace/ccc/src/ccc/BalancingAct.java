package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BalancingAct {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		for (int i = 0; i < 5; i++) {
			st = new StringTokenizer(br.readLine());
			boolean [] possible = new boolean [30*1000+1];
			possible[0] = true;
			int n = Integer.parseInt(st.nextToken());
			int total = 0;
			for (int j = 0; j < n; j++) {
				st = new StringTokenizer(br.readLine());
				int weight = Integer.parseInt(st.nextToken());
				total += weight;
				for (int k = possible.length-1-weight; k >= 0; k--) {
					possible[k+weight] |= possible[k];
				}
			}
			for (int j = total/2; j >= 0; j--) {
				if (possible[i]) {
					System.out.println(total-i*2);
					break;
				}
			}
		}
	}
}

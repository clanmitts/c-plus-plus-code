package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class AbsolutelyAcidic {
	public static HashMap<Integer, ArrayList<Integer>> sortbykey(HashMap<Integer, ArrayList<Integer>> map) {
        TreeMap<Integer, ArrayList<Integer>> sorted = new TreeMap<Integer, ArrayList<Integer>>(Collections.reverseOrder());
        sorted.putAll(map);
        map.putAll(sorted);
        return map; 
    }
	public static int max(ArrayList<Integer> list) {
		int max = 0;
		for (int i: list) max = Math.max(max, i);
		return max;
	}
	public static int min(ArrayList<Integer> list) {
		int min = Integer.MAX_VALUE;
		for (int i: list) min = Math.min(min, i);
		return min;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		boolean [] used = new boolean [1001];
		TreeMap<Integer, ArrayList<Integer>> h = new TreeMap<Integer, ArrayList<Integer>>(Collections.reverseOrder());
		HashMap<Integer, Integer> frequency = new HashMap<Integer, Integer>();
		int n = Integer.parseInt(st.nextToken());
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			int temp = Integer.parseInt(st.nextToken());
			if (!used[temp]) {
				used[temp] = true;
				frequency.put(temp, 1);
			}
			else {
				frequency.put(temp, frequency.get(temp)+1);
			}
		}
		for (Map.Entry mapElement : frequency.entrySet()) {
			int key = (int)mapElement.getKey();
            int value = (int)mapElement.getValue();
            if (h.containsKey(value)) {
            	ArrayList<Integer> temp = h.get(value);
            	temp.add(key);
            	h.put(value, temp);
            }
            else {
            	ArrayList<Integer> temp = new ArrayList<Integer>();
            	temp.add(key);
            	h.put(value, temp);
            }
        }
		if(h.size() == 1) {
			ArrayList<Integer> list = (ArrayList<Integer>) h.values().toArray()[0];
			System.out.println(max(list)-min(list));
		}
		else {
			ArrayList<Integer> one = (ArrayList<Integer>) h.values().toArray()[0];
			ArrayList<Integer> two = (ArrayList<Integer>) h.values().toArray()[1];
			int max1 = max(one);
			int max2 = max(two);
			int min1 = min(one);
			int min2 = min(two);
			System.out.println(Math.max(max1-min2, max2-min1));
		}
	}
}

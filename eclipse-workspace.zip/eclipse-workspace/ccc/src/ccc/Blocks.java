package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Blocks {
	static int n;
	static String [] list = new String [4];
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void func () throws IOException {
		st = new StringTokenizer(br.readLine());
		String str = st.nextToken().trim();
		for (int a = 0; a < 4; a++) {
			for (int i = 0; i <= 6; i++) {
				for (int j = 0; j <= 6; j++) {
					for (int k = 0; k <= 6; k++) {
						for (int l = 0; l <= 6; l++) {
							String temp = String.valueOf(list[a].charAt(i)) + String.valueOf(list[(a+1)%4].charAt(j)) + String.valueOf(list[(a+2)%4].charAt(k)) + String.valueOf(list[(a+3)%4].charAt(l));
							temp = temp.replaceAll(" ", "");

							if (temp.equals(str)) {
								System.out.println("YES");
								return;
							}
						}
					}
				}
			}
		}
		System.out.println("NO");
		return;
	}
	public static void main(String[] args) throws IOException {
		st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		for (int i = 0; i < 4; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = st.nextToken().trim()+" ";
		}
		for (int i = 1; i <= n; i++) {
			func();
		}
	}
}

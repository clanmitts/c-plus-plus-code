package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class TintedGlassWindow {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int t = Integer.parseInt(st.nextToken());
		int [][] list = new int [n+1][5+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i][1] = Integer.parseInt(st.nextToken());
			list[i][2] = Integer.parseInt(st.nextToken());
			list[i][3] = Integer.parseInt(st.nextToken());
			list[i][4] = Integer.parseInt(st.nextToken());
			list[i][5] = Integer.parseInt(st.nextToken());
		}
		int [][][] index = new int [4*n+1][3][3];
		for (int i = 1; i <= n; i += 4) {
			index[i][0][0] = list[i][1];
			index[i][1][0] = list[i][2];
			index[i][0][1] = list[i][5];
			index[i+1][0][0] = list[i][3]+1;
			index[i+1][1][0] = list[i][4];
			index[i+1][0][1] = -list[i][5];
			index[i+2][0][0] = list[i][3];
			index[i+2][1][0] = list[i][4]+1;
			index[i+2][0][1] = -list[i][5];
			index[i+3][0][0] = list[i][3]+1;
			index[i+3][1][0] = list[i][4]+1;
			index[i+3][0][1] = list[i][5];
		}
	}
}

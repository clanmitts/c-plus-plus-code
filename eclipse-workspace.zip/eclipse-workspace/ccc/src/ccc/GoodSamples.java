package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class GoodSamples {
	static int n, m, k;
	static ArrayList<Integer> sample = new ArrayList<Integer>();
	static ArrayList<Integer> add = new ArrayList<Integer>();
	static ArrayList<Integer> need = new ArrayList<Integer>();
	public static int binarySearchl(ArrayList<Integer> list, int n, int l, int h) {	    
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list.get(mid) < n) {
		    	l = mid + 1;
		    } 
		    else if (list.get(mid) > n) {
		    	h = mid - 1;
		    } 
		    else if (list.get(mid) == n) {
		    	return mid;
		    }
		}
		return h;
	}
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		k = Integer.parseInt(st.nextToken());
		add.add(0);
		need.add(0);
		add.add(1);
		for (int i = 2; i <= m; i++) {
			add.add((int) ((add.get(i-1)+i)%1e9));
		}
		int count = 0;
		int temp = k;
		while (temp != 0) {
			int temp2 = (binarySearchl(add, temp, 1, m));
			need.add(temp2);
			count += temp2;
			temp -= add.get(temp2);
		}
		if (n < add.get(need.get(1)) + need.size()-2) {
			System.out.println(-1);
		}
		else if (k < n) {
			System.out.println(-1);
		}
		else {
			for (int i = 1; i <= need.get(1); i++) {
				sample.add(i);
			}
			for (int i = 2; i <= need.size()-1; i++) {
				
			}
		}
	}
}

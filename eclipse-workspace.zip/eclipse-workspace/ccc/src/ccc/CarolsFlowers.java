package ccc;

import java.util.Arrays;
import java.util.Scanner;

public class CarolsFlowers {
	static long pow(long base, long exponent, long modulus) {
	    if (modulus == 1) {
	        return 0;
	    }
	    long c = 1;
	    for (int i = 0; i <= exponent-1; i++) 
	        c = (c * base) % modulus;
    return c;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int f;
		int n;
		f = input.nextInt();
		n = input.nextInt();
		int [] flower = new int [f+1];
		for (int i = 1; i <= f; i++) {
			flower[i] = input.nextInt();
		}
		Arrays.sort(flower);
		long total = 0;
		for (int i = n; i >= 1; i--) {
			total += (pow(flower[i], n-i+1, (long) (1e9 + 7)));
		}
		total %= (1e9+7);
		System.out.println(total);
	}
}

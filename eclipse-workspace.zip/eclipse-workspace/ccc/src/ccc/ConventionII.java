package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class ConventionII {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		cowTime [] list = new cowTime [n+1];
		for (int i = 0; i <= n; i++) list[i] = new cowTime(0, 0, 0);
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i].eatTime = Integer.parseInt(st.nextToken());
			list[i].arriveTime = Integer.parseInt(st.nextToken());
			list[i].seniority = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(list);
		int time = 0;
		int max = 0;
		int index = 2;
		PriorityQueue<cowSeniority> q = new PriorityQueue<cowSeniority>();
		cowSeniority temp= new cowSeniority(list[1].getEatTime(), list[1].getArriveTime(),
				list[1].getSeniority());
		q.add(temp);
		while (index <= n) {
			if (q.isEmpty()) {
				temp = new cowSeniority(list[index].getEatTime(), list[index].getArriveTime(),
						list[index].getSeniority());
				q.add(temp);
			}
			
		}
	}
	public static class cowTime implements Comparable<cowTime>{
		private Integer eatTime;
		private Integer arriveTime;
		private Integer seniority;
		public cowTime (int a, int b, int c ) {
			this.eatTime = a;
			this.arriveTime = b;
			this.seniority = c;
		}
		public Integer getEatTime() {
			return eatTime;
		}
		public Integer getArriveTime() {
			return arriveTime;
		}
		public Integer getSeniority() {
			return seniority;
		}
		public int compareTo (cowTime a) {
			return a.getArriveTime().compareTo(this.arriveTime);
		}
	}
	public static class cowSeniority implements Comparable<cowSeniority>{
		private Integer eatTime;
		private Integer arriveTime;
		private Integer seniority;
		public cowSeniority (int a, int b, int c ) {
			this.eatTime = a;
			this.arriveTime = b;
			this.seniority = c;
		}
		public Integer getEatTime() {
			return eatTime;
		}
		public Integer getArriveTime() {
			return arriveTime;
		}
		public Integer getSeniority() {
			return seniority;
		}
		public int compareTo (cowSeniority a) {
			return a.getSeniority().compareTo(this.seniority);
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class CompleteGraphBuilding {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		weight [] list = new weight [n+1];
		int originalWeight = 0;
		for (int i = 1; i <= n; i++) list[i] = new weight(0, 0, i, new ArrayList<Integer>());
		for (int i = 1; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int w = Integer.parseInt(st.nextToken());
			list[a].maxWeight = Math.max(list[a].maxWeight, w);
			list[b].maxWeight = Math.max(list[b].maxWeight, w);
			list[a].branches ++;
			list[b].branches ++;
			originalWeight +=w;
		}
	}
	public static class weight implements Comparable<weight>{
		int maxWeight;
		int branches;
		int index;
		ArrayList<Integer> original;
		public weight (int a, int b, int c, ArrayList<Integer> d) {
			maxWeight = a;
			branches = b;
			index = c;
			original = d;
		}
		public int getMaxWeight() {
			return maxWeight;
		}
		public int getBranches() {
			return branches;
		}
		public ArrayList<Integer> getoriginal() {
			return original;
		}
		public int compareTo(weight o) {
			if (Integer.compare(maxWeight, o.maxWeight) == 0) {
				return Integer.compare(branches, o.branches);
			} else {
				return Integer.compare(maxWeight, o.maxWeight);
			}
		}
	}
}

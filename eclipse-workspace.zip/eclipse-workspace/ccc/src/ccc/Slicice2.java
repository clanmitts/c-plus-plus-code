package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Slicice2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		int [] p = new int [n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) p[i] = Integer.parseInt(st.nextToken());
		int [] b = new int [m+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i <= m; i++) b[i] = Integer.parseInt(st.nextToken());
		int [][] dp = new int [n+1][k+1];
		for (int i = 1; i <= n; i++) {
			for (int j = 0; j <= k; j++) {
			}
		}
		System.out.println(dp[n][k]);
	}
}

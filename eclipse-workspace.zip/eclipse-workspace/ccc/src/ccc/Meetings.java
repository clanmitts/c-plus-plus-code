package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class Meetings {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int l = Integer.parseInt(st.nextToken());
		int [][] cows = new int [n+1][3];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			cows[i][0] = Integer.parseInt(st.nextToken());
			cows[i][1] = Integer.parseInt(st.nextToken());
			cows[i][2] = Integer.parseInt(st.nextToken());
		}
		ArrayList<Integer> finish = new ArrayList<Integer>();
		int num = 0;
		for (int i = 1; i <= n; i++) {
			if (cows[i][2] == -1) finish.add(cows[i][1]);
			else if (cows[i][2] == 1) finish.add(l-cows[i][1]);
		}
		int sum = 0;
		Collections.sort(finish);
	}
}

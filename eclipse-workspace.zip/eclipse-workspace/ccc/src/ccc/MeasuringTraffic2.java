package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MeasuringTraffic2 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int [][] range = new int [n+1][2];
		String [] list = new String [n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = st.nextToken().trim();
			range[i][0] = Integer.parseInt(st.nextToken());
			range[i][1] = Integer.parseInt(st.nextToken());
		}
		int ind = 0;
		for (int i = n; i >= 1; i--) {
			if (list[i].equals("none")) {
				ind = i;
				break;
			}
		}
		int min = range[ind][0];
		int max = range[ind][1];
		for (int i = ind-1; i >= 1; i--) {
			if (list[i].equals("on")) {
				min = Math.max(0, min-range[i][1]);
				max = Math.max(0, max-range[i][0]);
			}
			else if (list[i].equals("off")) {
				min += range[i][0];
				max += range[i][1];
			}
			else if (list[i].equals("none")) {
				min = Math.max(min, range[i][0]);
				max = Math.min(max, range[i][1]);
			}
		}
		System.out.println(min + " " + max);
		ind = 0;
		for (int i = 1; i <= n; i++) {
			if (list[i].equals("none")) {
				ind = i;
				break;
			}
		}
		min = range[ind][0];
		max = range[ind][1];
		for (int i = ind+1; i <= n; i++) {
			if (list[i].equals("off")) {
				min = Math.max(0, min-range[i][1]);
				max = Math.max(0, max-range[i][0]);
			}
			else if (list[i].equals("on")) {
				min += range[i][0];
				max += range[i][1];
			}
			else if (list[i].equals("none")) {
				min = Math.max(min, range[i][0]);
				max = Math.min(max, range[i][1]);
			}
		}
		System.out.println(min + " " + max);
	}
}

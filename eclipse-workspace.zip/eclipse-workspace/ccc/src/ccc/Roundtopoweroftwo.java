package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Roundtopoweroftwo {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		for (int i = 0; i < 5; i++) {
			st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			if (n == 0) System.out.println(1);
			else {
				int j = 0;
				for (j = 1; j <= n; j *= 2);
				if (n-j/2 < j-n) System.out.println(j/2);
				else System.out.println(j);
			}
		}
	}
}

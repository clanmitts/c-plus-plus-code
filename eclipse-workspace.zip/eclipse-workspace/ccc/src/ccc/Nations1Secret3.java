package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Nations1Secret3 {
	static int n;
	static char [] str;
	static long [] fhash;
	static long [] fpower;
	static long [] finv;
	static long [] bhash;
	static long [] bpower;
	static long [] binv;
	static long mod = (long)(1e9+7);
	static long base = 131;
	static long max;
	static long lindex;
	static long rindex;
	static boolean [] vis;
	public static long fp (long a, long power) {
		long ans = 1;
		for (long i = 1; i <= power; i*= 2) {
			if ((power&i) > 0) ans = (long) (ans*a % (long)(1e9+7));
			a = a*a % (long)(1e9+7);
		}
		return ans;
	}
	public static void getMax() {
		int lbest = 1; int rbest = 1;
		for (int i = 1; i <= n; i++) {
			int lo = 0; int hi = Math.min(i-1, n-i);
			while (lo != hi) {
				int mid = (lo+hi+1)/2;
				if((fhash[i+mid]-fhash[i]+mod)*finv[i]%mod ==
					(bhash[i-mid]-bhash[i]+mod)*binv[i]%mod) lo=mid;
				else hi = mid-1;
			}
			if(lo*2+1>rbest-lbest+1){
				lbest=i-lo;
				rbest=i+lo;
			}	
		}
		for (int i = 2; i <= n; i++) {
			int lo=0,hi= Math.min(i-1-1,n-i);
			while (lo != hi) {
				int mid=(lo+hi+1)/2;
				if((fhash[i+mid]-fhash[i]+mod)*finv[i]%mod ==
					(bhash[i-1-mid]-bhash[i-1]+mod)*binv[i-1]%mod)
					lo=mid;
				else hi = mid-1;
			}
			if(lo*2+2>rbest-lbest+1){
				lbest=i-lo-1;
				rbest=i+lo;
			}
		}
		lindex = lbest;
		rindex = rbest;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		str = st.nextToken().trim().toCharArray();
		fhash = new long[n+1];
		fpower = new long [n+1];
		finv = new long [n+1];
		fhash[0] = 0;
		fpower[0] = 1;
		finv[0] = 1;
		for (int i = 1; i <= n; i++) {
			fhash[i] = (fhash[i-1] + fpower[i-1]*str[i-1])%mod;
			fpower[i] = fpower[i-1]*base%mod;
			finv[i] = fp(fpower[i], mod-2);
		}
		bhash = new long[n+2];
		bpower = new long [n+2];
		binv = new long [n+2];
		bhash[n+1] = 0;
		bpower[n+1] = 1;
		binv[n+1] = 1;
		for (int i = n; i >= 1; i--) {
			bhash[i] = (bhash[i+1] + bpower[i+1]*str[i-1])%mod;
			bpower[i] = bpower[i+1]*base%mod;
			binv[i] = fp(bpower[i], mod-2);
		}
		getMax();
		for (int i = (int) lindex; i <= rindex; i++) {
			System.out.print(str[i-1]);
		}
		System.out.println();
		System.out.println(rindex-lindex+1);
	}
}

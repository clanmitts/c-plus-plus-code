package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class RedistributingGifts {
	static int [][] list;
	static int n;
	static int [] cow;
	static int [][] ans;
	static boolean [] used;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new int [n+1][n+1];
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= n; j++) {
				list[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		cow = new int [n+1];
		ans = new int [n+1][2];
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (list[i][j] == i) {
					cow[i] = j;
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			ans[i][0] = i;
			ans[i][1] = cow[i];
		}
		for (int i = 1; i <= n; i++) {
			
		}
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class GoodSamples2 {
	public static long fastPower(long x, int y) {
        long result = 1;
        while (y > 0) {
            if ((y & 1) == 0) {
                x *= x;
                y >>>= 1;
            } else {
                result *= x;
                y--;
            }
        }
        return result;
    }
	public static int count(String str) {
		int zero = -1; int one = -1;
		int index = 0;
		int count = 0;
		while (index < str.length()) {
			if (str.charAt(index) == '0') {
				count += (index - Math.max(zero, Math.max(index-2, -1)));
				zero = index;
			}
			else {
				count += (index - Math.max(one, Math.max(index-2, -1)));
				one = index;
			}
			index ++;
		}
		return count;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		boolean works = false;
		String fin = "";
		for (int i = 1; i <= fastPower(2, n); i++) {
			String str = Integer.toBinaryString(i);
			if (str.length() == n) {
				if (count(str) == k) {
					works = true;
					fin = str;
					break;
				}
			}
		}
		if (works) {
			System.out.print((char)(fin.charAt(0)+1) + " ");
			for (int i = 1; i < fin.length(); i++) {
				System.out.print((char)(fin.charAt(i)+1) + " ");
			}
		}
		else {
			System.out.println(-1);
		}
	}
}

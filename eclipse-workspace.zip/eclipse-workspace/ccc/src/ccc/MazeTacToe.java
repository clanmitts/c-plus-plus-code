package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MazeTacToe {
	static int n;
	static char [][] list;
	static boolean [][] m;
	static boolean [][] o;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		list = new char[n][n*3];
		m = new boolean [3][3];
		o = new boolean [3][3];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			list[i] = st.nextToken().trim().toCharArray();
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j += 3) {
				if (list[i][j] == 'M') m[list[i][j+1]][list[i][j+2]] = true;
				else if (list[i][j] == 'O') o[list[i][j+1]][list[i][j+2]] = true;
			}
		}
		
	}
	public static class place {
		char letter; int x, y;
		place (char a, int b, int c) {
			letter = a;
			x = b;
			y = c;
		}
	}
}

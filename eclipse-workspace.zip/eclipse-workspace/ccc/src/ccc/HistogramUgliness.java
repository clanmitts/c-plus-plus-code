package ccc;

public class HistogramUgliness {

}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class GoodTriplets3 {
	public static int binarySearch(int[] list, int n, int l, int h) {
		int max = Integer.MIN_VALUE;
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	max = Math.max(max, mid);
		    	h = mid-1;
		    }
		}
		if (max != 0) return max;
		l = 1;
		h = 2*n+1;
		while (l <= h) {
			int mid = l  + ((h - l) / 2);
		    if (list[mid] < n) {
		    	l = mid + 1;
		    } 
		    else if (list[mid] > n) {
		    	h = mid - 1;
		    } 
		    else if (list[mid] == n) {
		    	return mid;
		    }
		}
		return h;
	}
	public static void main(String [] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int c = Integer.parseInt(st.nextToken());
		int [] list = new int [2*n+1];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			list[i] = Integer.parseInt(st.nextToken());
			list[i+n] = list[i] + c;
		}
		Arrays.sort(list);
		int l = 1; 
		int r = binarySearch(list, c/2+list[1], 1, 2*n)+1;
		int q = r;
		int count = (q-l+1)*(r-l)*(r-l-1)/6;
		while (l <= n) {
			while (list[r]-list[l] <= (c+1)/2) r++;
			count += (r-l)*(r-l-1)/2;
			q = r;
			while (list[r]-list[l] >= (c+1)/2) l++;
		}
	}
}

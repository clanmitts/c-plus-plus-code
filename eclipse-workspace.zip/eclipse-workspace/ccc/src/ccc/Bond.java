package ccc;

public class Bond {

}

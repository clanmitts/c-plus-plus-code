package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FactorSolitaire2 {
	static int count;
	static int n;
	public static void small() {
		for (int i = n-1; i >= 2; i--) {
			if ((n-i)%i == 0) {
				n-= i;
				count += n/i;
				return;
			}
		}
		n-=1;
		count += n;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		count = 0;
		int count2 = 0;
		while (n != 1) {
			count2 ++;
			small();
		}
		System.out.println(count);
	}
}

package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class SquirrelElection {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		province [] list = new province[n+1];
		list[0] = new province(0, 0);
		int needed = 0;
		for (int i = 1; i <= n; i++) {
			st = new StringTokenizer(br.readLine());
			int v = Integer.parseInt(st.nextToken());
			int p = Integer.parseInt(st.nextToken());
			v = v/2+1;
			list[i] = new province(v, p);
			needed += p;
		}
		needed = needed/2 + 1;
		long [][] dp = new long [n+1][5001];
		for (int i = 0; i <= n; i++) {
			Arrays.fill(dp[i], (long) 1e13);
			dp[i][0] = 0;
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= 5000; j++) {
				if (j - list[i].p >= 0) {
					dp[i][j] = Math.min(dp[i-1][j], dp[i-1][j-list[i].p] + list[i].v);
				}
				else {
					dp[i][j] = dp[i-1][j];
				}
			}
		}
		long min = (long)(10e13);
		for (int i = needed; i <= 5000; i++) {
			min = Math.min(min, dp[n][i]);
		}
		System.out.println(min);
	}
	public static class province {
		int v, p;
		province(int a, int b) {
			v = a;
			p = b;
		}
	}
}

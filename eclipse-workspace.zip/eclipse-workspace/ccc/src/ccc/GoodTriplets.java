package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class GoodTriplets {
	static ArrayList<Integer> list;
	static int quarter;
	public static int middle(int a, int b, int c) {
		if ((a < b && b < c) || (c < b && b < a))
			return b;
		else if ((b < a && a < c) || (c < a && a < b))
			return a;
		else
			return c;
	}
	public static boolean works (int a, int b, int c) {
		int one = Math.abs(list.get(a)-list.get(b));
		int two = Math.abs(list.get(a)-list.get(c));
		int three = Math.abs(list.get(c)-list.get(b));
		return (Math.min(one, Math.min(two, three)) + middle(one, two, three)) > quarter;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int c = Integer.parseInt(st.nextToken());
		quarter = (c+1)/2;
		list = new ArrayList<Integer>();
		boolean [] used = new boolean [(int) (c+1)];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i <= n; i++) {
			int temp = Integer.parseInt(st.nextToken());
			if (!used[temp]) {
				list.add(temp);
				used[temp] = true;
			}
		}
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			for (int j = i+1; j < list.size(); j++) {
				for (int k = j+1; k <list.size(); k++) {
					if (works(i, j, k)) count ++;
				}
			}
		}
		System.out.println(count-1);
	}
}

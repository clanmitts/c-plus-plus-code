package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SuperPLumber3 {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		while (true) {
			st = new StringTokenizer(br.readLine());
			int m = Integer.parseInt(st.nextToken());
			int n = Integer.parseInt(st.nextToken());
			if (m == 0) break;
			char [][] list = new char [m+2][n+1];
			for (int i = 1; i <= m; i++) {
				st = new StringTokenizer(br.readLine());
				char [] temp = st.nextToken().trim().toCharArray();
				for (int j = 1; j <= n; j++) {
					list[i][j] = temp[j-1];
				}
			}
			int [][][] dp = new int [m+2][n+2][2];
			for (int i = 1; i <= m; i++) {
				dp[i][1][1] = -Integer.MAX_VALUE;
			}
			dp[m][1][1] = 0;
			for (int i = 0; i <= m+1; i++) {
				for (int j = 0; j <= n; j++) {
					dp[i][j][0] = Integer.MIN_VALUE;
					dp[i][j][1] = Integer.MIN_VALUE;
				}
			}
			dp[m][1][0] = 0;
			dp[m][1][1] = 0;
			for (int i = 1; i <= n; i++) {
				for (int j = m; j >= 1; j--) {
					if (list[j][i] != '*') {
						dp[j][i][0] = Math.max(Math.max(dp[j][i-1][0], dp[j][i-1][1]), 
								Math.max(dp[j][i][0], dp[j+1][i][0]));
						if (list[j][i] >= 49 && list[j][i] <= 57) {
							dp[j][i][0] += list[j][i]-48;
						}
					}
				}
				for (int j = 1; j <= m; j++) {
					if (list[j][i] != '*') {
						dp[j][i][1] = Math.max(Math.max(dp[j][i-1][0], dp[j][i-1][1]), 
								Math.max(dp[j][i][1], dp[j-1][i][1]));
						if (list[j][i] >= 49 && list[j][i] <= 57) {
							dp[j][i][1] += list[j][i]-48;
						}
					}
				}
			}
			System.out.println(Math.max(dp[m][n][0], dp[m][n][1]));
		}
	}
}

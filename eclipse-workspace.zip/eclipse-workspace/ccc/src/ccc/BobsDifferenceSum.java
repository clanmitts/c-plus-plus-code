package ccc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BobsDifferenceSum {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		Long [] list = new Long [n+1];
		Long [] psa = new Long [n+1];
		st = new StringTokenizer(br.readLine());
		list[0] = Long.MIN_VALUE;
		for (int i = 1; i <= n; i++) {
			list[i] = Long.parseLong(st.nextToken());
		}
		Arrays.sort(list);
		psa[1] = list[1];
		for (int i = 2; i <= n; i++) {
			psa[i] = psa[i-1] + list[i];
		}
		long count = 0;
		for (int i = 1; i < n; i++) {
			count += (psa[n] - psa[i] - (list[i] * (n-i)));
		}
		System.out.println(count);
	}
}

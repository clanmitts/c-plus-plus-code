package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Chapter_3_Exercise_1 {
	public static void main(String [] args) throws IOException {
		System.out.println("\t\t B\t\t I\t\t N\t\t G\t\t O");
		System.out.println("\t\t 2\t\t20\t\t42\t\t60\t\t64");
		System.out.println("\t\t14\t\t25\t\t32\t\t55\t\t70");
		System.out.println("\t\t 5\t\t18\t      Free\t\t53\t\t67");
		System.out.println("\t\t12\t\t16\t\t31\t\t46\t\t75");
		System.out.println("\t\t10\t\t22\t\t39\t\t59\t\t71");
	}
}

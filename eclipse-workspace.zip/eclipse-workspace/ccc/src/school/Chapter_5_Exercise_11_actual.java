package school;

import java.util.Scanner;

public class Chapter_5_Exercise_11_actual {
	static double a, b, c, x1, x2;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the value for a: ");
		a = input.nextDouble();
		System.out.print("Enter the value for b: ");
		b = input.nextDouble();
		System.out.print("Enter the value for c: ");
		c = input.nextDouble();
		x1 = (-b + Math.sqrt(b*b - 4*a*c))/(2*a);
		x2 = (-b - Math.sqrt(b*b - 4*a*c))/(2*a);
		System.out.println("There roots are " + x1 + " and " + x2);
	}
}

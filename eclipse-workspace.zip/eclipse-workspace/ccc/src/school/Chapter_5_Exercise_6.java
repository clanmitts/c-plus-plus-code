package school;

import java.util.Scanner;
import java.util.Random;

public class Chapter_5_Exercise_6 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		int a = rand.nextInt(10)+1;
		int b = rand.nextInt(10)+1;
		int c = rand.nextInt(4);
		if (c == 0) {
			System.out.print("What is " + a + " * " + b + " ? ");
			int in = input.nextInt();
			if (in == a*b) System.out.println("Correct");
			else System.out.println("Incorrect");
		}
		else if (c == 1) {
			System.out.print("What is " + a + " + " + b + " ? ");
			int in = input.nextInt();
			if (in == a+b) System.out.println("Correct");
			else System.out.println("Incorrect");
		}
		else if (c == 2) {
			System.out.print("What is " + a + " - " + b + " ? ");
			int in = input.nextInt();
			if (in == a-b) System.out.println("Correct");
			else System.out.println("Incorrect");
		}
		else if (c == 3) {
			System.out.print("What is " + a + " / " + b + " ? ");
			int in = input.nextInt();
			if (in == a/b) System.out.println("Correct");
			else System.out.println("Incorrect");
		}
	}
}

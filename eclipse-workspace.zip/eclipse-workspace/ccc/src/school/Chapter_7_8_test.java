package school;

import java.util.Scanner;

class calcTax {
	public static double Taxrate(double n) {
		if (n <= 1000.00) return 2;
		if (n < 5000.00) return 3;
		return 6;
	}
}

public class Chater_7_8_test {
	public static void Delivery(double n) {
		if (n < 1000) System.out.println("The total cost plus delivery = $" + (25 + n));
		else if (n < 5000) System.out.println("The total cost plus delivery = $" + (65 + n));
		else System.out.println("The total cost plus delivery = $" + (85 + n));
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("How much does the order cost? ");
		double n = input.nextDouble();
		System.out.println(calcTax.Taxrate(n));
		n += (n*calcTax.Taxrate(n)/100);
		Delivery(n);
		calcTax x = new calcTax();
	}
}

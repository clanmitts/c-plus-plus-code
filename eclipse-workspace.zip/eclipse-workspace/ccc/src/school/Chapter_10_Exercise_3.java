package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_10_Exercise_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		int [] arr = new int [10];
		for (int i = 1; i <= 500; i++) {
			arr[rand.nextInt(10)] ++;
		}
		for (int i = 0; i <= 9; i++) {
			System.out.println(i + "\t" + arr[i]);
		}
	}
}

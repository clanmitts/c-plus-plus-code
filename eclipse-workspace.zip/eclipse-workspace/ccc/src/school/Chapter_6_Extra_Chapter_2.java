package school;

import java.util.Scanner;

public class Chapter_6_Extra_Chapter_2 {
	 public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
		 String str = input.nextLine();
		 str = str.toUpperCase();
		 System.out.println(str);
		 for (int i = 1; i < str.length()-1; i++) {
			 System.out.print(str.charAt(i));
			 for (int j = 1; j <= str.length()-2; j++) {
				 System.out.print("*");
			 }
			 System.out.println(str.charAt(str.length()-1-i));
		 }
		 for (int i = str.length()-1; i >= 0; i--) {
			 System.out.print(str.charAt(i));
		 }
		 System.out.println();
	 }
}

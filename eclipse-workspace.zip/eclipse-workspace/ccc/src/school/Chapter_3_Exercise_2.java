package school;

public class Chapter_3_Exercise_2 {
	public static void main(String [] args) {
		System.out.println("Bingo Card"
				+ "\n\n"
				+ "1. the caller randomly pulls a numbered bingo ball."
				+ "\n\n"
				+ "2. The number is placed on the bingo board and called out."
				+ "\n\n"
				+ "3. Players look for the called number on their bingo card."
				+ "\n\n"
				+ "4. If the number is located, it is marked off."
				+ "\n\n"
				+ "5. Steps 1 to 4 are repeated until a player matches the BINGO pattern."
				+ "\n\n"
				+ "6. The winning player yells BINGO."
				+ "\n");
	}
}

package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_7_Exercise_8 {
	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		Random rand = new Random();
		System.out.println("High Low Game\n");
		System.out.println("RULES");
		System.out.println("Numbers 1 through 6 are low");
		System.out.println("Numbers 8 through 13 are high");
		System.out.println("Number 7 is neither high or low");
		int points = 1000;
		while (true) {
			System.out.println("\nYou have " + points + " points. \n");
			System.out.print("Enter points to risk: ");
			int risk;
			risk = input.nextInt();
			System.out.print("\npredict (1 = High, 0 = Low): ");
			int hl = input.nextInt();
			int c = rand.nextInt(13)+1;
			System.out.println("Number is " + c);
			if (hl == 0) {
				if (c <= 6) {
					System.out.println("You win. ");
					points += risk*2;
				}
				else {
					System.out.println("You lose. ");
					points -= risk;
				}  
			}
			else {
				if (c >= 7) {
					System.out.println("You win. ");
					points += risk*2;
				}
				else {
					System.out.println("You lose. ");
					points -= risk;
				}
			}
			System.out.print("Play again? (y or n) ");
			int e = input.next().charAt(0);
			if (e == 'n') break;
		}
		System.out.println("Thanks for playing");
	}
}

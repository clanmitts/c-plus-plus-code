package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class Chapter_4_Exercise_6 {
	public static int q, d, n, p, v;
	public static void main(String[] args) throws IOException {
		System.out.print("Enter the change in cents: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		v = Integer.parseInt(st.nextToken());
		q = v / 25;
		v -= q*25;
		d = v/10;
		v -= d*10;
		n = v/5;
		v -= n*5;
		p = v;
		System.out.println("The minimum number of coins is: "
				+ "\nQuarters: " + q
				+ "\nDimes: " + d
				+ "\nNickels: " + n
				+ "\nPennies: " + p);
	}
}

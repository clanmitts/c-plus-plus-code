package school;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class mastermind {
	static Scanner input = new Scanner(System.in);
	static Random rand = new Random();
	static int [] board;
	static int [] guess;
	static int [] freqb;
	static int [] freqg;
	static int pegs;
	static int colours;
	static int tries;
	static int o;
	static int t;
	static void createGame() {
		tries = 0;;
		System.out.print("Enter the number of pegs (1-10): ");
		pegs = input.nextInt();
		System.out.print("Enter the number of colours (1-9): ");
		colours = input.nextInt();
		board = new int [pegs+1];
		guess = new int [pegs+1];
		freqb = new int [colours+1];
		freqg = new int [colours+1];
		for (int i = 1; i <= pegs; i++) {
			board[i] = rand.nextInt(colours)+1;
			freqb[board[i]] ++;
		}
	}
	static boolean guess() {
		o = 0;
		t = 0;
		tries ++;
		Arrays.fill(freqg, 0);
		System.out.println("Guess " + tries + ":");
		for (int i = 1; i <= pegs; i++) {
			System.out.print("Colour for peg " + i + ":");
			guess[i] = input.nextInt();
		}
		one();
		two();
		if (o == pegs) {
			System.out.println("You have broken the code in " + tries + " guesses. ");
			return false;
		}
		else {
			System.out.println("You have " + o + " pegs(s) correct and " + t + " colour(s) correct but not in the right place. ");
			return true;
		}
	}
	static void one() {
		for (int i = 1; i <= pegs; i++) {
			if (board[i] == guess[i]) {
				o++;
				freqg[board[i]] ++;
			}
		}
	}
	static void two() {
		for (int i = 1; i <= pegs; i++) {
			if (freqb[guess[i]] > freqg[guess[i]]) {
				t++;
				freqg[board[i]] ++;
			}
		}
	}
}

public class Chapter_10_Exercise_5 {
	public static void main(String[] args) {
		mastermind game = new mastermind();
		game.createGame();
		while (game.guess());
	}
}

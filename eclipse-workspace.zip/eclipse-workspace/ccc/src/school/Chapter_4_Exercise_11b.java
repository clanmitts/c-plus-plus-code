package school;

import java.util.Scanner;

public class Chapter_4_Exercise_11b {
	static int b, f, s;
	static double total, taxes, tendered;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number of burgurs: ");
		b = input.nextInt();
		System.out.print("Enter the number of fries: ");
		f = input.nextInt();
		System.out.print("Enter the number of sodas: ");
		s = input.nextInt();
		total = b*1.69 + f*1.09 + s*0.99;
		System.out.print("Total before taxes: $");
		System.out.printf("%.2f", total);
		taxes = total * 0.065;
		System.out.print("\nTax: $");
		System.out.printf("%.2f", taxes);
		System.out.print("\nFinal total: $");
		System.out.printf("%.2f", total + taxes);
		System.out.print("\nEnter the amount tendered: $");
		tendered = input.nextInt();
		System.out.print("Change: $");
		System.out.printf("%.2f", tendered-total-taxes);
	}
}

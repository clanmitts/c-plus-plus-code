package school;

import java.util.Random;

public class Chapter_10_Exercise_2 {
	public static int cal(int n) {
		int total = n;
		for (int i = 0; i < Integer.toString(n).length(); i++) {
			total += (Integer.toString(n).charAt(i)-'1'+1);
		}
		return total;
	}
	public static void main(String[] args) {
		int [] arr =  new int [102];
		for (int i = 1; i <= 101; i++) {
			arr[i] = cal(i);
		}
		System.out.println("Index\tGenerated Number");
		for (int i = 1; i <= 101; i++) {
			System.out.println(i + "\t" + arr[i]);
		}
	}
}

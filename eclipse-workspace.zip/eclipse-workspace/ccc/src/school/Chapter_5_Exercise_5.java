package school;

import java.io.IOException;
import java.util.Scanner;

public class Chapter_5_Exercise_5 {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the percentage: ");
		int n = input.nextInt();
		System.out.print("The corresponding letter grade is: ");
		if (n < 60) System.out.println("F");
		else if (n < 70) System.out.println("D");
		else if (n < 80) System.out.println("C");
		else if (n < 90) System.out.println("B");
		else System.out.println("A");
	}
}

\\\\\\\\package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_7_Exercise_10 {
	public static void giveHint(int n, int ans) {
		if (n < ans) System.out.println("Hint: Try a higher number. ");
		else System.out.println("Hint: Try a lower number. ");
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		Random r = new Random();
		int ans = r.nextInt(20)+1;
		while (true) {
			System.out.print("Enter a number of 1 and 20: ");
			int n = input.nextInt();
			if (n == ans) {
				System.out.println("You Won!");
				break;
			}
			giveHint(n, ans);
		}
	}
}

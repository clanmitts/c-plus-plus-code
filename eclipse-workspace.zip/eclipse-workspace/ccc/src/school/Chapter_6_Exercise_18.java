package school;

import java.util.Scanner;

public class Chapter_6_Exercise_18 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter your first name: ");
		String f = input.nextLine();
		System.out.print("Enter your middle name: ");
		String m = input.nextLine();
		System.out.print("Enter your last name: ");
		String l = input.nextLine();
		System.out.println("Your monogram is: " + f.toLowerCase().charAt(0) + m.toUpperCase().charAt(0) + l.toLowerCase().charAt(0));
	}
}

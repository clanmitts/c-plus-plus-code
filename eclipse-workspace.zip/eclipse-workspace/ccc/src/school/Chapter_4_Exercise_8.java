package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import java.util.Scanner;

public class Chapter_4_Exercise_8 {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter an integer: ");
		int a = input.nextInt();
		System.out.print("Enter a second integer: ");
		int b = input.nextInt();
		System.out.println(a + " / " + b + " = " + (a/b) );
		System.out.println(a + " % " + b + " = " + (a%b) );
		System.out.println("\n" + b + " / " + a + " = " + (b/a) );
		System.out.println(b + " % " + a + " = " + (b/a) );
	}
}

package school;

import java.util.Scanner;

public class Chapter_8_Exercise_2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		while (true) {
			System.out.print("Enter an integer: ");
			String str = input.nextLine();
			num n = new num();
			n.n = str;
			n.newNum();
			System.out.println("show (w)hole number.");
			System.out.println("show (O)nes place number.");
			System.out.println("show (T)ens place number.");
			System.out.println("show (H)undreds place number.");
			System.out.println("(Q)uit");
			System.out.print("Enter your choice: ");
			char c = input.next().charAt(0);
			input.nextLine();
			if (c == 'W') System.out.println("The whole number is " + Integer.parseInt(n.n));
			else if (c == 'O') System.out.println("The ones place digit is: " + n.ones());
			else if (c == 'T') System.out.println("The tens place digit is: " + n.tens());
			else if (c == 'H') System.out.println("The hundreds place digit is: " + n.hundreds());
			else if (c == 'Q') break;
		}
	}
	public static class num {
		String n;
		public num newNum() {
			if (n.length() == 1) n = "00" + n;
			else if (n.length() == 2) n = "0" + n;
			return null;
			
		}
		public String whole() {
			return n;
		}
		public char ones() {
			return n.charAt(n.length()-1);
		}
		public char tens() {
			return n.charAt(n.length()-2);
		}
		public char hundreds() {
			return n.charAt(n.length()-3);
		}
	}
}

package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_6_Exercise_14 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random r = new Random();
		System.out.println("Dice 1\tDice 2\tTotal");
		for (int i = 1; i <= 5; i++) {
			int a = r.nextInt(6)+1;
			int b = r.nextInt(6)+1;
			int total = a+b;
			if (total < 10)System.out.println("     " + a + "\t     " + b + "\t    " + total);
			else System.out.println("     " + a + "\t     " + b + "\t   " + total);
		}
	}
}

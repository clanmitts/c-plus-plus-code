package school;

import java.util.Scanner;

public class Chapter_5_Exercise_13 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double p, r, m, c;
		System.out.print("Principal: ");
		p = input.nextDouble();
		System.out.print("Interest Rate: ");
		r = input.nextDouble();
		System.out.print("Number of monthly payments: ");
		m = input.nextDouble();
		c = p*(r/12)/(1-(Math.pow(1+r/12, -m)));
		System.out.print("The monthly payment is $");
		System.out.format("%.2f", c);
	}
}

package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Chapter_4_Exercise_2 {
	public static void main(String[] args) throws IOException {
		System.out.print("Enter the diameter of the pizza in inches: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		double d = Double.parseDouble(st.nextToken());
		d = d*d*0.05 + 1.00 + 0.75;
		d *= 100;
		d = Math.round(d);
		d /= 100;
		System.out.println("The cost of making the pizza is : $" + d + "\n");
	}
}

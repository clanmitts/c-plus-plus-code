package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Chapter_4_Exercise_1 {
	public static void main(String [] args) throws IOException{
		System.out.format("Enter a time less than 4.5 seconds: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		double t = Double.parseDouble(st.nextToken());
		if (t >= 4.5) System.out.format("Number is too big \n");
		else {
			System.out.format("The height of the object is : " + (100-4.9*t*2) + " meters\n");		
		}
	}
}

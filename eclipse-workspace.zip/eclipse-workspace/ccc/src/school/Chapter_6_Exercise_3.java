package school;

import java.util.Scanner;

public class Chapter_6_Exercise_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double investment = 2500;
		double compound = 0.075;
		int years = 0;
		while (investment < 5000) {
			investment += (investment*compound);
			years ++;
		}
		System.out.println(years);
	}
}

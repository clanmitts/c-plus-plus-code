package school;
import java.util.Scanner;

public class Chapter_5_Exercise_02 {
	static int weight, length, width, height, volume;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter package weight in kilograms: ");
		weight = input.nextInt();
		System.out.print("Enter package length in centimeters: ");
		length = input.nextInt();
		System.out.print("Enter package width in centimeters: ");
		width = input.nextInt();
		System.out.print("Enter package height in centimeters: ");
		height = input.nextInt();
		int volume = length*width*height;
		if (volume > 100000) {
			if (weight > 27) System.out.println("Too heavy and too large.");
			else System.out.println("Too large.");
		}
		else if (weight > 27) System.out.println("Too heavy");
	}
}

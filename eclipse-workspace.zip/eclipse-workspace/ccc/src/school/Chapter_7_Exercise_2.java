package school;

import java.util.Scanner;

public class Chapter_7_Exercise_2 {
	public static double one(double n) {
		return n*2.54;
	}
	public static double two(double n) {
		return n*30.48;
	}
	public static double three(double n) {
		return n*0.9144;
	}
	public static double four(double n) {
		return n*1.60934;
	}
	public static void five(double n) {
		System.out.println(n * 0.393701);
	}
	public static void six(double n) {
		System.out.println(n * 0.0328084);
	}
	public static void seven(double n) {
		System.out.println(n * 0.393701);
	}
	public static void eight(double n) {
		System.out.println(n * 0.621371);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a number: ");
		double x = input.nextDouble();
		System.out.println("Convert: ");
		System.out.println("1. Inches to Centimeters\t5. Centimeters to Inches");
		System.out.println("2. Feet to Centimeters\t\t6. Centimeters to Feet");
		System.out.println("3. Yards to Meters\t\t7. Meters to Yards");
		System.out.println("4. Miles to Kilometers\t\t8. Kilometers to Miles");
		System.out.print("Enter your choice: ");
		double n = input.nextInt();
		if (n == 1) System.out.println(one(x));
		else if (n == 2) System.out.println(two(x));
		else if (n == 3) System.out.println(three(x));
		else if (n == 4) System.out.println(four(x));
		else if (n == 5) five(x);
		else if (n == 6) six(x);
		else if (n == 7) seven(x);
		else if (n == 8) eight(x);
	}
}

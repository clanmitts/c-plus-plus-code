package school;

import java.util.Scanner;

public class Chapter_6_Exercise_6 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a positive integer: ");
		String n = input.nextLine();
		int sum = 0;
		for (int i = 0; i < n.length(); i++) {
			sum += n.charAt(i)-'0';
		}
		System.out.print("The sum of the digits is: ");
		System.out.println(sum);
	}
}

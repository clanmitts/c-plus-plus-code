package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Chapter_6_Exercise_19 {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a sentece: ");
		String str = input.nextLine();
		System.out.print("Enter a string: ");
		String n = input.nextLine();
		String out = "";
		int a = 0;
		int b = 0;
		while (b < str.length()) {
			if (str.charAt(b) < 'A' || 
					(str.charAt(b) > 'Z' && str.charAt(b) < 'a') || 
					str.charAt(b) > 'z') {
				if (!str.substring(a, b).toLowerCase().equals(n.toLowerCase())) {
					for (int i = a; i <= b; i++) {
						out += str.charAt(i);
					}
				}
				a = b+1;
			}
			b++;
		}
		if (!str.substring(a, b).equals(n)) {
			for (int i = a; i < b; i++) {
				out += str.charAt(i);
			}
		}
		System.out.println(out);
	}
}

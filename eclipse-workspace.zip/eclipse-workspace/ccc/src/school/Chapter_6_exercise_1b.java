package school;

import java.util.Scanner;

public class Chapter_6_exercise_1b {
	
	public static boolean isPrime(int n) {
		if (n == 1) return false;
		for (int i = 2; i < n; i++) if (n%i == 0) return false;
		return true;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int m = input.nextInt();
		System.out.print("Prime numbers: ");
		for (int i = n; i <= m; i++) if (isPrime(i)) System.out.print(i + " ");
	}
}

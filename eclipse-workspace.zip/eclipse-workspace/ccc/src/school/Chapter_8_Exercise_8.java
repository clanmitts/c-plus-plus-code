package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_8_Exercise_8 {
	static class guess {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		int a;
		int b;
		int n;
		int score;
		public void getRand() {
			a = rand.nextInt(21);
			b = rand.nextInt(21);
		}
		public void takeGuess() {
			System.out.print(a + " + " + b + " = ");
			n = input.nextInt();
		}
		public void guesses() {
			while(true) {
				getRand();
				takeGuess();
				if (n == 999) return;
				if (n == a+b) {
					score += 5;
					continue;
				}
				System.out.print("Wrong answer. Enter another answer: ");
				n = input.nextInt();
				if (n == 999) break;
				if (n == a+b) {
					score += 3;
					continue;
				}
				System.out.print("Wrong answer. Enter another answer: ");
				n = input.nextInt();
				if (n == 999) break;
				if (n == a+b) {
					score += 1;
					continue;
				}
				System.out.println("Wrong answer. The answer was " + (a+b));
			}
		}
	}
	public static void main(String[] args) {
		guess g = new guess();
		g.score = 0;
		g.guesses();
		System.out.println("Your score is: " + g.score);
	}
}

package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;

public class Chapter_5_Exercise_9 {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		int c = rand.nextInt(20)+1;
		System.out.print("Enter a number between 1 and 20: ");
		int n = input.nextInt();
		System.out.println("Computer's Number: " + c);
		System.out.println("Player's Number: " + n);
		if (n == c) System.out.println("You won!");
		else System.out.println("Better luck next time");
	}
}

package school;

import java.util.Scanner;

public class Chapter_6_test {
	public static boolean con (String str, char a) {
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == a) return true;
		}
		return false;
	}
	public static void check(String a, String b) {
		int same = 0;
		for (int i = 0; i < a.length(); i++) {
			if (a.charAt(i) == b.charAt(i)) same ++;
		}
		if (same >= 4) {
			System.out.println("Password is not accepted (too similar)"); 
			return;
		}
		if (b.length() < 6) {
			System.out.println("Password is not accepted (must be at least 6 characters)");
			return;
		}
		if (!('a' <= b.toLowerCase().charAt(0) && b.toLowerCase().charAt(0) <= 'z')) {
			System.out.println("Password is not accepted (must start with a character)");
			return;
		}
		if (b.contains(" ")) {
			System.out.println("Password is not accepted (cannot contain spaces)");
			return;
		}
		if (b.toLowerCase().equals(b)) {
			System.out.println("Password is not accepted (must have a capital letter)");
			return;
		}
		if (!con(b, '0') && 
			!con(b, '1')&&
			!con(b, '2')&& 
			!con(b, '3')&& 
			!con(b, '4')&& 
			!con(b, '5')&& 
			!con(b, '6')&& 
			!con(b, '7')&& 
			!con(b, '8')&& 
			!con(b, '9')) {
			System.out.println("Password is not accepted (must contian at least one number)");
			return;
		}
		if (!con(b, '*') &&
				!con(b, '@')&& 
				!con(b, '>')&& 
				!con(b, '?')) {
			System.out.println("Password is not accepted (must contain one of * @ > $) ");
			return;
		}
		System.out.println("Password is accepted");
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String o = input.nextLine();
		String n  = input.nextLine();
		check(o, n);
	}
}

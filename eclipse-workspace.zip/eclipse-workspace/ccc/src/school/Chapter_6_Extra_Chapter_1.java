package school;

import java.util.ArrayList;
import java.util.Scanner;

public class Chapter_6_Extra_Chapter_1 {
	public static int count(String str, char want) {
		int c = 0;
		for (int i = 0; i < str.length(); i++) if (str.charAt(i) == want) c ++;
		return c;
	}
	public static String reverse(String str) {
		String temp = "";
		for (int i = str.length()-1; i >= 0; i--) {
			temp += str.charAt(i);
		}
		return temp;
	}
	public static boolean consecutive(String str, char c) {
		for (int i = 1; i < str.length(); i++) if (str.charAt(i) == c && str.charAt(i-1) == c) return true;
		return false;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str = input.nextLine().trim();
		int numOfChar = str.length();
		int numOfWords = count(str, ' ')+1;
		String reversedSentence = reverse(str);
		String upperCase = str.toUpperCase();
		String lowerCase = str.toLowerCase();
		int vowels = count(upperCase, 'A') + 
					 count(upperCase, 'E') + 
					 count(upperCase, 'I') +
					 count(upperCase, 'O') +
					 count(upperCase, 'U');
		int consonants = count(upperCase, 'B') +
						 count(upperCase, 'C') +
						 count(upperCase, 'D') +
						 count(upperCase, 'F') +
						 count(upperCase, 'G') +
						 count(upperCase, 'H') +
						 count(upperCase, 'J') +
						 count(upperCase, 'K') +
						 count(upperCase, 'L') +
						 count(upperCase, 'M') +
						 count(upperCase, 'N') +
						 count(upperCase, 'P') +
						 count(upperCase, 'Q') +
						 count(upperCase, 'R') +
						 count(upperCase, 'S') +
						 count(upperCase, 'T') +
						 count(upperCase, 'V') +
						 count(upperCase, 'W') +
						 count(upperCase, 'X') +
						 count(upperCase, 'Y') +
						 count(upperCase, 'Z');
		int ind = 0;
		ArrayList<Integer> ASCII = new ArrayList<Integer>();
		while (str.charAt(ind) != ' ' && 
			   str.charAt(ind) != '.' && 
			   str.charAt(ind) != ',' &&
			   str.charAt(ind) != '?' &&
			   str.charAt(ind) != '!' &&
			   str.charAt(ind) != ';' &&
			   str.charAt(ind) != ':') {
			ASCII.add((int) str.charAt(ind));
			ind ++;
		}
		boolean and = upperCase.contains("AND");
		boolean A = consecutive(upperCase, 'A');
		boolean E = consecutive(upperCase, 'E');
		boolean I = consecutive(upperCase, 'I');
		boolean O = consecutive(upperCase, 'O');
		boolean U = consecutive(upperCase, 'U');
		int upper = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') upper ++;
		}
		int lower = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') lower ++;
		}
		int punctuation = count(str, ',') + count(str, '.') + count(str, '?') + count(str, '!') + count(str, ';') + count(str, ':');
		System.out.print("Number of characters: ");
		System.out.println(numOfChar);
		System.out.print("Number of words: ");
		System.out.println(numOfWords);
		System.out.print("The sentence reversed: ");
		System.out.println(reversedSentence);
		System.out.print("The sentecne in uppercase: ");
		System.out.println(upperCase);
		System.out.print("The sentence in lowercase: ");
		System.out.println(lowerCase);
		System.out.print("The number of vowels: ");
		System.out.println(vowels);
		System.out.print("The number of consonants: ");
		System.out.println(consonants);
		System.out.print("The ASCII values of the first word:");
		for (int i: ASCII) System.out.print(" " + i);
		System.out.println();
		if (and) System.out.println("The sentence contains and"); else System.out.println("The sentece does not contain and");
		if (A)  System.out.println("A appears consecutively");
		if (E) System.out.println("E appears consecutively");
		if (I) System.out.println("I appears consecutively");
		if (O) System.out.println("O appears consecutively");
		if (U) System.out.println("U appears consecutively");
		if (!A && !E && !I && !O && !U) System.out.println("No vowels appear consecutively. ");
		System.out.print("Number of uppercase letters: ");
		System.out.println(upper);
		System.out.print("Number of lowercase letters: ");
		System.out.println(lower);
	}
}

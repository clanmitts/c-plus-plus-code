package school;
import java.util.Scanner;

public class Chapter_5_Exercise_3 {
	static double eggs;
	static double price;
	public static void main(String[] args) {
		System.out.print("Enter the number of eggs purchased: ");
		Scanner input = new Scanner(System.in);
		eggs = input.nextInt();
		eggs /= 12;
		if (eggs < 4) {
			price = 0.50*eggs;
		}
		else if (eggs < 6) {
			price = 0.45*eggs;
		}
		else if (eggs < 11) {
			price = 0.40*eggs;
		}
		else {
			price = 0.35*eggs;
		}
		System.out.print("The bill is equal to : $");
		System.out.format("%.2f", price);
	}
}

package school;

import java.util.Random;
import java.util.Scanner;

public class Chapter_6_Exercise_8 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random r = new Random();
		int ans = r.nextInt(20)+1;
		while (true) {
			System.out.print("Enter a number of 1 and 20: ");
			int n = input.nextInt();
			if (n == ans) {
				System.out.println("You Won!");
				break;
			}
			System.out.println("Try again.");
		}
	}
}

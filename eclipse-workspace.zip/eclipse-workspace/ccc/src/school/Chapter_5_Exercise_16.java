package school;

import java.util.Scanner;
import java.lang.Math;

public class Chapter_5_Exercise_16 {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter an angle in degrees: ");
		double a = input.nextDouble();
		a = Math.toRadians(a);
		System.out.print("Sine: ");
		System.out.println(Math.sin(a));
		System.out.print("Cosine: ");
		System.out.println(Math.cos(a));
		System.out.print("Tangent: ");
		System.out.println(Math.tan(a));
	}
}

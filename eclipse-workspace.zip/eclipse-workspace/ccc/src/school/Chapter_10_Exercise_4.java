package school;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

public class Chapter_10_Exercise_4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		ArrayList<Integer> arr = new ArrayList<Integer>();
		double count = 0;
		double total = 0;
		int max = 0;
		int min = Integer.MAX_VALUE;
		int [] freq = new int [51];
		int median = 0;
		HashSet<Integer> modes = new HashSet<Integer>();
		while (true) {
			System.out.println("Enter a number from 1 to 50. Enter 0 to stop entering numbers: ");
			int n = input.nextInt();
			if (n == 0) break;
			count ++;
			max = Math.max(max, n);
			min = Math.min(min, n);
			arr.add(n);
			freq[n] ++;
			if (freq[n] > freq[median]) {
				median = n;
				modes.clear();
				modes.add(n);
			}
			else if (freq[n] == freq[median]) {
				modes.add(n);
			}
			total += n;
		}
		Collections.sort(arr);
		int range = max-min;
		total /= count;
		double m;
		if (arr.size() % 2 == 1) m = arr.get(arr.size()/2);
		else m = ((double)(arr.get(arr.size()/2)) + arr.get(arr.size()/2)+1) / 2;
		System.out.println("Average: " + total);
		System.out.println("Maximum: " + max);
		System.out.println("Range: " + range);
		System.out.print("Mode: ");
		for (int i: modes) System.out.print(i + " ");
		System.out.println();
		System.out.println("Median: " + m);
		System.out.print(" 1 -   5 :  ");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print(" 6 -  10 :  ");
		for (int i = 6; i <= 10; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("11 -  15 :  ");
		for (int i = 11; i <= 15; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("16 -  20 :  ");
		for (int i = 16; i <= 20; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("21 -  25 :  ");
		for (int i = 21; i <= 25; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("26 -  30 :  ");
		for (int i = 26; i <= 30; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("31 -  35 :  ");
		for (int i = 31; i <= 35; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("36 -  40 :  ");
		for (int i = 36; i <= 40; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("41 -  45 :  ");
		for (int i = 41; i <= 45; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
		System.out.println();
		System.out.print("46 -  50 :  ");
		for (int i = 46; i <= 50; i++) {
			for (int j = 1; j <= freq[i]; j++) {
				System.out.print("*");
			}
		}
	}
}

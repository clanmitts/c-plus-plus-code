package school;


// I started the index at 1 so when you try to do the 
import java.util.Arrays;
import java.util.Scanner;

public class Chapter_10_Exercise_Extra {
	static Scanner input = new Scanner(System.in);
	static char [][] board = new char [4][4];
	public static void initBoard() {
		Arrays.fill(board[1], '-');
		Arrays.fill(board[2], '-');
		Arrays.fill(board[3], '-');
	}
	public static void displayBoard() {
		System.out.println(board[1][1]+ "" +board[1][2] + "" +board[1][3]);
		System.out.println(board[2][1]+ "" +board[2][2] + "" +board[2][3]);
		System.out.println(board[3][1]+ "" +board[3][2] + "" +board[3][3]);
	}
	public static int checkWin() {
		for (int i = 1; i <= 3; i++) {
			if (board[i][1] == 'X' && board[i][1] == board[i][2] && board[i][1] == board[i][3]) return 1;
			if (board[i][1] == 'O' && board[i][1] == board[i][2] && board[i][1] == board[i][3]) return 2;
			if (board[1][i] == 'X' && board[1][i] == board[2][i] && board[1][i] == board[3][i]) return 1;
			if (board[1][i] == 'O' && board[1][i] == board[2][i] && board[1][i] == board[3][i]) return 2;
		}
		if (board[1][1] == 'X' && board[1][1] == board[2][2] && board[1][1] == board[3][3]) return 1;
		if (board[1][1] == 'O' && board[1][1] == board[2][2] && board[1][1] == board[3][3]) return 2;
		if (board[3][1] == 'X' && board[3][1] == board[2][2] && board[3][1] == board[1][3]) return 1;
		if (board[3][1] == 'O' && board[3][1] == board[2][2] && board[3][1] == board[1][3]) return 2;
		return 0;
	}
	public static void x() {
		System.out.print("Player #1 enter a row(1-3): ");
		int r = input.nextInt();
		System.out.print("Player #1 enter a column(1-3): ");
		int c = input.nextInt();
		if (board[r][c] != 'O' && board[r][c] != 'X') board[r][c] = 'X';
		else {
			System.out.println("That spot is already taken!!");
			x();
		}
	}
	public static void o() {
		System.out.print("Player #2 enter a row (1-3): ");
		int r = input.nextInt();
		System.out.print("Player #2 enter a column(1-3): ");
		int c = input.nextInt();
		if (board[r][c] != 'O' && board[r][c] != 'X') board[r][c] = 'O';
		else {
			System.out.println("That spot is already taken!!");
			o();
		}
	}
	public static void main(String[] args) {
		initBoard();
		while (true) {
			displayBoard();
			x();
			if (checkWin() != 0) break;
			System.out.println(board[0][0]);
			displayBoard();
			o();
			if (checkWin() != 0) break;
		}
		if (checkWin() == 1) System.out.println("Player #1 WINS!!!");
		else System.out.println("Player #2 WINS!!!");
		displayBoard();
	}
}
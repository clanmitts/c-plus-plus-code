package school;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Chapter_7_Exercise_5 {
	 private static final DecimalFormat df = new DecimalFormat("0.00");
	public static String getDollarAmount(int q, int d, int n, int p) {
		double total = 0;
		total += q*0.25;
		total += d*0.10;
		total += n*0.05;
		total += p*0.01;
		return "$" + df.format(total);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter yout total coins: \n");
		System.out.print("Quarters: ");
		int q = input.nextInt();
		System.out.print("Dimes: ");
		int d = input.nextInt();
		System.out.print("Nickels: ");
		int n = input.nextInt();
		System.out.print("Pennies: ");
		int p = input.nextInt();
		System.out.print("Total: ");
		System.out.println(getDollarAmount(q, d, n, p));;
	}
}

package school;

import java.util.Scanner;

public class test2 {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int h, w, p, d;
		double m;
		System.out.print("Height: ");
		h = input.nextInt();
		System.out.print("Weight: ");
		w = input.nextInt();
		System.out.print("Pulse Pressure: ");
		p = input.nextInt();
		System.out.print("Diastolic pressure: ");
		d = input.nextInt();
		m = d + (p/3);
		if (h > 137 && w >= 60 && h <= 221 && w <= 300 && m >= 60) System.out.println("can ride");
		else System.out.println("cannot ride");
	}
}

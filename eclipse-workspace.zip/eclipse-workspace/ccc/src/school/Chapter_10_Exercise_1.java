package school;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Chapter_10_Exercise_1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random rand = new Random();
		int [] odd = new int [26];
		Arrays.fill(odd, -1);
		int [] even = new int [26];
		Arrays.fill(even, -1);
		int o = 1;
		int e = 1;
		for (int i = 1; i <= 25; i++) {
			int temp = rand.nextInt(100);
			if (temp%2 == 1) {
				odd[o] = temp;
				o++;
			}
			else {
				even[e] = temp;
				e ++;
			}
		}
		System.out.println("ODD:");
		for (int i = 1; i <= 25; i++) {
			if (odd[i] == -1) break;
			System.out.print(odd[i] + " ");
		}
		System.out.println();
		System.out.println("EVEN");
		for (int i = 1; i <= 25; i++) {
			if (even[i] == -1) break;
			System.out.print(even[i] + " ");
		}
		System.out.println();
	}
}

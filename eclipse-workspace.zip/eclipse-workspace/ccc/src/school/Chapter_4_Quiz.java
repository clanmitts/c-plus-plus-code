package school;

import java.util.Scanner;

public class Chapter_4_Quiz {
	static double amount, principal, rate, years;
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Amount: ");
		amount = input.nextDouble();
		System.out.print("Enter the Principal: ");
		principal = input.nextDouble();
		System.out.print("Enter the rate: ");
		rate = input.nextDouble();
		years = (amount/principal-1)/rate;
		System.out.print("The time period is ");
		System.out.format("%.1f", years);
	}
}

package school;

import java.io.IOException;
import java.util.Scanner;

public class Chapter_4_Exercise_12 {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		double total;
		double designing, coding, debugging, testing;
		System.out.println("Enter the number of minutes spent on either of the following project task\n");
		System.out.print("Designing: ");
		designing = input.nextDouble();
		System.out.print("Coding: ");
		coding = input.nextDouble();
		System.out.print("Debugging: ");
		debugging = input.nextDouble();
		System.out.print("Testing: ");
		testing = input.nextDouble();
		total = designing + coding + debugging + testing;
		System.out.println("\nTask\t\t%Time");
		System.out.println("Designing\t" + designing/total*100 + " %");
		System.out.println("Coding\t\t" + coding/total*100 + " %");
		System.out.println("Debugging\t" + debugging/total*100 + " %");
		System.out.println("Testing\t\t" + testing/total*100 + " %");
		
	}
}

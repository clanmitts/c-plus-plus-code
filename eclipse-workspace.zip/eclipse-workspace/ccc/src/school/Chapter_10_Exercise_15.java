package school;

import java.util.Scanner;

// not finished

class mankala {
	static int [][] board = new int [3][8]; 
	static Scanner input = new Scanner(System.in);
	static void printRules() {
		System.out.println("Players sit on opposite sides with the large bin to a player�s right designated her home bin. On a turn,\r\n"
				+ "a player selects one of the six pits to remove the stones from and then �sows� the stones counterclockwise around the board, \r\n"
				+ "placing one stone in each pit including the player�s home bin (but excluding\r\n"
				+ "the opponent�s home bin). If the last stone lands in the player�s home bin, the player gets another turn.\r\n"
				+ "If the last stone lands in an empty pit on the player�s side of the board, the player takes all stones in\r\n"
				+ "the corresponding pit on the opponent�s side and places them in the player�s home bin. When a player\r\n"
				+ "cannot play, the game is over and all stones remaining in the opponent�s pits go to the opponent�s home\r\n"
				+ "bin. The winner is the player with the most stones in the player�s home bin at the end of the game.\r\n"
				+ "Each pit will start with 3 stones.");
	}
	static void createGame() {
		for (int i = 1; i <= 6; i++) {
			board[0][i] = 3;
			board[2][i] = 3;
		}
		board[1][0] = 0;
		board[1][7] = 0;
	}
	static void printGameState() {
		System.out.print("Player 1\t\t");
		for (int i = 1; i <= 6; i++) {
			System.out.print(board[0][i] + "\t");
		}
		System.out.println();
		System.out.println("\t\t" + board[1][0] + "\t\t\t\t\t\t\t" + board[1][7]);
		System.out.print("Player 2\t\t");
		for (int i = 1; i <= 6; i++) {
			System.out.print(board[2][i] + "\t");
		}
		System.out.println();
		System.out.print("\t\t\t");
		for (int i = 'A'; i <= 'F'; i++) {
			System.out.print((char)(i) + "\t");
		}
		System.out.println();
	}
	static void playerOneTurn() {
		System.out.print("Player 1, what column do you want to sow?(capital) ");
		int sow = input.nextLine().charAt(0);
		int a = 0;
		int b = sow-'A'+1;
		int count = board[a][b];
		board[a][b] = 0;
		for (int i = 1; i <= count; i++) {
			if (a == 0) {
				if (b > 1) {
					b--;
					board[a][b]++;
				}
				else {
					a = 1;
					b = 0;
					board[a][b] ++;
				}
			}
			else if (a == 1) {
				a = 2;
				b = 1;
				board[a][b] ++;
			}
			else if (a == 2) {
				if (b < 6) {
					b++;
					board[a][b]++;
				}
				else {
					a = 0;
					b = 6;
					board[a][b] ++;
				}
			}
		}
		if (a == 0 && board[a][b] == 1) {
			board[1][0] += board[2][b];
			board[2][b] = 0;
		}
		if (a == 1 && b == 0) {
			printGameState();
			playerOneTurn();
		}
	}
	static void playerTwoTurn() {
		System.out.print("Player 2, what column do you want to sow?(capital) ");
		int sow = input.nextLine().charAt(0);
		int a = 2;
		int b = sow-'A'+1;
		int count = board[a][b];
		board[a][b] = 0;
		for (int i = 1; i <= count; i++) {
			if (a == 0) {
				if (b > 1) {
					b--;
					board[a][b]++;
				}
				else {
					a = 2;
					b = 1;
					board[a][b] ++;
				}
			}
			else if (a == 1) {
				a = 0;
				b = 6;
				board[a][b] ++;
			}
			else if (a == 2) {
				if (b < 6) {
					b++;
					board[a][b]++;
				}
				else {
					a = 1;
					b = 7;
					board[a][b] ++;
				}
			}
		}
		if (a == 2 && board[a][b] == 1) {
			board[1][7] += board[0][b];
			board[0][b] = 0;
		}
		if (a == 1 && b == 7) {
			printGameState();
			playerTwoTurn();
		}
	}
	static boolean checkGameOver() {
		return (checkOne() || checkTwo());
	}
	static boolean checkOne() {
		for (int i = 1; i <= 6; i++) {
			if (board[0][i] != 0) return false;
		}
		return true;
	}
	static boolean checkTwo() {
		for (int i = 1; i <= 6; i++) {
			if (board[2][i] != 0) return false;
		}
		return true;
	}
}

public class Chapter_10_Exercise_15 {
	public static void main(String[] args) {
		mankala game = new mankala();
		game.printRules();
		game.createGame();
		while (true) {
			game.printGameState();
			game.playerOneTurn();
			if (game.checkGameOver()) break;
			game.printGameState();
			game.playerTwoTurn();
			if (game.checkGameOver()) break;
			
		}
		if (game.board[1][0] > game.board[1][7]) System.out.println("Player 1 wins");
		else if (game.board[1][0] < game.board[1][7]) System.out.println("Player 2 wins");
		else System.out.println("Tie");
	}
}

package school;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Chapter_4_Exercise_7 {
	static String str;
	public static void main(String[] args) throws IOException {
		System.out.print("Enter a three-digit number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		str = st.nextToken();
		System.out.format("\nThe hundreds-place digit is: " + str.charAt(0));
		System.out.format("\nThe tens-place digit is: " + str.charAt(1));
		System.out.format("\nThe ones-place digit is: " + str.charAt(2));
	}
}

package school;

import java.util.Scanner;

public class Chapter_6_Exercise_2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int counter = 2;
		int n = input.nextInt();
		while (counter <= n) {
			if (n % counter == 0) {
				System.out.println(counter);
				n /= counter;
			}
			else {
				counter ++;
			}
		}
		
	}
}

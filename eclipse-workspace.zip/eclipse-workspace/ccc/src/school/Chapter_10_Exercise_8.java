package school;

import java.util.Scanner;

public class Chapter_10_Exercise_8 {
	public static void isPalindrome(String str) {
		str = str.replaceAll("\\s","");
		str = str.toLowerCase();
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != str.charAt(str.length()-i-1)) {
				System.out.println("It is not a palindrome. ");
				return;
			}
		}
		System.out.println("It is a palindrome. ");
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str = input.nextLine().trim();
		isPalindrome(str);
		
	}
}

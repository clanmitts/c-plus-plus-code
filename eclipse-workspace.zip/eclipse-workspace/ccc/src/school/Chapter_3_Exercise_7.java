package school;

public class Chapter_3_Exercise_7 {
	public static void main(String[] args) {
		System.out.print("\n"
				+ "    *****\n"
				+ "   *     *\n"
				+ "  * _   _ *\n"
				+ " *  o   o  *\n"
				+ "*     :     *\n"
				+ "*     +     *\n"
				+ " *  \\___/  *\n"
				+ "   *      *\n"
				+ "    *****\n");
	}
}

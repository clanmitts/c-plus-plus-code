package Chess;

public class movement {
	public static void move(char ) {
		
	}
}

package Chess;

import java.util.Arrays;

public class board {
	public static char board [][] = new char [17][33];
	public static void reset() {
		for (int i = 0; i <= 16; i+= 2) {
			Arrays.fill(board[i], '-');
		}
		for (int i = 1; i <= 15; i+= 2) {
			for (int j = 0; j <= 32; j++) {
				if (j%4 == 0) board[i][j] = '|';
				else board[i][j] = ' ';
			}
		}
	}
	public static void print() {
		for (int i = 0; i <= 16; i++) {
			for (int j = 0; j <= 32; j++) {
				System.out.print(board[i][j]);
			}
			System.out.println();
		}
	}
}

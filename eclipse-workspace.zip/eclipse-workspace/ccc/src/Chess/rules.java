package Chess;

public class rules {
	public static void print() {
		
	}
}

package Grade_11_Culminating;

import java.util.ArrayList;

public class snake {
	public static class pair {
		int x;
		int y;
		public pair(int i, int j) {
			x = i;
			y = j;
		}
	}
	public static ArrayList<pair> snake = new ArrayList<pair>();
	public static void build() {
		snake.add(new pair(10, 10));
	}
}

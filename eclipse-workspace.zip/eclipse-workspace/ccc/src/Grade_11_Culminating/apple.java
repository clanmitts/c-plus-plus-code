package Grade_11_Culminating;

import java.util.Random;

public class apple {
	public static boolean eaten = false;
	public static void place() {
		Random rand = new Random();
		while (true) {
			int a = rand.nextInt(20)+1;
			int b = rand.nextInt(20)+1;
			if (grid.grid[a][b] == '.') {
				grid.grid[a][b] = 'A';
				eaten = true;
				return;
			}
		}
	}
}

package Grade_11_Culminating;

import java.io.IOException;
import java.util.TimerTask;

public class Main {
	public static boolean game_over = false;
	
	public static void main(String[] args) throws IOException, InterruptedException {
		//print out the rules
		print_rules.print();
		snake.build();
		grid.build();
		while (!game_over) {
			try
	        {
	            (new test()).getInput();
	        }
	        catch( Exception e )
	        {
	            System.out.println( e );
	        }
		}
	}
}

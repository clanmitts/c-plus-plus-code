package Grade_11_Culminating;

public class grid {
	public static char [][] grid = new char [21][21];
	public static void build() {
		for (int i = 1; i <= 20; i++) {
			for (int j = 1; j <= 20; j++) {
				grid[i][j] = '.';
			}
		}
		grid[snake.snake.get(0).x][snake.snake.get(0).y] = 'S';
		apple.place();
	}
	public static void display() {
		for (int i = 1; i <= 20; i++) {
			for (int j = 1; j <= 20; j++) {
				System.out.print(grid[i][j]);
			}
			System.out.println();
		}
	}
}

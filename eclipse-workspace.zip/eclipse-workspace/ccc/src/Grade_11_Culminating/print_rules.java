package Grade_11_Culminating;

import java.util.Scanner;

public class print_rules {
	public static void print() {
		Scanner input = new Scanner(System.in);
		System.out.println(
				  "Welcome to the game Snake.\n"
				+ "In this game, you control a snake whose goal is to collect apples.\n"
				+ "You snake will be represented as * with S as the head of the snake\n"
				+ "Apples will be represented as A\n"
				+ "Move using the WASD keys. However, make sure caps lock is off or else the snake won't move.\n"
				+ "Apples will spawn on the grid and it's your objective you find a way to the apple and eat it.\n"
				+ "However, you can't run into your own body or the walls or else you will die.\n"
				+ "It's best to extend your consol all the way\n"
				+ "When you are ready to start, type anything then press enter\n");
		String nothing = input.nextLine();
	}
}

package Battleship;

import java.util.Random;

public class computer_turn {
	public static void guess() {
		Random rand = new Random();
		char a = (char) (rand.nextInt(10)+1);
		char b = (char) (rand.nextInt(10)+1);
		if (computer_view.player_grid[a][b] != '*') {
			guess();
			return;
		}
		char c = (char) (a+'A'-1);
		char d = (char) (b +'0'-1);
		System.out.println("Computer shot at " + String.valueOf(c) + String.valueOf(d));
		if (player_view.player_grid[a][b] != '*') {
			computer_view.ships_hit ++;
			computer_view.player_grid[a][b] = 'X';
			player_view.player_grid[a][b] = 'X';
			player_view.display_player_grid();
			System.out.println("HIT!!");
		}
		else {
			computer_view.player_grid[a][b] = 'O';
			player_view.display_player_grid();
			System.out.println("MISS!!");
		}
	}
	public static void congrats() {
		player_view.display_player_grid();
		System.out.println("The computer won!!");
	}
}

package Battleship;

public class rules {
	public static void print_rules() {
		System.out.println("Welcome to battle ship. \r\n"
				+ "You and the computer will have a 10x10 grid with the x coordinates being labled from 0-9 and the y coordinated labled A-J\r\n"
				+ "On the board, both you and the computer will place 2 ships of lenght 3, 1 ship of length 3, and 1 ship of length 5.\r\n"
				+ "water will be represented by *\r\n"
				+ "On your grid, ships will be represented by O. When they are hit, they will now be represented by X\r\n"
				+ "On your perspective of the computers grid, you will see all water at first. \r\n"
				+ "If you hit a ship with your guess, that coordinate will now be represented with a X\r\n"
				+ "If you miss the ships with your guess, that coordinate will now be represented with a O\r\n"
				+ "To input a coordinate, you first write the letter in uppercase then the number\r\n"
				+ "Examples are A7, C0, and J9\r\n"
				+ "When all points of a ship is hit, it will sink. However, you will not know\r\n"
				+ "The first player to sink all ships wins\r\n"
				+ "It is reccomended for the console to take up the entire screen\r\n"
				+ "You will always go first");
	}
}

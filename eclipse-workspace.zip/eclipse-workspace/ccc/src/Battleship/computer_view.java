package Battleship;

import java.util.Random;

public class computer_view {
	public static char [][] computer_grid = new char [11][11];
	public static char [][] player_grid = new char [11][11];
	public static int ships_hit = 0;
	public static void create_computer_grid() {
		for (int i = 1; i <= 10; i++) {
			computer_grid[i][0] = (char) ('A' + i);
			computer_grid[0][i] = (char) ('1' + i);
		}
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				computer_grid[i][j] = '*';
			}
		}
	}
	public static void create_player_grid() {
		for (int i = 1; i <= 10; i++) {
			player_grid[i][0] = (char) ('A' + i);
			player_grid[0][i] = (char) ('1' + i);
		}
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				player_grid[i][j] = '*';
			}
		}
	}
	public static void display_computer_grid() {
		for (int i = 0; i <= 10; i++) {
			for (int j = 0; j <= 10; j++) {
				System.out.print(computer_grid[i][j]);
			}
			System.out.println();
		}
	}
	public static void three_boat() {
		Random rand = new Random();
		int a = rand.nextInt(10)+1;
		int b = rand.nextInt(10)+1;
		int c = rand.nextInt(10)+1;
		int d = rand.nextInt(10)+1;
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 3) || (b==d && a-c+1 == 3))) {
			three_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (computer_grid[a][i] != '*') {
					three_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				computer_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (computer_grid[i][b] != '*') {
					three_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				computer_grid[i][b] = 'O';
			}
		}
	}
	public static void four_boat() {
		Random rand = new Random();
		int a = rand.nextInt(10)+1;
		int b = rand.nextInt(10)+1;
		int c = rand.nextInt(10)+1;
		int d = rand.nextInt(10)+1;
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 4) || (b==d && a-c+1 == 4))) {
			four_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (computer_grid[a][i] != '*') {
					four_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				computer_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (computer_grid[i][b] != '*') {
					four_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				computer_grid[i][b] = 'O';
			}
		}
	}
	public static void five_boat() {
		Random rand = new Random();
		int a = rand.nextInt(10)+1;
		int b = rand.nextInt(10)+1;
		int c = rand.nextInt(10)+1;
		int d = rand.nextInt(10)+1;
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 5) || (b==d && a-c+1 == 5))) {
			five_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (computer_grid[a][i] != '*') {
					five_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				computer_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (computer_grid[i][b] != '*') {
					five_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				computer_grid[i][b] = 'O';
			}
		}
	}
	public static void generate_boats() {
		three_boat();
		three_boat();
		four_boat();
		five_boat();
	}
}

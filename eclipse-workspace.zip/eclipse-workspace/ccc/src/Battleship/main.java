package Battleship;

public class main {
	public static void main(String[] args) {
		rules.print_rules();
		player_view.create_player_grid();
		player_view.create_computer_grid();
		player_view.generate_boats();
		computer_view.create_computer_grid();
		computer_view.create_player_grid();
		computer_view.generate_boats();
		while (true) {
			player_turn.guess();
			if (player_view.ships_hit == 15) {
				player_turn.congrats();
				break;
			}
			computer_turn.guess();
			if (computer_view.ships_hit == 15) {
				computer_turn.congrats();
				break;
			}
		}
	}
}

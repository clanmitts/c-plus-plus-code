package Battleship;

import java.util.Scanner;

public class player_turn {
	public static void guess () {
		Scanner input = new Scanner(System.in);
		player_view.display_computer_grid();
		String str;
		int a = 0;
		int b = 0;
		try {
			System.out.println("Player 1, guess a coordinate: ");
			str = input.nextLine().trim();
			a = str.substring(0, 1).toUpperCase().charAt(0)-'A'+1;
			b = str.charAt(1)-'0'+1;
		}
		catch (StringIndexOutOfBoundsException e) {
			System.out.println("Please enter a coordinate");
			guess();
			return;
		}
		if (a < 1 || a > 10 || b < 1 || b > 10) {
			System.out.println("Please shoot somewhere inside the grid. ");
			guess();
			return;
		}
		if (player_view.computer_grid[a][b] != '*') {
			System.out.println("You already shot here");
			guess();
			return;
		}
		if (computer_view.computer_grid[a][b] != '*') {
			player_view.ships_hit += 1;
			player_view.computer_grid[a][b] = 'X';
			player_view.display_computer_grid();
			System.out.println("HIT!!");
		}
		else {
			player_view.computer_grid[a][b] = 'O';
			player_view.display_computer_grid();
			System.out.println("MISS!!");
		}
	}
	public static void congrats() {
		player_view.display_computer_grid();
		System.out.println("Congratulation you win!!");
	}
}

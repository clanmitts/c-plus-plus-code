package Battleship;

import java.util.Scanner;

public class player_view {
	public static char [][] player_grid = new char [11][11];
	public static char [][] computer_grid = new char[11][11];
	public static int ships_hit = 0;
	public static void create_player_grid() {
		for (int i = 0; i <= 9; i++) {
			player_grid[i+1][0] = (char) ('A' + i);
			player_grid[0][i+1] = (char) ('0' + i);
		}
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				player_grid[i][j] = '*';
			}
		}
	}
	public static void create_computer_grid() {
		for (int i = 0; i <= 9; i++) {
			computer_grid[i+1][0] = (char) ('A' + i);
			computer_grid[0][i+1] = (char) ('0' + i);
		}
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				computer_grid[i][j] = '*';
			}
		}
	}
	public static void display_player_grid() {
		System.out.println("\nPlayer grid\n");
		for (int i = 0; i <= 10; i++) {
			for (int j = 0; j <= 10; j++) {
				System.out.print(player_grid[i][j]);
			}
			System.out.println();
		}
	}
	public static void display_computer_grid() {
		System.out.println("\nComputer grid\n");
		for (int i = 0; i <= 10; i++) {
			for (int j = 0; j <= 10; j++) {
				System.out.print(computer_grid[i][j]);
			}
			System.out.println();
		}
	}
	public static void three_boat() {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		String str;
		int a = 0;
		int b = 0;
		try {
			System.out.println("Enter start coordinate for a 3 segment boat: ");
			str = input.nextLine().trim();
			str.substring(0,1).toUpperCase();
			a = str.charAt(0)-'A'+1;
			b = str.charAt(1)-'0'+1;
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println("Please Enter a coordinate");
			three_boat();
			return;
		}
		if (a < 1 || a > 10 || b < 1 || b > 10) {
			System.out.println("That boat won't fit on the grid");
			three_boat();
			return;
		}
		System.out.println("Enter end coordinate for a 3 segment boat: ");
		str = input.nextLine().trim();
		str.substring(0,1).toUpperCase();
		int c = str.charAt(0)-'A'+1;
		int d = str.charAt(1)-'0'+1;
		if (c < 1 || c > 10 || d < 1 || d > 10) {
			System.out.println("That boat won't fit on the grid");
			three_boat();
			return;
		}
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 3) || (b==d && a-c+1 == 3))) {
			System.out.println("This is not a 3 segment boat");
			three_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (player_grid[a][i] != '*') {
					System.out.println("This will colide with another boat");
					three_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				player_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (player_grid[i][b] != '*') {
					System.out.println("This will colide with another boat");
					three_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				player_grid[i][b] = 'O';
			}
		}
	}
	public static void four_boat() {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		String str;
		int a = 0;
		int b = 0;
		try {
			System.out.println("Enter start coordinate for a 4 segment boat: ");
			str = input.nextLine().trim();
			str.substring(0,1).toUpperCase();
			a = str.charAt(0)-'A'+1;
			b = str.charAt(1)-'0'+1;
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println("Please Enter a coordinate");
			four_boat();
			return;
		}
		if (a < 1 || a > 10 || b < 1 || b > 10) {
			System.out.println("That boat won't fit on the grid");
			four_boat();
			return;
		}
		System.out.println("Enter end coordinate for a 4 segment boat: ");
		str = input.nextLine().trim();
		str.substring(0,1).toUpperCase();
		int c = str.charAt(0)-'A'+1;
		int d = str.charAt(1)-'0'+1;
		if (c < 1 || c > 10 || d < 1 || d > 10) {
			System.out.println("That boat won't fit on the grid");
			four_boat();
			return;
		}
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 4) || (b==d && a-c+1 == 4))) {
			System.out.println("This is not a 4 segment boat");
			four_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (player_grid[a][i] != '*') {
					System.out.println("This will colide with another boat");
					four_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				player_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (player_grid[i][b] != '*') {
					System.out.println("This will colide with another boat");
					four_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				player_grid[i][b] = 'O';
			}
		}
	}
	public static void five_boat() {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		String str;
		int a = 0;
		int b = 0;
		try {
			System.out.println("Enter start coordinate for a 5 segment boat: ");
			str = input.nextLine().trim();
			str.substring(0,1).toUpperCase();
			a = str.charAt(0)-'A'+1;
			b = str.charAt(1)-'0'+1;
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println("Please Enter a coordinate");
			five_boat();
			return;
		}
		if (a < 1 || a > 10 || b < 1 || b > 10) {
			System.out.println("That boat won't fit on the grid");
			five_boat();
			return;
		}
		System.out.println("Enter end coordinate for a 5 segment boat: ");
		str = input.nextLine().trim();
		str.substring(0,1).toUpperCase();
		int c = str.charAt(0)-'A'+1;
		int d = str.charAt(1)-'0'+1;
		if (c < 1 || c > 10 || d < 1 || d > 10) {
			System.out.println("That boat won't fit on the grid");
			five_boat();
			return;
		}
		if (a < c) {
			int temp = a;
			a = c;
			c = temp;
		}
		if (b < d) {
			int temp = b;
			b = d;
			d = temp;
		}
		if (!((a==c && b-d+1 == 5) || (b==d && a-c+1 == 5))) {
			System.out.println("This is not a 3 segment boat");
			five_boat();
			return;
		}
		if (a == c) {
			for (int i = d; i <= b; i++) {
				if (player_grid[a][i] != '*') {
					System.out.println("This will colide with another boat");
					five_boat();
					return;
				}
			}
			for (int i = d; i <= b; i++) {
				player_grid[a][i] = 'O';
 			}
		}
		else {
			for (int i = c; i <= a; i++) {
				if (player_grid[i][b] != '*') {
					System.out.println("This will colide with another boat");
					five_boat();
					return;
				}
			}
			for (int i = c; i <= a; i++) {
				player_grid[i][b] = 'O';
			}
		}
	}
	public static void generate_boats() {
		display_player_grid();
		three_boat();
		display_player_grid();
		three_boat();
		display_player_grid();
		four_boat();
		display_player_grid();
		five_boat();
		display_player_grid();
	}
}

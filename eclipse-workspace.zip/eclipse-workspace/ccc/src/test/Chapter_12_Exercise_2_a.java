package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.StringTokenizer;

 class pair {
	public pair(String str, int n) {
		word = str;
		freq = n;
	}
	String word;
	int freq;

}

public class Chapter_12_Exercise_2_a {
	static String [] word = new String [100000];
	static int [] freq = new int [1000000];
	static void swap(int a, int b){
        int temp = freq[a];
        freq[a] = freq[b];
        freq[b] = temp;
        String t = word[a];
        word[a] = word[b];
        word[b] = t;
    }
    static int partition(int l, int r) {
        int pivot = freq[r];
        int i = (l - 1);
 
        for (int j = l; j <= r - 1; j++) {
            if (freq[j] > pivot) {
                i++;
                swap(i, j);
            }
        }
        swap(i + 1, r);
        return (i + 1);
    }
    static void quickSort(int low, int high){
        if (low < high) {
            int pi = partition(low, high);
            quickSort(low, pi - 1);
            quickSort(pi + 1, high);
        }
    }
	public static void main(String[] args) throws IOException{
		pair [] arr = new pair [100000];
		File f = new File("words.txt");
		FileReader fr = null;
		try {
			fr = new FileReader(f);
		}
		catch (FileNotFoundException e) {
			System.out.println("Can't find file");
			System.exit(0);
		}
		BufferedReader br = new BufferedReader(fr);
		String str;
		HashMap<String, Integer> m = new HashMap<String, Integer>();
		int l = 0;
		int r = 0;
		while ((str = br.readLine()) != null) {
			str = str.toLowerCase();
			l = 0;
			r = 1;
			while (r < str.length()) {
				while (r < str.length() && ('a' <= str.charAt(r) && str.charAt(r) <= 'z')) {
					r++;
				}
				String temp = str.substring(l, r);
				if (m.containsKey(temp)) {
					m.put(temp, m.get(temp)+1);
				}
				else {
					m.put(temp, 1);
				}
				while (l < str.length() && (l <= r || !(l < str.length() && 'a' <= str.charAt(l) && str.charAt(l) <= 'z'))) {
					l++;
				}
				r = l+1;
			}
		}
		int ind = 0;
		
		Arrays.fill(arr, new pair("", 0));
		for (Map.Entry<String,Integer> mapElement : m.entrySet()) {
			ind ++;
			String key = mapElement.getKey();
			int value = mapElement.getValue()+0;
            word[ind] = key;
            freq[ind] = (value);
        }
		quickSort(1, ind);
		for (int i = 1; i <= ind; i++) {
			System.out.println(word[i] + "\t\t" + freq[i]);
		}
		
	}
}

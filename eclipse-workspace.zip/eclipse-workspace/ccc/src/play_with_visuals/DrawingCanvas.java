package play_with_visuals;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class DrawingCanvas extends JComponent{
	private int width;
	private int height;
	private cloud c1;
	private cloud c2;
	public DrawingCanvas(int w, int h) {
		width = w;
		height = h;
		c1 = new cloud(200, 75, 100, Color.MAGENTA);
	}
	
	@Override
	
	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		
		RenderingHints rh = new RenderingHints (
			RenderingHints.KEY_ANTIALIASING, // makes the shapes smoother
			RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);
		
		Rectangle2D.Double r = new Rectangle2D.Double(0, 0, width, height); // start x coordinate, start y coordinate, x length, y length
		g2d.setColor(new Color(100, 149, 237));//The numbers here are the colour values. You can also use colour constants
		g2d.fill(r); //puts the shape on the screen. The shapes filled first will be behind the shapes filled later
		
		Ellipse2D.Double e = new Ellipse2D.Double(0, 0, 100, 100);// things are the same as the rectangle. top left x and y. Then the width and length
		g2d.setColor(Color.BLUE);
		g2d.fill(e);
		
		Line2D.Double line = new Line2D.Double(100, 250, 300, 75);
		g2d.setColor(Color.BLACK);
		g2d.draw(line);
		
		c1.drawCloud(g2d);
		
		g2d.setColor(Color.BLACK);
		Path2D.Double p = new Path2D.Double();
		p.moveTo(100,  300); // moves to a different location without drawing a line
		p.lineTo(150, 200); // moves to a different location drawing a line along the way
		p.lineTo(200,  300);
		p.closePath();
		g2d.draw(p); //g2d.draw connects the first and last point. g2d.fill fills the shape in after
		
		Path2D.Double curve = new Path2D.Double();
		curve.moveTo(250,  400);
		curve.curveTo(350,  300,  500,  300,  600,  400); // first 4 are the two points for the bezier curve. The last 2 is the end point
		curve.closePath();
		g2d.fill(curve);
		g2d.translate(150, 100);// how many pixels right and how many pixels down
		g2d.draw(curve);
	}
}

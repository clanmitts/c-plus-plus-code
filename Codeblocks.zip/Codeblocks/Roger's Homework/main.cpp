#include <bits/stdc++.h>

using namespace std;

int n;
pair<int, int> arr [1000001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[i] = {a, b};
    }

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

class point {
    public:
        int a;
        int b;
};

int n, m;
string arr [101];
int dis [101][101];
bool vis [101][101];
point s;
deque<point> q;
int xaxis [4] = {1, -1, 0, 0};
int yaxis [4] = {0, 0, 1, -1};
point next;
char directions [4] = {'U', 'D', 'L', 'R'};
point path [4] = {(-1, 0), (1, 0), (0, -1), (0, 1)};
bool contains(char a) {
    for (int i = 0; i < 4; i++) {
        if (a == directions[i]) return true;
    }
    return false;
}
int indexOf(char a) {
    for (int i = 0; i < 4; i++) {
        if (directions[i] == a) {
            return i;
        }
    }
    return -1;
}
void up(int i, int j) {
    if (contains(arr[i][j])) {
        up(i-1, j);
    }
    else if (arr[i][j] != 'W') {
        vis[i][j] = true;
        up(i-1, j);
    }
}
void down(int i, int j) {
    if (contains(arr[i][j])) {
        down(i+1, j);
    }
    else if (arr[i][j] != 'W') {
        vis[i][j] = true;
        down(i+1, j);
    }
}
void left(int i, int j) {
    if (contains(arr[i][j])) {
        left(i, j-1);
    }
    else if (arr[i][j] != 'W') {
        vis[i][j] = true;
        left(i, j-1);
    }
}
void right(int i, int j) {
    if (contains(arr[i][j])) {
        right(i, j+1);
    }
    else if (arr[i][j] != 'W') {
        vis[i][j] = true;
        right(i, j+1);
    }
}

void camera(int i, int j) {
    up(i, j);
    down(i, j);
    left(i, j);
    right(i, j);
}

main() {
    cin >> n;
    cin >> m;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (arr[i][j] == 'W') vis[i][j] = true;
            if (arr[i][j] == 'S') {
                    s.a = i;
                    s.b = j;
            }
            if (arr[i][j] == 'C') camera(i, j);
        }
    }
    for (int i = 0; i < n; i++) {
        fill(&dis[0][0],&dis[0][0] + sizeof(dis) / sizeof(dis[0][0]),-1);
    }
    dis[s.a][s.b] = 0;
    if (!vis[s.a][s.b]) {
    q.push_back(s);
        while (!q.empty()) {
            point cur = q.front();
            q.pop_front();
            if (!vis[cur.a][cur.b]) {
                vis[cur.a][cur.b] = true;
                if (contains(arr[cur.a][cur.b])) {
                    next = (cur.a + path[indexOf(arr[cur.a][cur.b])].a,
                            cur.b + path[indexOf(arr[cur.a][cur.b])].b);
                    if (!vis[next.a][next.b]) {
                        dis[next.a][next.b] = dis[cur.a][cur.b];
                        q.addFirst(next);
                    }
                }
                else {
                    for (int i = 0; i < 4; i++) {
                        next = new point(cur.a+xaxis[i], cur.b+yaxis[i]);
                        if (!vis[next.a][next.b]) {
                            if(dis[next.a][next.b]==-1||dis[next.a][next.b]>dis[cur.a][cur.b]+1) {
                                dis[next.a][next.b]= dis[cur.a][cur.b]+1;
                            }
                            q.add(next);
                        }
                    }
                }
            }
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (list[i][j] == '.') System.out.println(dis[i][j]);
        }
    }
}

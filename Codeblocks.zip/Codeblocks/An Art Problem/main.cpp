#include <iostream>
#include <deque>
using namespace std;


int main()
{
    int max = 1000000000;
    int n, m, k;
    cin >> n >> m >> k;
    int list [n+2][m+2];
    bool original [n+2][m+2];
    deque<int []> d;
    for (int i = 0; i <= n+1; i++) {
        for (int j = 0; j <= m+1; j++) {
            list[i][j] = max;
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            int temp [2];
            cin >> list[i][j];
            if (list[i][j] != 0) {
                temp[0] = i;
                temp[1] = j;
                d.push_back(temp);
                original[i][j] = true;
            }
            else {
                list[i][j] = max;
            }
        }
    }
    while (!d.empty()) {
        int cur [2] = d.pop_front();
        if (list[cur[0]+1][cur[1] == max || list[cur[0]-1][cur[1] == max || list[cur[0][cur[1]+1] == max || list[cur[0][cur[1]-1] == max) {
            if ((cur[0]-k >= 1 && original[cur[0]-k][cur[1]) || (cur[0]+k <= n && original[cur[0]+k][cur[1]) ||
                (cur[1]-k >= 1 && original[cur[0][cur[1]-k]) || (cur[1]+k <= m && original[cur[0][cur[1]+k])) {

            }
        }
        if (cur[0] < n && list[cur[0]+1][cur[1] == maxs) {
            l
        }
        if (cur[0] > 1 && list[cur[0]-1][cur[1] == max) {

        }
        if (cur[1] < m && list[cur[0]][cur[1]+1] == max) {

        }
        if (cur[i] > 1 && list[cur[0]][cur[1]-1 == max) {

        }
    }

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

string wish [6][6];
int n;
string str;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5; j++) {
            cin >> wish[i][j];
        }
    }
    for (int i = 1; i <= n; i++) {
        cin >> str;
        for (int i = 0; i < str.length(); i++) {
            if ('a' <= str[i] && str[i] <= 'z') cout << str[i];
            else if ('A' <= str[i] && str[i] <= 'Z') cout << wish[str[i]-'A'+1][str[i+1]-'1'+1][0];
        }
        cout << endl;
    }
    return 0;
}

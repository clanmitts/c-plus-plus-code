#include <bits/stdc++.h>

using namespace std;

long long n;
long long m;
long long total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    if (n < m) swap (n, m);
    if (n%2 == 1 && m % 2 == 1) {
        cout << ((n+1)/2) * m << " " << (n/2) * m << endl;
    }
    else {
        cout << (n*m)/2 << " " << (n*m)/2 << endl;
    }
    return 0;
}

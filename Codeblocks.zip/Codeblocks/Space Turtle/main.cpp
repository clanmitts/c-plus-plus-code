#include <bits/stdc++.h>

using namespace std;
double tx, ty, tz;
double sx, sy, sz;
double x, y, z, newX, t;
int main()
    {
	double closest, distance, d;
	char turn;


	cin >> tx >> ty >> tz;

	cin >> sx >> sy >> sz;

	x = sx - tx;
	y = sy - ty;
	z = sz - tz;

	closest = x * x + y * y + z * z;
	do
	{
	    cin >> distance;
	    cin >> turn;

	    newX = x - distance;

	    if (newX * x < 0)
		closest = min (closest, y * y + z * z);
	    else
		closest = min (closest, newX * newX + y * y + z * z);
	    x = newX;
	    t = x;
	    if (turn == 'L')
	    {
		x = y;
		y = -t;
	    }
	    else if (turn == 'R')
	    {
		x = -y;
		y = t;
	    }
	    else if (turn == 'U')
	    {
		x = z;
		z = -t;
	    }
	    else
	    {
		x = -z;
		z = t;
	    }
	}
	while (turn != 'E');
        cout << ((int) ((sqrt (closest) * 100) + 0.5) / 100.0);
    }

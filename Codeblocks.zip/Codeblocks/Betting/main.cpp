#include <bits/stdc++.h>

using namespace std;

int t;
long double a, b, c, d;
int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> a >> b >> c >> d;
        if ((b/a-1)*(d/c-1)>1 && (b-a)*(d-c) > a*c) cout << "YES" << '\n';
        else cout << "NO" << '\n';
    }
    return 0;
}

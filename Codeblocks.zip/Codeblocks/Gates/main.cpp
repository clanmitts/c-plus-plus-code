#include <bits/stdc++.h>

using namespace std;

int g;
int p;
int n;
int planes [100001];
int total = 0;
int i = 0;
bool thing = true;
int t;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> g;
    cin >> p;
    while (i < p && thing) {
        cin >> n;
        while (n > 0 && planes[n] > 0) {
            int t = planes[n];
            planes[n] ++;
            n -= t;
        }
        if (n <= 0) thing = false;
        else {
            planes[n] = 1;
            total ++;
            i++;
        }
    }
    cout << total << "\n";
    return 0;
}

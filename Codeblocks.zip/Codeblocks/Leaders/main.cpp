#include <bits/stdc++.h>

using namespace std;

const int MAXN = 3e5 + 13;

int n;
string s;
int arr[MAXN];
int eG;
int eH;
int lG;
int lH;
int ans;

int main()
{
    cin >> n >> s;
    for (int i = 0; i < n; i++){
        cin >> arr[i];
        arr[i]--;
    }
    for (int i = 0; i < n; i++){
        if (s[i] == 'G'){
            eG = i;
            break;
        }
    }
    for (int i = n - 1; i >= 0; i--){
        if (s[i] == 'G'){
            lG = i;
            break;
        }
    }
    for (int i = 0; i < n; i++){
        if (s[i] == 'H'){
            eH = i;
            break;
        }
    }
    for (int i = n - 1; i >= 0; i--){
        if (s[i] == 'H'){
            lH = i;
            break;
        }
    }
    if (arr[eG] >= lG){
        for (int i = 0; i < eG; i++){
            if (i == eH) {
                continue;
            }
            if (s[i] == 'H' && arr[i] >= eG){
                ans++;
            }
        }
    }
    if (arr[eH] >= lH){
        for (int i = 0; i < eH; i++){
            if (i == eG){
                continue;
            }
            if (s[i] == 'G' && arr[i] >= eH){
                ans++;
            }
        }
    }
    if ((arr[eG] >= lG || (eG <= eH && arr[eG] >= eH)) && (arr[eH] >= lH || (eH <= eG && arr[eH] >= eG)))
    {
        ans++;
    }
    cout << ans << '\n';
    return 0;
}

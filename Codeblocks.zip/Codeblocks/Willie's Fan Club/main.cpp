#include <bits/stdc++.h>

using namespace std;

int n;
unordered_set<int> blacklist;
int l = 1;
int r = 1;
int input;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    while (r <= n) {
        if (r == l) r++;
        else if (blacklist.count(l) >= 1) l++;
        else if (blacklist.count(r) >= 1) r++;
        else {

            cout << "? " << l << " " << r << endl;
            cin >> input;
            if (input) blacklist.insert(l);
            else blacklist.insert(r);
        }
    }
    for (int i = 1; i <= n; i++) {
        if (blacklist.count(i) == 0) {
            cout << "! " << i << endl;
            break;
        }
    }
    return 0;
}

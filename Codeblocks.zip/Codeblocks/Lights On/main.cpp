#include <bits/stdc++.h>

using namespace std;

string s;
int k;
int l;
int r;

int maxon;
int on;
int off;
bool first;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> s;
    cin >> k;
    l = 0;
    r = 0;
    first = false;
    while (r < s.length()) {
        if (first == false) {
            r = -1;
            first = true;
        }
        r++;
        if (s[r] == '0') {
                off ++;
                on ++;
            }
            if (s[r] == '1') {
                on ++;
            }
        if (off > k) {
            if (s[l] == '0') {
                off--;
                on --;
            }
            if (s[l] == '1') {
                on --;
            }
            l++;
        }
        maxon = max(maxon, on);
    }
    cout << maxon << endl;
    return 0;
}

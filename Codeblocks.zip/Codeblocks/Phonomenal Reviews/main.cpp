#include <bits/stdc++.h>

using namespace std;

int n;
int m;
bool pho [100001];
list<int> arr [100001];
bool used [100001];
int dis [100001];
int start;

int bfs(int x) {
    int total = 0;
    used[x] = true;
    for (int i: arr[x]) {
        if (!used[x]) {

        }
    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int temp;
        cin >> temp;
        pho[temp] = true;
        start = temp;
    }
    for (int i = 1; i < n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }
    used[start] = true;
    cout << bfs(start) << endl;
    return 0;
}

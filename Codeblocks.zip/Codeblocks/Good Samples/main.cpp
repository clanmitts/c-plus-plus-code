#include <bits/stdc++.h>

using namespace std;

int arr [1000001];
long long triangle (int n) {
		long long c = 0;
		for (int i = 1; i <= n; i++) c += i;
		return c;
	}
main() {
    int n;
    cin >> n;
    int m;
    cin >> m;
    long long k;
    cin >> k;
    if (k < n || k > triangle(m) + (long long)m*(n-m)) cout << -1 << endl;
    else {
        long long c = 1;
        arr[1] = 1;
        int ind = 1;
        for (int i = 1; i < n-1; i++) {
            if (c+min(m, ind+1)+(n-i-1) <= k) {
                c += min(m, ind+1);
                arr[i+1] = arr[i]+1;
                ind ++;
            }
            else {
                c ++;
                arr[i+1] = arr[i];
                ind = 1;
            }
        }
        arr[n] = arr[n-(int)(k-c)];
        for (int i = 1; i <= n; i++) cout << arr[i]%m+1 << " ";
        cout << endl;
    }

}

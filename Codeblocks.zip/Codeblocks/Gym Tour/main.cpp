#include <bits/stdc++.h>

using namespace std;

int n, k, f;
vector<int> path [100000];
int gym [100000];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> k;
    cin >> f;
    for (int i = 1; i <= k; i++) {
        cin >> gym[i];
    }
    for (int i = 1; i <= n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        path[a].push_back(b);
    }

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int arr [252];
int scorea;
int scoreb;
int even =1;
int turnover;
int tempturnover;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> arr[i];
    arr[0] = -123213;
    arr[n+1] = -42342;
    for (int i = 1; i <= n+1; i++) {
        if (arr[i] != arr[i-1]) {
            if ((arr[i-1] == 1 && scorea > scoreb) || (arr[i-1] == 2 && scoreb > scorea)) turnover = max(turnover, tempturnover);
            tempturnover = 0;
            if (arr[i] == 1) {
                if (scorea < scoreb) tempturnover = 1;
            }
            else if (arr[i] == 2) {
                if (scoreb < scorea) tempturnover = 1;
            }
        }
        else {
            if (tempturnover != 0) tempturnover ++;
        }
        if (arr[i] == 1) scorea++;
        if (arr[i] == 2) scoreb++;
        if (scorea == scoreb) even ++;
    }
    cout << scorea << " " << scoreb << "\n";
    cout << even<< "\n";
    cout << turnover << "\n";
    return 0;
}

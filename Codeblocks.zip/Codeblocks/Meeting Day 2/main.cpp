#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int x;
vector<pair<int, int>> regular [100001];
vector<pair<int, int>> reversed [1000001];
deque<int> d;
int u, v, w;
int there [100001];
int home [100001];
int cur;
int out;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    cin >> x;
    for (int i = 1; i <= m; i++) {
        cin >> u;
        cin >> v;
        cin >> w;
        regular[u].push_back({v, w});
        reversed[v].push_back({u, w});
    }
    for (int i = 1; i <= n; i++) {
        there[i] = 2000000000;
        home[i] = 2000000000;
    }
    there[x] = 0;
    home[x] = 0;
    d.push_back(x);
    while (!d.empty()) {
        cur = d.front();
        d.pop_front();
        for (pair<int, int> i: regular[cur]) {
            if (there[cur]+i.second < there[i.first]) {
                there[i.first] = there[cur]+i.second;
                d.push_back(i.first);
            }
        }
    }
    d.push_back(x);
    while (!d.empty()) {
        cur = d.front();
        d.pop_front();
        for (pair<int, int> i: reversed[cur]) {
            if (home[cur]+i.second < home[i.first]) {
                home[i.first] = home[cur]+i.second;
                d.push_back(i.first);
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        out = max(out, there[i]+home[i]);
    }
    cout << out << endl;
    return 0;
}

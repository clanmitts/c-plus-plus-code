#include <bits/stdc++.h>

using namespace std;


int n;
int arr [102][102];
int arr2 [102][102];
int rarr [102][102];
int rarr2 [102][102];

bool equals(int a1[102], int a2[102]) {
    for (int i = 1; i <= n; i++) {
        if (a1[i] != a2[i]) return false;
    }
    return true;
}

bool one() {
    for (int i = 1; i <= n; i++) {
        if (arr[i][1] <= arr[i-1][1]) return false;
        if (!equals(arr[i], arr2[i])) return false;
    }
    return true;
}

bool two() {
    for (int i = n; i >= 1; i--) {
        if (arr[i][n] <= arr[i+1][n]) return false;
        if (!equals(arr[i], arr2[i])) return false;
    }
    return true;
}

bool three() {
    for (int i = n; i >= 1; i --) {
        if (rarr[i][1] <= rarr[i+1][1]) return false;
        if (!equals(rarr[i], rarr2[i])) return false;
    }
    return true;
}

bool works = false;

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> arr[i][j];
            arr2[i][j] = arr[i][j];
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            rarr[j][i] = arr[i][j];
            rarr2[j][i] = rarr[j][i];
        }
    }
    for (int i = 1; i <= n; i++) {
        sort(arr2[i]+ 1, arr2[i]+n+1);
        sort(rarr2[i]+ 1, rarr2[i]+n+1);
    }
    if (one()) {
        for (int i = 1;i  <= n; i++) {
            for (int j = 1; j < n; j++) {
                cout << arr[i][j] << " ";
            }
            cout << arr[i][n];
            cout << endl;
        }
        works = true;
    }
    for (int i = 1; i <= n; i++)  sort(arr2[i]+ 1, arr2[i]+n+1, greater<>());
    if (works) {}
    else if (two()) {
        for (int i = n; i >= 1; i--) {
            for (int j = n; j > 1; j--) {
                cout << arr[i][j] << " ";
            }
            cout << arr[i][1];
            cout << endl;
        }
    }
    else if (three()) {
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j < n; j++) {
                cout << rarr[i][j] << " ";
            }
            cout << rarr[i][n];
            cout << endl;
        }
    }
    else {
        for (int i = 1; i <= n; i++) {
            for (int j = n; j > 1; j--)  {
                cout << rarr[i][j] << " ";
            }
            cout << rarr[i][1];
            cout << endl;
        }
    }
}

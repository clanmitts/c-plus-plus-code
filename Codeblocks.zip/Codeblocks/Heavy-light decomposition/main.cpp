#include <bits/stdc++.h>

using namespace std;

int n;
int m;
bool vis [100001];
int dfs [100001];
int ind;
vector<int> arr [100001];
int ending [100001];
int location [100001];
int BIT [100002];
bool heavy [100001];
int rep [100001];
int s [100001];
int par [100001];


void findHeavy(int x) {
    int a = 0;
    int b = 0;
    vis[x] = true;
    for (int i: arr[x]) {
        if (!vis[i] && s[i] > a) {
            heavy[b] = false;
            heavy[i] = true;
            a = s[i];
        }
    }
    for (int i: arr[x]) {
        findHeavy(i);
    }
}

int findSize(int x) {
    for (int i: arr[x]) {
        if (!vis[i]) s[x] += findSize(i);
    }
    return s[x];
}

void findRep(int x) {
    for (int i: arr[x]) {
        if (!vis[i]) {
            if (heavy[i]) {
                rep[i] = rep[x];
            }
            else {
                rep[i] = i;;
            }
        }
    }
}

void moveAround(int x) {
    for (int i = 0; i < arr[x].size(); i++) {
        if(heavy[arr[x][i]]) {
            int temp = arr[x][0];
            arr[x][0] = arr[x][i];
            arr[x][i] = temp;
        }
    }
    for (int i: arr[x]) {
        moveAround(i);
    }
}

void d(int q) {
    ind++;
    dfs[ind] = q;
    location[q] = ind;
    vis[q] = true;
    for (int i: arr[q]) {
        if (!vis[i]) {
            par[i] = q;
            d(i);
        }
    }
    ending[q] = ind;
}

void updateBIT(int index, int val){
    index = index + 1;
    while (index <= n){
        BIT[index] += val;
        index += index & (-index);
    }
}

int getSum(int index) {
    int sum = 0;
    index = index + 1;
    while (index>0){
        sum += BIT[index];
        index -= index & (-index);
    }
    return sum;
}


void update(int x, int b) {
    if (x != 1) {
        updateBIT(location[rep[x]], b);
        updateBIT(location[x], -b);
        update(par[rep[x]], b);
    }
}


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }


    for (int i = 1; i <= n; i++) rep[i] =1;
    for (int i = 1; i <= n; i++) vis[i] = false;
    s[1] = findSize(1);
    findHeavy(1);
    findRep(1);
    moveAround(1);
    d(1);

    for (int i = 1; i <= m; i++) {
        int a;
        cin >> a;
        if (a == 1) {
            int b;
            int c;
            cin >> b;
            cin >> c;
            updateBIT(location[b], c);
            updateBIT(ending[b]+1, -c);
        }
        else if (a == 2) {
            int b;
            cin >> b;
            cout << getSum(location[b])-getSum(location[b]-1) << endl;
        }
    }
    return 0;
}

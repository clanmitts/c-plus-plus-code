#include <bits/stdc++.h>

using namespace std;


int main()
{
    int n = 1;
   cout << (n << 1);

}

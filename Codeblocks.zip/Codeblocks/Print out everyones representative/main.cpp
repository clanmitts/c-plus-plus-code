#include <bits/stdc++.h>

using namespace std;

int n;
vector<int> arr [100001];
bool vis[100001];
bool heavy [100001];
int rep;


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    for (int i = 1; i <= 10; i++) rep[i] = 1;
    return 0;
}

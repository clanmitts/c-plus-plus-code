#include <bits/stdc++.h>

using namespace std;

int n, b, t;
int num [1000001];
unordered_map<int, int> freq;
vector <int [2]> sorted;
long long total = 0;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> b;
    cin >> t;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
        if (freq.count(num[i]+1e9) > 0) {
            freq.find(num[i]+1e9)++;
        }
        else {
            freq.insert({num[i]+1e9, 1});
        }
    }
    num[0] = -2000000000;
    sort(num, num+n+1);
    int l = 1;
    int r = 1;
    for (int i = 1; i <= n; i++) cout << num[i] << " ";
    cout << endl;
    while (r <= n) {
        cout << l << " " << r << endl;
        if (num[r] != num[l]) {
            while (num[r]-num[l] > t) {
                l++;
            }
            if (num[r]-num[l] >= b) {
                total += (freq.at(num[l]+1e9))*(r-l-freq.at(num[l]+1e9+1));
                l ++;
            }
            else {
                r++;
            }
        }
        else {
            r++;
        }
    }
    cout << total << endl;
    return 0;
}

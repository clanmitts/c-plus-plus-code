#include <bits/stdc++.h>

using namespace std;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    double n;
    cin >> n;
    n -= 1;
    n *= -1;
    cout << fixed << showpoint;
    cout << setprecision(9) << (5 + sqrt(25 - 48*n))/24 << endl;
    return 0;
}

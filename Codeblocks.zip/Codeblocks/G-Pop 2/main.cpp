#include <bits/stdc++.h>

using namespace std;

int n;
int q;
pair<int, int> num [500001];
priority_queue<int> check;
int out [500001];
int ind = 1;

bool func(const pair<int,int> &a, const pair<int,int> &b){
    return (a.second < b.second);
}

int main()
{

    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= q; i++) {
        cin >> num[i].first;
        cin >> num[i].second;
        cout << "erer" << endl;
    }
    sort(num, num+n+1, func);
    for (int i = 1; i <= n; i++) {
        while (ind <= n && num[ind].second >= i) {
                cout << "ERE" << endl;
            check.push(num[ind].first);
            ind++;
        }
        while (!check.empty() && check.top() < i) {
            check.pop();
        }
        if (check.top() == i) out[i] = out[i-1];
        else out[i] = out[i-1]+1;
    }
    for (int i = 1; i <= n; i++) cout << out[i] << " " ;
    cout << "\n";
    return 0;
}

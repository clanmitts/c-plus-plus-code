#include <bits/stdc++.h>

using namespace std;

int n;
string str;


void check() {
    if (str[0] != 'm' && str[0] != 'o') {
            cout << "no" << endl;
            return;
    }
    for (int i = 1; i < str.length()-1; i++) {
        if (str[i] != 'm' && str[i] != 'o') {
        cout << "no" << endl;
        return;
        }
        if (str[i] == 'm') if (str[i-1] != 'o') {
            cout << "no" << endl;
            return;
        }
        if (str[i] == 'o') if (str[i-1] != 'm') {
            cout << "no" << endl;
            return;
        }
        else {
            i++;
        }
    }
     if (str[str.length()-1] != 'm' && str[str.length()-1] != 'o') {
        cout << "no" << endl;
        return;
        }
        if (str[str.length()-1] == 'm') if (str[str.length()-2] != 'o') {
            cout << "no" << endl;
            return;
        }
        if (str[str.length()-1] == 'o') if (str[str.length()-2] != 'm') {
            cout << "no" << endl;
            return;
        }
    cout << "yes" << endl;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str;
    check();
    return 0;
}

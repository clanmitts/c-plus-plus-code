#include <bits/stdc++.h>

using namespace std;

int n;
int a [100001];
int v [100001];
vector<int> want [100001];
bool vis [100001];
long long output;
int l = 0;
int r = 1;
int smallest = INT_MAX;
deque<int> d;

void check(int x) {
    l = x;
    r = x;
    smallest = INT_MAX;
    l = a[l];
    r = a[a[r]];
    while (l != r) {
        l = a[l];
        r = a[a[r]];
    }
    smallest = min(smallest, v[l]);
    l = a[l];
    while (l != r) {
        smallest = min(smallest, v[l]);
        l = a[l];
    }
    vis[l] = true;
    d.push_back(l);
    while(!d.empty()) {
        int cur = d.front();
        d.pop_front();
        for (int i: want[cur]) {
            if (!vis[i]) {
                vis[i] = true;
                d.push_back(i);
            }
        }
    }
    output -= smallest;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        cin >> v[i];
        output += v[i];
        want[a[i]].push_back(i);
    }
    for (int i = 1; i <= n; i++) {
        if (!vis[i]) {
            check(i);
        }
    }
    cout << output << "\n";
    return 0;
}

#include <iostream>

using namespace std;

string n;
string out = "";
int a;

string one() {
    out = "";
    char high = '0';
    for (char i: n) {
        high = max(high, i);
    }
    if (high == n[0]) {
        for (int i = 1; i <= n.size(); i++) out += high;
    }
    else {
        for (int i = 1; i <= n.size(); i++) out += n[0]+1;
    }
    return out;
}

string two() {
    out = "";
    out += n[0];
    char high = '0';
    for (int i = 1; i < n.size(); i++) {
        high = max(high, n[i]);
    }
    if (high > n[0]) {
        for (int i = 2; i <= n.size(); i++) {
            out += high;
        }
    }
    else if (high == n[0]) {
        int i = 1;
        for (int i = 1; i < n.size(); i++) {
            if (n[i] < n[0]) {
                out += n[i];
                break;
            }
            else {
                out += n[0];
            }
        }
        while (out.size() < n.size()) {
            out += high;
        }
    }
    else {
        for (int i = 2; i <= n.size(); i++) {
            out += high;
        }
    }
    return out;
}

int main()
{
    cin >> n;
    cin >> a;
    if (a == 0) cout << one();
    else {
        cout << min(stol(one()), stol(two()));
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int r;
int c;
char poster [2001][2001];

int main()
{
    cin >> n;
    cin >> m;
    cin >> r;
    cin >> c;
    if (r == 1 && c == 1) {
        for (int i = 1; i <= n; i++) {
            poster[i][1] = 'a';
        }
        for (int i = 1; i <= m; i++) {
            poster[1][i] = 'a';
        }
        for (int i = 2; i <= n; i++) {
            for (int j = 2; j <= m; j++) {
                poster[i][j] = 'b';
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                cout << poster[i][j];
            }
            cout << endl;
        }
    }
    else if (n == 2 && m == 2) {
        if (r == 0 && c == 0) {
            cout << "ab\ncd" << endl;
        }
        else if (r == 0 && c == 1) {
            cout << "ab\nac" << endl;
        }
        else if (r == 0 && c == 2) {
            cout << "ab\nab" << endl;
        }
        else if (r == 1 && c == 0) {
            cout << "aa\nbc" << endl;
        }
        else if (r == 1 && c == 1) {
            cout << "aa\nab" << endl;
        }
        else if (r == 1 && c == 2) {
            cout << "IMPOSSIBLE" << endl;
        }
        else if (r == 2 && c == 0) {
            cout << "aa\nbb" << endl;
        }
        else if (r == 2 && c == 1) {
            cout << "IMPOSSIBLE" << endl;
        }
        else if (r == 2 && c == 2) {
            cout << "aa\naa" << endl;
        }
    }
    else if (n == 2) {
        if (r == 0) {
            poster[1][1] = 'a';
            poster[2][1] = 'a';
            for (int i = 2; i <= m; i++) {
                if (poster[1][i-1] == 'z') poster[1][i] = 'a';
                else poster[1][i] = poster[1][i-1]+1;
                poster[2][i] = poster[1][i];
            }
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= m;j++) {
                    cout << poster[i][j] << endl;
                }
                cout << endl;
            }
        }
        else if (r == 1) {
            if (c == m) cout << "IMPOSSIBLE" << endl;
            else {
                poster[1][1] = 'a';
                poster[1][m] = 'a';
                for (int i = 2; i <= m/2; i++) {
                    if (poster[1][i-1] == 'z') poster[1][i] = 'a';
                    else poster[1][i] = poster[1][i-1]+1;
                    poster[1][m-i+1] = poster[1][i];
                }
                if (m%2 == 1) {
                    poster[1][m/2+1] = 'a';
                }
                for (int i = 1; i <= c; i++) {
                    poster[2][i] = poster[1][i];
                }
                for (int i = c+1; i <= m; i++) {
                    if (poster[2][i-1] == 'z') poster[2][i] = 'a';
                    else poster[2][i] = poster[2][i-1]+1;
                }
                for (int i = 1; i <= n; i++) {
                    for (int j = 1; j <= m;j++) {
                        cout << poster[i][j];
                    }
                    cout << endl;
                }
            }
        }
        else if (r == 2) {
            poster[1][1] = 'a';
            poster[1][m] = 'a';
            for (int i = 2; i <= m/2; i++) {
                if (poster[1][i-1] == 'z') poster[1][i] = 'a';
                else poster[1][i] = poster[1][i-1]+1;
                poster[1][m-i+1] = poster[1][i];
            }
            if (m%2 == 1) {
                poster[1][m/2+1] = 'a';
            }
            if (m%2 == 0) {

            }
        }
    }
    return 0;
}

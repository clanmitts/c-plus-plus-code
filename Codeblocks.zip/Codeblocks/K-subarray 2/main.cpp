#include <bits/stdc++.h>

using namespace std;

int n;
int k;
int arr [20001];
long long dp [20001][2];
long long psa [20002];
long long maxValue;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> k;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    for (int i = 1; i <= n; i++) {
        psa[i] = psa[i-1]+arr[i];
    }
    int ind = 1;
    for (int j = 1; j <= k; j++) {
        dp[0][ind] = (long long)(2)*INT_MIN;
        maxValue = (long long)(2)*INT_MIN;
        for (int i = 1; i <= n; i++) {
            maxValue = max(maxValue, dp[i-1][abs(ind-1)]-psa[i-1]);
            dp[i][ind] = max(dp[i-1][ind], psa[i]+maxValue);
        }
        ind = abs(ind-1);
    }
    cout << dp[n][abs(ind-1)];
    return 0;
}

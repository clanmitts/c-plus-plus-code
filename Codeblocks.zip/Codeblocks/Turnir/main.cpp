#include <bits/stdc++.h>

using namespace std;

int n;
vector<pair<int, int>> arr1;
vector<pair<int, int>> arr2;
int level [(int)(pow(2, 20))+1];
int cur;
int arr = 0;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cur = 0;
    for (int i = 1; i <= pow(2, n); i++) {
        int a;
        cin >> a;
        arr1.push_back({a, i});
    }
    for (int i = 1; i <= n; i++) {
        if (arr == 0) {
            while (arr1.size() > 0) {
                if (true) {
                    arr2.push_back(arr1[0]);
                    arr1.erase(arr1.begin());
                    level[arr1[0].second] = cur;
                    arr1.erase(arr1.begin());
                }
                else {
                    level[arr1[0].second] = cur;
                    arr1.erase(arr1.begin());
                    arr2.push_back(arr1[0]);
                    arr1.erase(arr1.begin());
                }
            }
            arr = 1;
        }
        else if (level)
        cur--;
    }
    return 0;
}

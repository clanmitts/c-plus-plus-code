#include <bits/stdc++.h>

using namespace std;

int n;
int arr [3000000];
int freq [2000000];
vector<int> place [1000001];
int output [2000000];

bool works() {
    for (int i = 2; i <= n; i++) {
        if (place[i].size() > place[i-1].size() && place[i].size() % i != 0) {
                return false;
        }
    }
    return true;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1;i  <= n; i++) cin >> arr[i];
    for (int i = 1; i <= n; i++) {
            freq[arr[i]] ++;
            place[arr[i]].push_back(i);
    }
    if (!works()) cout << -1;
    else {
        for (int i: place[1]) output[i] = i;
        for (int i = 2; i <= n; i++) {
            for (int j = 0; j < place[i].size(); j++) {
                output[place[i-1][j]] = place[i][j];
            }
        }
        for (int i = 1; i <= n; i++) cout << output[i] << " ";
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int sausage [100001];
vector<int> length [101];
long long dp [100001][5];
int wanted [5];
bool checked [101];
vector<int> temp;
int a;
int b;
int l;
int r;
long long total;

long long compute() {
    for (int i = 0; i < temp.size(); i++) {
        for (int j = 1; j <= 4; j++) {
            if (sausage[temp[i]] != wanted[j]) {
                dp[temp[i]][j] = dp[temp[i-1]][j];
            }
            if (sausage[temp[i]] == wanted[j]) {
                dp[temp[i]][j] = dp[temp[i-1]][j] + dp[temp[i-1]][j-1];
            }
        }
    }
    return dp[temp.size()-1][4];
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) dp[i][0] = 1;
    for (int i = 1; i <= n; i++) cin >> sausage[i];
    for (int i = 1; i <= n; i++) length[sausage[i]].push_back(i);
    for (int i = 1; i <= n; i++) {
        if (!checked[sausage[i]]) {
            checked[sausage[i]] = true;
            wanted[1] = sausage[i];
            wanted[4] = sausage[i];
            for (int j = 1; i <= 100; j++) {
                a = sausage[i];
                b = j;
                wanted[2] = j;
                wanted[3] = j;
                temp.clear();
                for (int i: length[a]) temp.push_back(i);
                for (int i: length[b]) temp.push_back(i);
                sort(temp.begin(), temp.end());
            }
        }
    }
    cout << total << endl;
    return 0;
}

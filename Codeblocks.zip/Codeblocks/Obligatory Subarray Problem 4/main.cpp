#include <bits/stdc++.h>

using namespace std;

int n, b, t;
int num [1000001];
int maximum, minimum;
int l;
priority_queue<int, vector<int>> maxq;
priority_queue<int, vector<int>, greater<>> minq;
unordered_map<int, int> rig;
long long total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n >> b >> t;
    for (int i = 1; i <= n; i++) cin >> num[i];
    maxq.push(num[1]);
    minq.push(num[1]);
    rig.insert({num[1], 1});
    for (int r = 2; r <= n; r++) {
        if (rig[num[r]] == 0) {
            maxq.push(num[r]);
            minq.push(num[r]);
        }
        rig[num[r]] = r;
        while (!maxq.empty()) {
            if (rig[maxq.top()] == 0) maxq.pop();
            else break;
        }
        while (!minq.empty()) {
            if (rig[minq.top()] == 0) minq.pop();
            else break;
        }
        while(maxq.top()-minq.top() > t) {
            if (rig[num[l]] == l) rig[num[1]] = 0;
            while (!maxq.empty()) {
            if (rig[maxq.top()] == 0) maxq.pop();
            else break;
            }
            while (!minq.empty()) {
                if (rig[minq.top()] == 0) minq.pop();
                else break;
            }
            l++;
        }
        total += (r-l+1);
    }
    maxq = priority_queue<int>();
    minq =  priority_queue<int, vector<int>, greater<>>();
    rig.clear();
    maxq.push(num[1]);
    minq.push(num[1]);
    rig.insert({num[1], 1});
    for (int r = 2; r <= n; r++) {
        if (rig[num[r]] == 0) {
            maxq.push(num[r]);
            minq.push(num[r]);
        }
        rig[num[r]] = r;
        while (!maxq.empty()) {
            if (rig[maxq.top()] == 0) maxq.pop();
            else break;
        }
        while (!minq.empty()) {
            if (rig[minq.top()] == 0) minq.pop();
            else break;
        }
        while(maxq.top()-minq.top() > b) {
            if (rig[num[l]] == l) rig[num[1]] = 0;
            while (!maxq.empty()) {
            if (rig[maxq.top()] == 0) maxq.pop();
            else break;
            }
            while (!minq.empty()) {
                if (rig[minq.top()] == 0) minq.pop();
                else break;
            }
            l++;
        }
        total -= (r-l+1);
    }
    cout << total << "\n";
    return 0;
}

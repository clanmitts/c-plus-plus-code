#include <bits/stdc++.h>

using namespace std;

long long l;
long long r;
long long total;
int div = 1;

double palindrome(int x) {
    int temp
    div = 1;
    while (x/div >= 10) {

    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> l;
    cin >> r;
    while (r/div >= 10) {
        total += 2^2;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

long long pow(long long  base, long long exponent, long long modulus) {
    if (modulus == 1) {
        return 0;
    }
    long long c = 1;
    for (int i = 0; i <= exponent-1; i++)
        c = (c * base) % modulus;
    return c;
}

int main()
{
    int f;
    int n;
    cin >> f;
    cin >> n;
    int flower [f+1];
    flower[0] = 0;
    for (int i = 1; i <= f; i++) {
        cin >> flower[i];
    }
    sort(flower, flower + f + 1);
    long long total = 0;
    for (int i = n; i >= 1; i--) {
        total += (pow(flower[i], n-i+1, (long long) (1e9 + 7)));
    }
    total %= ((long long)1e9+7);
    cout << (total) << endl;
}

#include <bits/stdc++.h>

using namespace std;

int n, q;
int num [1000001];
int leader [1000002];
int follower [1000002];
int l, r, k;
int connect [1000002];
int ind;
int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= n; i++) {
        leader[i] = i-1;
    }
    for (int i = 0; i <= n; i++) {
        follower[i] = i+1;
    }
    for (int i = 1; i <= q; i++) {
        cin >> l;
        cin >> r;
        cin >> k;
//        else if (l > k) {
            leader[follower[r]] = leader[l];
            follower[leader[l]] = follower[r];
            leader[l] = k;
            leader[follower[k]] = r;
            follower[r] = follower[k];
            follower[k] = l;
//
//        }
//        else if (r < k) {
//            leader[follower[r]] = leader[l];
//            follower[leader[l]] = follower[r];
//            leader[l] = k;
//            leader[follower[k]] = r;
//            follower[r] = follower[k];
//            follower[k] = l;
//        }
    }
     for (int i = 1; i <= n; i++) if (leader[i] == 0) ind = i;
        while (follower[ind] != 0) {
                cout << ind << " ";
                ind = follower[ind];
        }
        cout << "\n";
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int dis [9][9];
int sx, sy, ex, ey;
deque<pair<int, int>> q;

int main()
{
    for (int i = 1; i <= 8; i++) fill(dis[i], dis[i]+9, INT_MAX);
    cin >> sx >> sy >> ex >> ey;
    pair<int, int> cur;
    cur.first = sx;
    cur.second = sy;
    dis[cur.first][cur.second] = 0;
    q.push_back(cur);
    while (!q.empty()) {
        cur = q.front();
        q.pop_front();
        if (cur.first-2 >= 1 && cur.second-1 >= 1 && dis[cur.first][cur.second]+1 < dis[cur.first-2][cur.second-1]) {
            dis[cur.first-2][cur.second-1] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first-2;
            temp.second = cur.second-1;
            q.push_back(temp);
        }
        if (cur.first-2 >= 1 && cur.second+1 <= 8 && dis[cur.first][cur.second]+1 < dis[cur.first-2][cur.second+1]) {
            dis[cur.first-2][cur.second+1] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first-2;
            temp.second = cur.second+1;
            q.push_back(temp);
        }
        if (cur.first+2 <= 8 && cur.second+1 <= 8 && dis[cur.first][cur.second]+1 < dis[cur.first+2][cur.second+1]) {
            dis[cur.first+2][cur.second+1] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first+2;
            temp.second = cur.second+1;
            q.push_back(temp);
        }
        if (cur.first+2 <= 8 && cur.second-1 >= 1 && dis[cur.first][cur.second]+1 < dis[cur.first+2][cur.second-1]) {
            dis[cur.first+2][cur.second-1] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first+2;
            temp.second = cur.second-1;
            q.push_back(temp);
        }
        if (cur.first-1 >= 1 && cur.second-1 >= 1 && dis[cur.first][cur.second]+1 < dis[cur.first-1][cur.second-2]) {
            dis[cur.first-1][cur.second-2] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first-1;
            temp.second = cur.second-2;
            q.push_back(temp);
        }
        if (cur.first-1 >= 1 && cur.second+2 <= 8 && dis[cur.first][cur.second]+1 < dis[cur.first-1][cur.second+2]) {
            dis[cur.first-1][cur.second+2] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first-1;
            temp.second = cur.second+2;
            q.push_back(temp);
        }
        if (cur.first+1 <= 8 && cur.second+2 <= 8 && dis[cur.first][cur.second]+1 < dis[cur.first+1][cur.second+2]) {
            dis[cur.first+1][cur.second+2] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first+1;
            temp.second = cur.second+2;
            q.push_back(temp);
        }
        if (cur.first+1 <= 8 && cur.second-2 >= 1 && dis[cur.first][cur.second]+1 < dis[cur.first+1][cur.second-2]) {
            dis[cur.first+1][cur.second-2] = dis[cur.first][cur.second]+1;
            pair<int, int> temp;
            temp.first = cur.first+1;
            temp.second = cur.second-2;
            q.push_back(temp);
        }
    }
    cout << dis[ex][ey];
}

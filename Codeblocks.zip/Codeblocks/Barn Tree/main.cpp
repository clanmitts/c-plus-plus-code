#include <bits/stdc++.h>

using namespace std;

int n;
long long hay [200002];
vector<long long> arr [200002];
vector<pair<pair<int, int>, long long>> first;
vector<pair<pair<int, int>, long long>> second;
deque<int> q;
long long want;
bool vis [200002];
long long check [200002];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> hay[i];
    for (int i = 1; i < n; i++) {
        int a;
        int b;
        cin >>a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }
    for (int i = 1; i <= n; i++) want += hay[i];
    want /= n;
    for (int i = 1; i <= n; i++) hay[i] -= want;
    for (int i = 1; i <= n; i++) {
            check[i] = arr[i].size();
    }
    for (int i = 1; i <= n; i++) {
        if (check[i] == 1) {
            q.push_back(i);
        }
    }
    while (!q.empty()) {
        int cur = q.front();
        q.pop_front();
        vis[cur] = true;
        for (int i: arr[cur]) {
            if (!vis[i]) {
                if (hay[cur] > 0) {
                    first.push_back({{cur, i}, hay[cur]});
                    hay[i] += hay[cur];
                    hay[cur] = 0;
                }
                else if (hay[cur] < 0) {
                    if (hay[i] + hay[cur] < 0) {
                        second.push_back({{i, cur}, -hay[cur]});
                    }
                    else {
                        first.push_back({{i, cur}, -hay[cur]});
                    }
                    hay[i] += hay[cur];
                    hay[cur] = 0;
                }
                check[i] --;
                if (check[i] == 1) {
                    q.push_back(i);
                }
            }
        }
    }
    cout << first.size() + second.size() << endl;

    for (int i = 0; i < first.size(); i++) {
        cout << first[i].first.first << " " << first[i].first.second << " " << first[i].second <<  endl;
    }
    for (int i = second.size()-1; i >= 0; i--) {
        cout << second[i].first.first << " " << second[i].first.second << " " << second[i].second <<  endl;
    }
    return 0;
}

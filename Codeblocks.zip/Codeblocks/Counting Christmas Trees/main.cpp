#include <bits/stdc++.h>

using namespace std;

int n;
int h [100001];
int inc = 1;
int d = 1;
int maxinc = 1;
int maxdec = 1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> h[i];
    for (int i = 2; i <= n; i++) {
        if (h[i] > h[i-1]) {
            inc ++;
        }
        else {
            maxinc = max(maxinc, inc);
            inc = 1;
        }
        if (h[i] < h[i-1]) {
            d++;
        }
        else {
            maxdec = max(maxdec, d);
            d = 1;
        }
        maxinc = max(maxinc, inc);
        maxdec = max(maxdec, d);
    }
    maxinc = max(maxinc, inc);
    maxdec = max(maxdec, d);
    cout << maxinc << endl;
    cout << maxdec << endl;
    return 0;
}

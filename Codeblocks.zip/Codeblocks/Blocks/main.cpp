#include <bits/stdc++.h>

using namespace std;

int n;
string thing [4];

void func (){
        sort(thing, thing+4);
		string str;
		getline(cin, str);
		do {
			for (int i = 0; i <= 6; i++) {
				for (int j = 0; j <= 6; j++) {
					for (int k = 0; k <= 6; k++) {
						for (int l = 0; l <= 6; l++) {
                            string temp = "";
							temp = string(1, thing[0][i]) + string(1,thing[1][j]) + string(1, thing[2][k]) + string(1, thing[3][l]);
							string temp2 = "";
							for (char a: temp) {
                                    if (a != ' ') temp2 += a;
							}
							if (temp2 == str) {
								cout << "YES" << endl;;
								return;
							}
						}
					}
				}
			}
		}
		while (next_permutation(thing, thing+4));
		cout << "NO" << endl;
		return;
	}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    string gdg;
    getline(cin, gdg);
    for (int i = 0; i < 4; i++) {
        getline(cin, thing[i]);
        thing[i] += " ";
    }
    sort(thing, thing+4);
    for (int i = 1; i <= n; i++) {
        func();
    }
    return 0;
}

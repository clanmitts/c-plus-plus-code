#include <bits/stdc++.h>

using namespace std;

int n;
string str;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str;
    int index = 0;
    if (n < (str.length()+2)/3+1 || (str[0] == 'm' && n < (str.length()+2)/3)) {
        if (str[0] != 'm' && str[0] != 'o') {
            cout << "no" << endl;
        }
        else {
            if (str[0] == 'o') {
                if (str[1] == 'o' || str[1] == 'm') {
                    index = 2;
                }
                else {
                    cout << "no" << endl;
                }
            }
            if (str[0] == 'm') {
                if (str[1] != 'o') {
                        cout << "no" << endl;
                }
                else {
                    index = 2;
                }
            }
            for (int i = 2; i < str.length(); i++) {
                if (str[i] != 'm' && str[i] != 'o') {
                        cout << "no" << endl;
                        break;
                }
                else {
                    if (str[i] == 'o') {
                        if (str[i-1] == 'o') {

                        }
                        else if (str[i-1] == 'm') {

                        }
                        else {
                            cout << "no" << endl;
                            break;
                        }
                    }
                    if (str[i] == 'm') {
                        if (str[i-1] == 'o') {
                            if (str[i-2] == 'o') {

                            }
                            else {
                                cout << "no" << endl;
                                break;
                            }
                        }
                        else {
                            cout << 'no' << endl;
                            break;
                        }
                    }
                }
            }
            cout << "yes" << endl;
        }
    }
    else if (str.length() == 1 && (str[0] == 'm' || str[0] == 'o')) {
        cout << "yes" << endl;
    }
    else {
        cout << "no" << endl;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

long long bit [1000001];
long long num [1000001];
long long freq [1000001];
int n;
int m;

void updateSum(int index, long long val) {
    while (index <= n) {
        bit[index] += val;
        index += (index & -index);
    }
}

long long freqToSum(int index) {
    long long sum = 0;
    while (index > 0) {
        sum += bit[index];
        index -= (index & -index);
    }
    return sum;
}

void updateFreq(int index, long long val) {
    while (index <= 100000) {
        freq[index] += val;
        index += (index & -index);
    }
}

long long freqToFreq (int index) {
    long long sum = 0;
    while(index > 0) {
        sum += freq[index];
        index -= (index & -index);
    }
    return sum;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
        updateSum(i, num[i]);
        updateFreq(num[i], 1);
    }
    for (int i = 0; i < m; i++) {
        string temp;
        cin >> temp;
        int a = temp[0];
        if (a == 'C') {
            int b;
            int c;
            cin >> b;
            cin >> c;
            updateFreq(num[b], -1);
            updateSum(b, c-num[b]);
            num[b] = c;
            updateFreq(c, 1);
        }
        else if (a == 'S') {
            int b;
            int c;
            cin >> b;
            cin >> c;
            cout << freqToSum(c)-freqToSum(b-1) << endl;
        }
        else {
            int b;
            cin >> b;
            cout << freqToFreq(b) << endl;
        }
    }
    return 0;
}

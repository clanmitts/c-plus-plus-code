#include <bits/stdc++.h>

using namespace std;

int n;
int k;
long long m;
pair<long long, int> a [200001];
pair<long long, int> b [200001];
int x ;
int y;
int total;

int main()
{
    cin >> n;
    cin >> k;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        cin >> a[i].first;
        a[i].second = i;
    }
    for (int i = 1; i <= n; i++) {
        cin >> b[i].first;
        b[i].second = i;
    }
    x = 1;
    y = n;
    sort(a, a+n+1);
    sort(b, b+n+1);
    for (int i = 1; i <= n; i++) {
        cout << b[i].first << " " << b[i].second << endl;
    }
    while (x <= n && y >= 1) {
        while (y >= 1 && a[x].first + b[y].first > m) {
            y--;
        }
        if (a[x].first + b[y].first == m && abs(a[x].second-b[y].second) >= k) {
            total ++;
        }
        x++;
    }
    cout << total << endl;
    return 0;
}

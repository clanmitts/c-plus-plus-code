#include <iostream>
#include <deque>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);


    int n, m, k;
    cin >> n >> m >> k;
    int list[n+2][m+2];
    int dis[n+2][m+2];
    deque<pair<int, int>> d;
    for (int i = 0; i <= n+1; i++) {
        for (int j = 0; j <= m+1; j++) {
            list[i][j] = 1000000001;
            dis[i][j] = 1000000001;
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> list[i][j];
            if (list[i][j] != 0) {
                pair <int, int> temp;
                temp.first = i;
                temp.second = j;
                d.push_back(temp);
                dis[i][j] = 0;
            }
            else {
                list[i][j] = 1000000001;
            }
        }
    }
    int a [5];
    int b [5];
    a[1] = 1;
    a[2] = -1;
    a[3] = 0;
    a[4] = 0;
    b[1] = 0;
    b[2] = 0;
    b[3] = 1;
    b[4] = -1;
    while (!d.empty()) {
        pair <int, int> temp;
        temp = d.front();
        d.pop_front();
        if (dis[temp.first][temp.second] < k) {
            for (int i = 1; i <= 4; i++) {
                int nexta = temp.first+a[i];
                int nextb = temp.second+b[i];
                if (0<nexta && n>=nexta && 0<nextb && m>=nextb) {
                    if (list[nexta][nextb] == 1000000001) {
                        for (int j = 1; j <= 4; j++) {
                            if (dis[nexta+a[j]][nextb+b[j]] <= dis[temp.first][temp.second]) {
                                list[nexta][nextb] = min(list[nexta][nextb], list[nexta+a[j]][nextb+b[j]]);
                            }
                        }
                        dis[nexta][nextb] =
                            min({dis[nexta+1][nextb], dis[nexta-1][nextb],
                                    dis[nexta][nextb+1], dis[nexta][nextb-1]}) + 1;
                        d.push_back({nexta, nextb});
                    }
                }
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (list[i][j] == 1000000001) cout << 0 << " ";
            else cout << list[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}

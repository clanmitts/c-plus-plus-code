#include <bits/stdc++.h>

using namespace std;

int lift [21][1000001];
int ledaer [1000001];


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
double sheep [1000000001][3];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> sheep[i][1];
        cin >> sheep[i][2];
    }

    return 0;
}

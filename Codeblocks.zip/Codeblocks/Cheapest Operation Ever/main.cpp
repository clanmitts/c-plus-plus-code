#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MM = 1e5+2;
int N, H, p[MM]; ll dp[MM]; deque<int> q;

double f(int k, int j){
    return (double)((dp[j] + 1LL*p[j+1]*p[j+1]) - (dp[k] + 1LL*p[k+1]*p[k+1]))/(2LL*(p[j+1] - p[k+1]));
}

int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> N >> H;
    for(int i=1; i<=N; i++) cin >> p[i];
    memset(dp, 0x3f, sizeof(dp)); dp[0] = 0;
    q.push_back(0);
    for(int i=1; i<=N; i++) {
        while(q.size() >= 2 && f(q[0], q[1]) <= p[i]) q.pop_front();
        int j = q[0];
        dp[i] = dp[j] + 1LL*(p[i] - p[j+1])*(p[i] - p[j+1]) + H;
        while(q.size() >= 2 && f(q[q.size()-2], q.back()) >= f(q.back(), i)) q.pop_back();
        q.push_back(i);
    }
    cout << dp[N] << "\n";
}

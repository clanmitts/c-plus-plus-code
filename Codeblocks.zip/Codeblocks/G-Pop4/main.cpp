#include <bits/stdc++.h>

using namespace std;

const int MAX_n = 5e5+1;
const int MAX_q = 5e5+1;

int n;
int q;
pair<int, int> num [MAX_q];
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> check;
int out [MAX_n];
int ind = 1;
int maxdis;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= q; i++) {
        cin >> num[i].first;
        cin >> num[i].second;
    }
    for (int i = 1; i <= n; i++) {
        maxdis = max(maxdis, num[i].second-num[i].first+1);
    }
    sort(num, num+q+1);
    for (int i = 1; i <= n; i++) {
        while (ind <= q && num[ind].first <= i) {
            check.push({num[ind].first, num[ind].second});
            ind ++;
        }
        while (!check.empty()) {
            if (check.top().second < i) check.pop();
            else break;
        }
        if (check.empty() || check.top().first == i) out[i] = out[i-1];
        else out[i] = out[i-1]+1;
    }
    cout << maxdis << "\n";
    for (int i = 1; i <= n; i++) cout << out[i]%maxdis+1 << " \n"[i == n];

    return 0;
}

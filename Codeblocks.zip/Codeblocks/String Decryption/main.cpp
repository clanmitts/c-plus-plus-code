#include <bits/stdc++.h>

using namespace std;

long long n;
string str;
long long sum;
int asterisks;

int main()
{
    cin >> n;
    cin >> str;
    for (int i = 0; i < str.length(); i++) {
        if (str[i] == '*') asterisks ++;
        else {
            sum += (str[i] - 'a' + 1);
        }
    }
    if (sum + asterisks*1 <= n && sum + asterisks*26 >= n) {
        for (int i = str.length()-1; i >= 0; i--) {
            if (str[i] == '*') {
                if (asterisks == n-sum) {
                    str[i] = 'a';
                    sum += 1;
                    asterisks --;
                }
                else if (sum + asterisks + 25 <= n) {
                    str[i] = 'z';
                    sum += 26;
                    asterisks --;
                }
                else {
                    str[i] = (n- (sum+asterisks-1)) + 'a' -1;
                    sum += (n- (sum+asterisks-1));
                    asterisks --;
                }
            }
        }
        cout << str << endl;
    }
    else {
        cout << "Impossible" << endl;
    }
    return 0;
}

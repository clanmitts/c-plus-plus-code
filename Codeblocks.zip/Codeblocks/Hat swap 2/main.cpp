#include <bits/stdc++.h>


using namespace std;

int n;
int m;
int hat [1000001];
int shirogane [1000001][3];
int kaguya [1000001][3];
list<int> arr [1000001];
deque<int> d;
bool svis [1000001];
bool kvis [1000001];
int sdis [1000001];
int kdis [1000001];
int small = 1000000000;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1;i <= n; i++) {
        cin >> hat[i];
    }
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }
    d.push_back(1);
    svis[1] = true;
    shirogane[hat[1]][1] = 1;
    while (!d.empty()) {
        int cur = d.front();
        d.pop_front();
        for (int i: arr[cur]) {
            if (!svis[i]) {
                sdis[i] = sdis[cur]+1;
                svis[i] = true;
                if (!shirogane[hat[i]][1]) {
                    shirogane[hat[i]][1] = i;
                }
                else if (!shirogane[hat[i]][2]) {
                    shirogane[hat[i]][2] = i;
                }
                d.push_back(i);
            }
        }
    }
    d.push_back(n);
    kvis[n] = true;
    kaguya[hat[n]][1] = n;
    while (!d.empty()) {
        int cur = d.front();
        d.pop_front();
        for (int i: arr[cur]) {
            if(!kvis[i]) {
                kdis[i] = kdis[cur]+1;
                kvis[i] = true;
                if (!kaguya[hat[i]][1]) {
                    kaguya[hat[i]][1] = i;
                }
                else if (!kaguya[hat[i]][2]) {
                    kaguya[hat[i]][2] = i;
                }
                d.push_back(i);
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        if (shirogane[i][1] && kaguya[i][1] && shirogane[i][1] != kaguya[i][1]) small = min(small, sdis[shirogane[i][1]] + kdis[kaguya[i][1]]);
        if (shirogane[i][2] && kaguya[i][1]) small = min(small, sdis[shirogane[i][2]] + kdis[kaguya[i][1]]);
        if (shirogane[i][1] && kaguya[i][2]) small = min(small, sdis[shirogane[i][1]] + kdis[kaguya[i][2]]);
    }
    if (small == 1000000000) cout << -1 << endl;
    else cout << small << endl;
    return 0;
}

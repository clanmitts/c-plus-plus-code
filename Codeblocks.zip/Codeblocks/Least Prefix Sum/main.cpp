#include <bits/stdc++.h>

using namespace std;

int t;
int n;
int m;
long long arr [200001];
long long psa [200001];
priority_queue<int> p;
priority_queue<int, vector<int>, greater<int>> q;
int ans;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    for (int j =1 ; j <= t; j++) {
        ans = 0;
        cin >> n;
        cin >> m;
        for (int i = 1; i <= n; i++) {
            cin >> arr[i];
        }
        for (int i = 1; i <= n; i++) {
            psa[i] = psa[i-1] + arr[i];
        }
        for (int i = m; i >= 1; i --) {
            while (psa[i] < psa[m]) {
                int cur = p.top();
                p.pop();
                psa[m] -= 2*cur;
                ans ++;
            }
            p.push(arr[i]);
        }
        while (!p.empty()) p.pop();

        for (int i = m+1; i <= n; i++) {
            psa[i] = psa[i-1] + arr[i];
        }
        for (int i = m+1; i <= n; i++) {
            q.push(arr[i]);
            while (psa[i] < psa[m]) {
                int cur = q.top();
                q.pop();
                psa[m] += 2*cur;
                ans++;
            }
        }
        while (!q.empty()) q.pop();
        cout << ans << endl;
    }

    return 0;
}

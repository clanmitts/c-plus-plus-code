#include <bits/stdc++.h>

using namespace std;

long l;
long r;
long total;

int main()
{
    cin >> l;
    cin >> r;
    while (l <= r) {
        l *= 2;
        total ++;
    }
    cout << total << endl;
    return 0;
}

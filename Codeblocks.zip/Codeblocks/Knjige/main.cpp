#include <bits/stdc++.h>

using namespace std;

int n;
int arr [100];
int optimal [100];
vector<int> l;
vector<int> r;
int pointer;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
        optimal[i] = arr[i];
    }
    sort(optimal, optimal+n);
    for (int i = n-1; i >= 0; i--) l.push_back(arr[i]);
    for (int pointer = 0; pointer < n; pointer++) {
        for (int i = n-pointer; i > 0; i--) {
            cout << "UZMI L L\n";
            if (l[i] == optimal[pointer]) {
                cout << "STAVI L R\n";
                cout << "UZMU R R\n";
                l.pop_back();
            }
            else {
                cout << "STAVI L R\n";
                r.push_back(l[i]);
                l.pop_back();
            }
        }
        for (int i = n-1; i > pointer; i--) {
            cout << "UZMI L R\n";
            cout << "STAVI L L\n";
            l.push_back(r[i]);
            r.pop_back();
        }
        cout << "STAVI R R\n";
    }
    return 0;
}

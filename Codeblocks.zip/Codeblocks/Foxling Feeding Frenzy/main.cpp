#include <bits/stdc++.h>

using namespace std;

int t;
int n, m;
int dp [201][201];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;

    return 0;
}

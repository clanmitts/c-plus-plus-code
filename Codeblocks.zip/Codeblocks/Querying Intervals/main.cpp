#include <bits/stdc++.h>

using namespace std;

int n;
int q;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int q1;
int q2;
int t;
int j;
vector <int> order;
int out [100001];
vector <pair<int, int>> tempvec;

void binarySearch(int x) {
    int l = 1;
    int r = order.size()-1;
    int mid = (l+r+1)/2;
    while (l <= r) {
        mid = (l+r+1)/2;
        cout << "c " << order.at(mid) << " " << x << endl;
        cout << flush;
        int temp;
        cin >> temp;
        if (temp == -1) exit(0);
        if (temp == x) {
            l = mid+1;
        }
        else {
            r = mid-1;
        }
    }
    order.insert(order.begin() + l, x);
    return;
}

bool compare (pair<int, int> a, pair<int, int> b) {
    return a.second<b.second;
}

int main()
{
    cin >> n;
    cin >> q1;
    cin >> q2;
    cin >> t;
    order.push_back(0);
    for (j = 1; j <= min(q2, n); j++) {
        cout << "h " << j << "\n";
        cout << flush;
        int temp;
        cin >> temp;
        tempvec.push_back({j, temp});
    }
    sort(tempvec.begin(), tempvec.end(), compare);
    for (pair<int, int> i: tempvec) order.push_back(i.first);
    for (int i = j; i <= n; i++) {
        binarySearch(i);
    }
    for (int i = 1; i <= n; i++) out[order.at(i)] = i;
    cout << "!";
    for (int i = 1; i <= n; i++) cout << " " << out[i];
    cout << endl;
    cout << flush;
    return 0;
}

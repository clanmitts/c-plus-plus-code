#include <bits/stdc++.h>

using namespace std;

int n;
long long total;
int leader [100001];
tuple<int, int, long long> num [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
long long mountain [5001];
long long value [5001];
long long out [5001];
long long tempbest;

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> mountain[i];
    }
    out[1] = 0;
    for (int i = 2; i <= n; i += 2) {
        tempbest = 1e18 +1;
        for (int j = 1; j <= n-i; j++) {
            value [j + (i/2)] += abs(mountain[j]-mountain[j+i]);
            if (value[j+(i/2)] < tempbest) {
                    tempbest = value[j+(i/2)];
            }
        }
        out[i+1] = tempbest;
    }
    fill(value, value+n+1, 0);
    for (int i = 1; i <= n;i += 2) {
        tempbest = 1e18+1;
        for (int j = 1; j <= n-i; j++) {
            value [j + (i/2)] += abs(mountain[j]-mountain[j+i]);
            if (value[j+(i/2)] < tempbest) {
                    tempbest = value[j+(i/2)];
            }
        }
        out[i+1] = tempbest;
    }
    cout << out[1];
    for (int i = 2; i <= n; i++) {
        cout << " " << out[i];
    }
    cout << endl;
    return 0;
}

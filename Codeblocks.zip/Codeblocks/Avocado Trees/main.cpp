#include <bits/stdc++.h>

using namespace std;

int n;
int q;
int h;
long long tree [1000001];
long long maximum = 0;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    cin >> h;
    for (int i = 1; i <= n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        if (a <= h) {
            tree[i] += b;
        }
        tree[i] += tree[i-1];
    }
    for (int i = 1; i <= q; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        maximum = max(maximum, tree[b]-tree[a-1]);
    }
    cout << maximum << "\n";
    return 0;
}

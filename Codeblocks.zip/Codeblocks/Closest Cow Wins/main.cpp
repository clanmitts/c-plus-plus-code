#include <bits/stdc++.h>

using namespace std;

int k;
int m;
int n;
pair<int, int> grass [200002];
int nhoj [200002];
int distance [200002];



int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> k;
    cin >> m;
    cin >> n;
    for (int i = 1; i <= k; i++) {
        cin >> grass[i].first;
        cin >> grass[i].second;
    }

    for (int i = 1; i <= m; i++) {
        cin >> nhoj[i];
    }
    nhoj[m+1] = INT_MAX;
    sort(grass, grass+k+1);
    int l = 1;
    for (int i = 1; i <= k; i++) {
        while (grass[i].first > nhoj[l]) l++;

    }
    return 0;
}

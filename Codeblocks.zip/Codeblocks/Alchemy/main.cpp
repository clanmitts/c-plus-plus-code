#include <bits/stdc++.h>

using namespace std;

int n;
int amount [101];
int k;
vector<int> graph [101];
int l;
int m;
int total;


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin>> amount [i];
    cin >> k;
    for (int i = 1; i <= n; i++) {
        cin >> l;
        cin >> m;
        for (int j = 1; j <= m; j++) {
            int temp;
            cin >> temp;
            graph[l].push_back(temp);
        }
    }
    while (true) {

    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
long long a [1000000];
long long b [1000000];
int l;
int r;
long long ans;



int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= m; i++) cin >> b[i];
    sort(a, a+n+1);
    sort(b, b+m+1);
    a[0] = INT_MIN;
    b[0] = INT_MIN;
    a[n+1] = INT_MIN;
    b[m+1] = INT_MIN;
    l = 1;
    r = 1;
    ans = INT_MAX;
    while (l <= n) {
        if (abs(b[r]-a[l]) < abs(b[r+1]-a[l])) {
            ans = min(ans,abs(b[r]-a[l]));
            l++;
        }
        else r++;
    }
    cout << ans;
    return 0;
}

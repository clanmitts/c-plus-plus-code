#include <bits/stdc++.h>

using namespace std;

int n;
int h;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> h;
    h *= 2;
    for (int i = 1; i <= n; i++) {
        int temp;
        cin >> temp;
        cout << temp+h << " \n"[i == n];
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int b;
int most;
char grid [121][121];
bool vis [121][121];

int path(int x, int y, int dir) {
    cout << x << " " << y << " " << dir << endl;
    int startx = x;
    int starty = y;
    int counter = 0;
    if (dir == 1) {
        while (x > 0 && grid[x][y] != '#') {
            cout << x << " " << y << endl;
            x--;
            if (vis[x][y]) {

                for (int i = x; i < startx; i++) {
                    vis[x][y] = false;
                }
                return counter;
            }
            counter ++;
            vis[x][y] = true;
        }
        x++;
        counter --;
        int a = 0;
        int b = 0;
        cout << counter << endl;
        cout << grid[x][y+1] << endl;;
        if (y+1 <= n && grid[x][y+1] != '#')a = path(x, y, 2);
        if (y-1 >= 1 && grid[x][y-1] != '#') b = path(x, y, 4);
        for (int i = x; i < startx; i++) {
            vis[x][y] = false;
        }
        cout << counter + max(a, b) << endl;;
        return counter + max(a, b);
    }
    if (dir == 2) {
        while (y <= n && grid[x][y] != '#') {
                cout << x << " " << y << endl;
            y++;
            if (vis[x][y]) {
                 for (int i = y; i > starty; i--) {
                    vis[x][y] = false;
                }
                return counter;
            }
            counter ++;
            vis[x][y] = true;
        }
        y--;
        counter --;
        int a = 0;
        int b = 0;
        cout << counter << endl;
        if (x-1 >= 0 && grid[x-1][y] != '#') a= path(x, y, 1);
        if (x+1 <= n && grid[x+11][y] != '#') b = path(x, y, 3);
        for (int i = y; i > starty; i--) {
            vis[x][y] = false;
        }
        cout << counter + max(a, b) << endl;
        return counter + max(a, b);
    }
     if (dir == 3) {
        while (x <= n && grid[x][y] != '#') {
            cout << x << " " << y << endl;
            x++;
            if (vis[x][y]) {
                for (int i = x; i > startx; i--) {
                    vis[x][y] = false;
                }
                return counter;
            }
            counter ++;
            vis[x][y] = true;
        }
        x--;
        counter --;
        int a = 0;
        int b = 0;
        cout << counter << endl;
        if (y+1 <= n && grid[x][y+1] != '#') a = path(x, y, 2);
        if (y-1 >= 1 && grid[x][y-1] != '#') b = path(x, y, 4);
        for (int i = x; i > startx; i--) {
            vis[x][y] = false;
        }
        cout << counter + max(a, b) << endl;
        return counter + max(a, b);
    }
    if (dir == 4) {
        while (y > 0 && grid[x][y] != '#') {
            cout << x << " " << y << endl;
            y--;
            if (vis[x][y]) {
                 for (int i = y; i < starty; i++) {
                    vis[x][y] = false;
                }
                return counter;
            }
            counter ++;
            vis[x][y] = true;
        }
        y++;
        counter --;
        int a = 0;
        int b = 0;
        if (x-1 >= 0 && grid[x-1][y] != '#') a= path(x, y, 1);
        if (x+1 <= n && grid[x+1][y] != '#') b = path(x, y, 3);
        for (int i = y; i < starty; i++) {
            vis[x][y] = false;
        }
        cout << counter + max(a, b) << endl;;
        return counter + max(a, b);
    }
}

int main()
{
    cin >> n;
    cin >> b;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            grid[i][j] = '.';
            vis[i][j] = false;
        }
    }
    for (int i = 1; i <= b; i++) {
        string temp;
        cin >> temp;
        int x = temp[0]-'A'+1;
        int y = stoi(temp.substr(1, 123));
        grid[y][x] = '#';
    }
    cout << max(path(1, 1, 2), path(1, 1, 3)) + 1 << endl;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cout << grid[i][j];
        }
        cout << endl;
    }
    return 0;
}

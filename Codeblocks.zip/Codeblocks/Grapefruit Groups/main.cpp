#include <bits/stdc++.h>

using namespace std;

int n;
long long a [1000001];
bool newGroup [1000001];
long long  suff [1000002];
long long group;
long long total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    newGroup[1] = true;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for (int i = n; i >= 1; i--) {
        suff[i] = suff[i+1]+a[i];
        if (suff[i] > 0) newGroup[i] = true;
    }
    for (int i = 1; i <= n; i++) {
        if (newGroup[i]) group++;
        total += a[i]*group;
    }
    cout << total << endl;
    cout << endl;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int u;
int t;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> u;
    cin >> t;
    cout << u + 3*t << endl;
    return 0;
}

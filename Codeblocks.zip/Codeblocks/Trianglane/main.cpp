#include <bits/stdc++.h>

int n;
int arr [2000001][3];
int tape = 0;


using namespace std;

int main()
{
    cin >> n;
    for (int i = 1; i <= 2; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> arr[j][i];
        }
    }
    for (int i = 1; i <= n; i++) {
        if (arr[i][1] == 1 && arr[i-1][1] == 1) tape += 1;
        else if (arr[i][1] == 1 && arr[i-1][1] == 0) tape += 3;
    }
    for (int i = 1; i <= n; i++) {
        if (i % 2 == 0) {
            if (arr[i][2] == 1 && arr[i-1][2] == 1) tape += 1;
            else if (arr[i][2] == 1 && arr[i-1][2] == 0) tape += 3;
        }
        else if (i % 2 == 1) {
            if (arr[i][2] == 1 && arr[i][1] == 1 && arr[i-1][2] == 1) tape -= 1;
            else if (arr[i][2] == 1 && arr[i][1] == 0 && arr[i-1][2] == 1) tape += 1;
            else if (arr[i][2] == 1 && arr[i][1] == 1 && arr[i-1][2] == 0) tape += 1;
            else if (arr[i][2] == 1 && arr[i][1] == 0 && arr[i-1][2] == 0) tape += 3;
        }
    }
    cout << tape << endl;
    return 0;
}

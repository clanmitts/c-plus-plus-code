#include <bits/stdc++.h>

using namespace std;

int n;
int m;
bool vis[100001];
deque<int> q;
vector<int> adj [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        adj[b].push_back(a);
    }
    q.push_back(1);
    while (!q.empty()) {
        int cur = q.front();
        q.pop_front();
        for (int i: adj[cur]) {
            if (!vis[i]) {
                vis[i] = true;
                q.push_back(i);
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        cout << vis[i];
    }
    cout << endl;
    return 0;
}

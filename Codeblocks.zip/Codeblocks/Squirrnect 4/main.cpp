#include <bits/stdc++.h>

using namespace std;

int w;
int h;
int n;

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin.tie(NULL);
        ios_base::sync_with_stdio(false);
        cin >> w;
        cin >> h;
        if (w == 1) cout << "bad\n";
        else if (h == 1 && w < 7) cout << "bad\n";
        else if (h < 4 && w < 4) cout << "bad\n";
        else cout << "good\n";
    }
    return 0;
}

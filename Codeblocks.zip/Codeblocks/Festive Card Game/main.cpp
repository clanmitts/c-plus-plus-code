#include <bits/stdc++.h>

using namespace std;

int n;
int arr [1000001];
int l;
int r;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = n; i >= 1; i--) {
        cout << i << " ";
    }
    cout << endl;
    if (n % 2 == 1) {
        arr[(n+1)/2] = n;
        l = (n+1)/2-1;
        r = (n+1)/2+1;
        for (int i = n-1; i >= 1; i--) {
            if (i%2 == 0) {
                arr[l] = i;
                l--;
            }
            else {
                arr[r] = i;
                r++;
            }
        }
    }
    else {
        l = n/2;
        r = (n+2)/2;
        for (int i = n; i >= 1; i--) {
            if (i%2 == 0) {
                arr[l] = i;
                l--;
            }
            else {
                arr[r] = i;
                r++;
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
    return 0;

}

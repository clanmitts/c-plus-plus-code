#include <bits/stdc++.h>

using namespace std;

int n;
int arr [1000001];
int maximum = 0;
int l = 1;
int r;
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    r = n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    maximum = n;
    while (l <= r) {
        if (r-l+1 == maximum) total++;
        if (arr[l] > arr[r]) {
            maximum = min(arr[l]-1, maximum);
            l++;
        }
        else {
            maximum = min(arr[r]-1, maximum);
            r--;
        }
    }
    cout << total << "\n";
    return 0;
}

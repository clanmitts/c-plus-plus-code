#include <bits/stdc++.h>

using namespace std;

int t;
int g;
bool played [5][5];
int score [5];
int win;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    cin >> g;
    for (int i = 1; i <= g; i++) {
        int t1;
        int t2;
        int s1;
        int s2;
        cin >> t1 >> t2 >> s1 >> s2;
        played[t1][t2] = true;
        played[t2][t1] = true;
        if (s1 > s2) score[t1] += 3;
        else if (s2 > s1) score[t2] += 3;
        else {}
        score[t1] ++;
        score[t2] ++;
    }

    return 0;
}

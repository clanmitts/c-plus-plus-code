#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main()
{
    ios::sync_with_stdio(0);
	cin.tie(0);

    int tt; cin >> tt;
    while(tt--)
    {
        int n; cin >> n;
        stack<int> branch;
        stack<int> mountain;
        int target = 1;

        for(int i = 0; i < n; ++i)
        {
            int a; cin >> a;
            mountain.push(a);
        }
	    while(!mountain.empty() || !branch.empty()){

            if(!mountain.empty() && mountain.top() == target){
                mountain.pop();
                if(target < n)
                    target++;
            }
            else if (!branch.empty() && branch.top() == target)
            {
                branch.pop();
                if(target < n)
                    target++;
            }
            else if(mountain.size() > 1){
                branch.push(mountain.top());
                mountain.pop();
            }
            else
            {
                cout << "N\n";
                break;
            }
	    }
        if(target == n)
        {
            cout << "Y\n";
        }
    }

	return 0;
}

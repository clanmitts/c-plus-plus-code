#include <bits/stdc++.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

int n;
int m;
int r;
int c;
char poster [2001][2001];
int a = 2;
int b = 2;
char letter;
bool column [2001];
bool row [2001];

int main()
{
    srand (time(NULL));
    poster[0][1] = 'a'-1;
    poster[1][0] = 'a'-1;
    cin >> n;
    cin >> m;
    cin >> r;
    cin >> c;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            poster[i][j] = '0';
        }
    }
    for (int i = 1; i <= n; i++) {
        poster[i][0] = 'a'-1;
    }
    for (int i = 1; i <= m; i++) {
        poster[0][i] = 'a'-1;
    }
    if ((r == n && c == m-1) || (r == n-1 && c == m)) {
        cout << "IMPOSSIBLE" << endl;
    }
    else {
        if (r >= 1) {
            poster[1][1] = 'a';
            poster[1][m] = 'a';
            for (int i = 2; i <= m/2; i++) {
                if (poster[1][i-1] == 'z') poster[1][i] = 'a';
                else poster[1][i] = poster[1][i-1]+1;
                poster[1][m-i+1] = poster[1][i];
            }
            row[1] = true;
        }
        if (c >= 1) {
            poster[1][1] = 'a';
            poster[n][1] = 'a';
            for (int i = 2; i <= n/2; i++) {
                if (poster[i-1][1] == 'z') poster[i][1] = 'a';
                else poster[i][1] = poster[i-1][1]+1;
                poster[n-i+1][1] = poster[i][1];
            }
            column[1] = true;
        }
        while (a <= r) {
            row[a] = true;
            if (poster[a-1][1] == 'z') poster[a][1] = 'a';
            else poster[a][1] = poster[a-1][1] + 1;
            poster[a][m] = poster[a][1];
            for (int i = 2; i <= m/2; i++) {
                if (poster[a][i-1] == 'z') poster[a][i] = 'a';
                else poster[a][i] = poster[a][i-1]+1;
                poster[a][m-i+1] = poster[a][i];
            }
            a++;
        }
        while (b <= c) {
            column[b] = true;
            if ('a' <= poster[1][b] && poster[1][b] <= 'z');
            else {
                    if (poster[1][b-1] == 'z') poster[1][b] = 'a';
                    else poster[1][b] = poster[1][b-1]+1;
            }
            poster[n][b] = poster[1][b];
            for (int i = 2; i <= n/2; i++) {
                if ('a' <= poster[i][b] && poster[i][b] <= 'z') {
                    poster[n-i+1][b] = poster[i][b];
                }
                else {
                    if (poster[i-1][b] == 'a') poster[i][b] = 'z';
                    else poster[i][b] = poster[i-1][b];
                    poster[n-i+1][b] = poster[i][b];
                }
            }
            b++;
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (poster[i][j] == '0') {
                    poster[i][j] = (rand()*32)%26 + 'a';
                }
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                cout << poster[i][j];
            }
            cout << endl;
        }
    }
    return 0;
}

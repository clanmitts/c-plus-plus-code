#include <bits/stdc++.h>

using namespace std;

int n;
int num [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> num[i];

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
string arr [200001];
int last [1000];
int cur;
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }

    return 0;
}

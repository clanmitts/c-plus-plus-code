#include <bits/stdc++.h>

using namespace std;

int n, m;
int arr [3][1000001];
int maximum = INT_MAX;
int minimum = 0;
long long total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= 2; j++) {
            cin >> arr[j][i];
        }
    }
    for (int i = 1; i < n; i++) {
        int temp = 0;
        int counter = 0;
        if (arr[1][i] == 0) counter ++;
        else temp += arr[1][i];
        if (arr[2][i] == 0) counter ++;
        else temp += arr[2][i];
        if (arr[1][i+1] == 0) counter ++;
        else temp += arr[1][i+1];
        if (arr[2][i+1] == 0) counter ++;
        else temp += arr[2][i+1];
        minimum = max(minimum, temp + counter);
        maximum = min(maximum, temp + counter*m);
    }
    if (maximum < minimum) cout << 0 << endl;
    else {
        for (int i = minimum; i <= maximum; i++) {
            long long temptotal = 1;
            for (int j = 1; j < n; j++) {
                int counter = 0;
                if (arr[1][i] == 0) counter ++;
                if (arr[2][i] == 0) counter ++;
                if (arr[1][i+1] == 0) counter ++;
                if (arr[2][i+1] == 0) counter ++;
                if (counter == 1) {
                    temptotal *= (maximum-minimum);
                }
                else if (counter == 2) {
                    temptotal *= (maximum-minimum-1);
                }
                else if (counter == 3) {
                    temptotal *= (((maximum-minimum-2)+1)*(maximum-minimum-2)/2);
                }
                else if (counter == 4) {
                    temptotal +=
                }
            }
            total += temptotal;
        }
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
char arr [2001];
int dis [2001][2001];
bool vis [2001][2001];
bool found [2001][2001];

void island(int a, int b) {
    vis[a][b] = true;
    dis[a][b] = 1;
    for ()
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    for (int i = 1; i <= n; i++) {
        for (int i = 1; i <= m; i++) {
            if (!vis[i][j] && arr[i][j] == '#') {
                island(i, j);
            }
        }
    }
    return 0;
}

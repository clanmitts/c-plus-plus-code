#include <bits/stdc++.h>

using namespace std;

string str;

void func() {
    if (str[0] == str[1] && str[1] == str[2] && str[2] == str[3]) {
        cout << "weak" << endl;
        return;
    }
    if (((str[1]-str[0] == 1)||(str[1] - str[0] == -9)) && ((str[2]-str[1] == 1)||(str[2] - str[1] == -9)) && ((str[3]-str[2] == 1)||(str[3] - str[2] == -9))) {
        cout << "weak" << endl;
        return;
    }
    if (((str[1]-str[0] == -1)||(str[1] - str[0] == 9)) && ((str[2]-str[1] == -1)||(str[2] - str[1] == 9)) && ((str[3]-str[2] == -1)||(str[3] - str[2] == 9))) {
        cout << "weak" << endl;
        return;
    }
    cout << "strong" << endl;
    return;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> str;
    func();
    return 0;
}

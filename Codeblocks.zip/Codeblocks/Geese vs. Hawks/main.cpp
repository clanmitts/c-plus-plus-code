#include <bits/stdc++.h>

using namespace std;

int n;
string str1;
string str2;
int val1 [1001];
int val2[1001];
int dp [1001][1001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str1;
    for (int i = 1; i <= n; i++) {
        cin >> val1[i];
    }
    cin >> str2;
    for (int i = 1; i <= n; i++) {
        cin >> val2[i];
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if ((str1[i-1] == 'W' && str2[j-1] == 'L' && val1[i] > val2[j]) || (str1[i-1] == 'L' && str2[j-1] == 'W' && val1[i] < val2[j])) {
                dp[i][j] = max(dp[i-1][j-1]+val1[i]+val2[j], max(dp[i-1][j], dp[i][j-1]));
            }
            else {
                dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
            }
        }
    }
    cout << dp[n][n] << endl;

    return 0;
}

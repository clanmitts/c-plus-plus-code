#include <bits/stdc++.h>

using namespace std;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    int n;
    int a [n];
    int b [n];
    int ans = 0;
    int ind = 0;
    bool used [n+1];
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> b[i];
    }
    for (int i = 0; i < n; i++) {
        while (used[a[ind]]) {
            ind++;
        }
        if (b[i] == a[ind]) {
            ind++;
        }
        else {
            ans++;
            used[b[i]] = true;
        }
    }
    cout << ans << endl;
}

#include <bits/stdc++.h>

using namespace std;

int t;
int n;
int arr [100001];
int order [100001];
int ind = 1;
int high [100001];
int low [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int ind = 1;
        for (int i = 1; i <= n; i++) {
            high[i] = -1;
            low [i] = INT_MAX;
        }
        cin >> n;
        for (int j = 1; j <= n; j++) {
            cin >> arr[i];
        }
        for (int i = 1; i <= n; i++) {

        }
    }
    return 0;
}

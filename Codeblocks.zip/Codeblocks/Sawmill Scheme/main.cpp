#include <bits/stdc++.h>

using namespace std;

vector<int> river [1000001];
double dp [1000001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    int n;
    int m;
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        river[a].push_back(b);
    }
    dp[1] = 1;
    for (int i = 1; i <= n; i++) {
        double cur = dp[i];
        if (river[i].size() != 0) {
            double temp = cur/river[i].size();
            for (int j = 0; j < river[i].size(); j++) {
                int index = river[i][j];
                dp[index] += temp;
            }
        }
    }
    cout << setprecision(9);
    for (int i = 1; i <= n; i++) {
        if (river[i].size() == 0) {
            cout << dp[i] << endl;
        }
    }
    return 0;
}

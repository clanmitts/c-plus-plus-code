#include <bits/stdc++.h>

using namespace std;

int n;
int m;
string cow;
bool goodg [100001];
bool goodh [100001];
deque<int> q;
int ind;
int grassg;
int grassh;
vector<int> grassgloc;
vector<int> grasshloc;
int a;
int b;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    int temp;
    cin >> cow;
    cow = " " + cow;
    q.clear();
    for (int i =1 ; i <= n; i++) {
        if (cow[i] == 'G') q.push_back(i);
    }
    while (!q.empty()) {
        cout << q.front() << endl;
        q.pop_front();
    }
    ind = 1;
    cout << q.size() << endl;
    while (ind <= n && !q.empty()) {
        if (ind - q.front() < m) {
        }
        else {
            grassg++;
            grassgloc.push_back(ind);
            while (q.front()- ind <= m) {
                q.pop_front();
            }
        }
        ind++;
    }
    if (!q.empty()) grassg ++;
    q.clear();
    for (int i =1 ; i <= n; i++) {
        if (cow[i] == 'H') q.push_back(i);
    }
    ind = 1;
    while (ind <= n && !q.empty()) {
        if (ind - q.front() < m) {
        }
        else {
            grassh++;
            grasshloc.push_back(ind);
            while (q.front()- ind <= m) {
                q.pop_front();
            }
        }
        ind++;
    }
    if (!q.empty()) grassh ++;
    cout << grassg + grassh << endl;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int num [500001];
int righ [500001];
int lef [500001];
long long inv = 0;

void addsumleft(int index, int value) {
    while (index <= n) {
        lef[index] += value;
        index += (index & -index);
    }
}

void addsumright(int index, int value) {
    while (index <= n) {
        righ[index] += value;
        index += (index & -index);
    }
}

int getsumleft(int index) {
    int sum = 0;
    while (index > 0) {
        sum += lef[index];
        index -= (index & -index);
    }
    return sum;
}

int getsumright(int index) {
    int sum = 0;
    while (index > 0) {
        sum += righ[index];
        index -= (index & -index);
    }
    return sum;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> num[i];
    for (int i = 1; i <= n; i++) {
        if (getsumleft(num[i]) < getsumright(n-num[i]+1)) {
            inv += getsumleft(num[i]);
            addsumleft(num[i], 1);
            addsumright(n-num[i]+1, 1);
        }
        else {
            inv += getsumright(n-num[i]+1);
            addsumleft(num[i], 1);
            addsumright(n-num[i]+1, 1);
        }
    }
    cout << inv << endl;
    return 0;
}

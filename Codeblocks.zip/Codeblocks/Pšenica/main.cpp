#include <bits/stdc++.h>

using namespace std;

int n;
int arr [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    sort(arr, arr+n+1);
    return 0;
}

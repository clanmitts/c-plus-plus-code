#include <bits/stdc++.h>

using namespace std;

int n;
int num [100001];

long long func (int x) {
    long long temp = 0;
    for (int i = 1; i <= n; i++) {
        temp += abs(x-num[i]);
    }
    return temp;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {

    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int d;
int k;
int o;
int r;
int total;

int main()
{

    return 0;
}

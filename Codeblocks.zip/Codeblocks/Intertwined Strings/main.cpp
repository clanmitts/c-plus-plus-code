#include <bits/stdc++.h>

using namespace std;

char a [13];
char b [13];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    string tempa;
    string tempb;
    cin >> tempa;
    cin >> tempb;
    for (int i = 0; i < tempa.size(); i++) a[i+1] = tempa[i];
    for (int i = 0; i < tempb.size(); i++) b[i+1] = tempb[i];

    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int people [150001];
int bit [150001];

void update(int index, long long val) {
    while (index <= n) {
        bit[index] += val;
        index += (index & -index);
    }
}

int num(int index) {
    long long sum = 0;
    while (index > 0) {
        sum += bit[index];
        index -= (index & -index);
    }
    return sum;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    int coun = 0;
    for (int i =1; i <= 10000000000; i++) {
        coun ++;
    }
    cout << coun << endl;
    return 0;
}

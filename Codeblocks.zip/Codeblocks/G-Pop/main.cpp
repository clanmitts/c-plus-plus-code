#include <bits/stdc++.h>

using namespace std;

int n;
int q;
pair<int, int> num [500001];
priority_queue<int, vector<int>, greater<>> check;
int out [500001];
int ind = 1;
int maxdis;

bool func(const pair<int,int> &a, const pair<int,int> &b){
    return (a.second < b.second);
}

int main()
{

    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;

    for (int i = 1; i <= q; i++) {
        cin >> num[i].first;
        cin >> num[i].second;
    }
    for (int i = 1; i <= n; i++) {
        maxdis = max(maxdis, num[i].second-num[i].first+1);
    }
    sort(num, num+q+1, func);
    for (int i = 1; i <= n; i++) {
        while (ind <= q && num[ind].second >= i) {;
            check.push(num[ind].first);
            ind++;
        }
        while (!check.empty() && check.top() > i) {
            check.pop();
        }
        if (check.top() == i) out[i] = out[i-1];
        else out[i] = out[i-1]+1;
        cout << check.top() << "\n";
    }
    cout << maxdis << "\n";
    for (int i = 1; i <= n; i++) cout << out[i]%maxdis+1 << " \n"[i == n] ;
    cout << "\n";
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int give [9];
int want [9];
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    for (int i = 1; i <= 8; i++) {
        cin >> give[i];
    }
    for (int i = 1; i <= 8; i++) {
        cin >> want[i];
    }
    total
    return 0;
}

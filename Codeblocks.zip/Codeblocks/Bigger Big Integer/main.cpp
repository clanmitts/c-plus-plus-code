#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    char list [n+1];
    for (int i = 1; i <= n; i++) {
        cin >> list[i];
    }
    for (int i = 2; i <= n; i++) {
        if (list[i] > list[i-1]) {
            char temp = list[i];
            list[i] = list[i-1];
            list[i-1] = temp;
            break;
        }
    }
    for (int i = 1; i <= n; i++) {
        cout << list[i];
    }
    cout << endl;
    return 0;
}

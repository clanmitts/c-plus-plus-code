#include <bits/stdc++.h>

using namespace std;

int n;
string arr [2];
int total;

int main()
{
    cin >> n;
    cin >> arr[0];
    cin >> arr[1];
    for (int i = 0; i < n; i++) {
        if (arr[0][i] == arr[1][i] && arr[0][i] == 'C') total ++;
    }
    cout << total << endl;
}

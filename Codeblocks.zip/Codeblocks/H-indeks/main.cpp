#include <bits/stdc++.h>

using namespace std;

int n;
int arr [500001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    arr[0] = INT_MAX;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    sort(arr, arr+n+1, greater<int>());
    int index = 1;
    while (index <= arr[index]) {
        index ++;
    }
    cout << index-1 << "\n";
    return 0;
}

#include <iostream>
#include <vector>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n, k;
    cin >> n >> k;
    char list [n+2];
    string temp;
        cin >> temp;
    for (int i = 1; i <= n; i++) {
        list[i] = temp[i-1];
    }
    list[n+1] = '1';
    int l = 0;
    int r = 1;
    vector<int> space;
    while (r <= n+1) {
        if (list[r] == '1') {
            space.push_back(r-l-1);
            l = r;
        }
        r++;
    }
    space.push_back(10000000);
    sort(space.begin(), space.end(), greater<int>());
    int count = 0;
    int size = space.size();
    for (int i = 1; i <= min(size-1, k); i++) {
        count += space[i];
    }
    cout::count;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
double x[123432];
double y[123432];
double a;
double b;
double c;
double tri1, tri2, tri3;
double semiPerimeter;
double diameter;
double ans;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    double x[12343];
    double y[23432];
    double a, b, c, semiP = 0, diameter, output = 0;
    double tri1, tri2, tri3;
    for (int i = 0; i < n; i++) {
        cin >> x[i];
        cin >> y[i];
    }
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            for (int k = 0; k < n; k++) {
                a = sqrt(pow(x[i] - x[j], 2) + pow(y[i] - y[j], 2));
                b = sqrt(pow(x[j] - x[k], 2) + pow(y[j] - y[k], 2));
                c = sqrt(pow(x[k] - x[i], 2) + pow(y[k] - y[i], 2));
                semiP = (a + b + c) / 2;
                diameter = 0;
                tri1 = (a * a) + (b * b) - (c * c);
                tri2 = (b * b) + (c * c) - (a * a);
                tri3 = (a * a) + (c * c) - (b * b);
                if (tri1 < 0 || tri2 < 0 || tri3 < 0 || semiP == 0) {
                    if (a > diameter) diameter = a;
                    if (b > diameter) diameter = b;
                    if (c > diameter) diameter = c;
                }
                else {
                    diameter = (a * b * c);
                    diameter /= (4 * sqrt (semiP * (semiP - a) * (semiP - b) * (semiP - c)));
                    diameter *= 2;
                }
                if (diameter > output) output = diameter;
            }
    output = floor(output * 100.0) / 100.0;
    cout << output << endl;
}

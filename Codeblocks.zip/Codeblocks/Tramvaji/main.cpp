#include <bits/stdc++.h>

using namespace std;

int n;
long long dis [1001];
long long psa [1001];
string str;
int a;
int b;
long long shortest = 1e18+1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 2; i <= n; i++) {
        cin >> str;
        if (str == "Patrik") {
            cin >> a;
            dis[i] = a-psa[i-1];
            psa[i] = psa[i-1] + dis[i];
        }
        if (str == "Josip") {
            cin >> a;
            cin >> b;
            dis[i] = b - (psa[i-1]-psa[a]);
            psa[i] = psa[i-1] + dis[i];
        }
    }
    for (int i = 2; i <= n; i++) {
        if (dis[i] < shortest) {
            shortest = dis[i];
            a = i-1;
            b = i;
        }
    }
    cout << shortest << " " << a << " " << b << endl;
    return 0;
}

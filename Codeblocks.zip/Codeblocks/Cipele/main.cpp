#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int l [100001];
int r [100001];

bool checkn(int a) {
    int x =1;
    int y = 1;
    while (x <= n && y <= m) {
        if (abs(l[x]-r[y]) <= a) {
            x++;
            y++;
        }
        else {
            y++;
        }
    }
    if (x > n) return true;
    return false;
}

bool checkm(int a) {
    int x = 1;
    int y = 1;
    while (x <= m && y <= n) {
        if (abs(r[x]-l[y]) <= a) {
            x ++;
            y ++;
        }
        else {
            y ++;
        }
    }
    if (x > m) return true;
    return false;
}

int binarySearchn() {
    int ugly = 2e9+1;
    int a = 1;
    int b = 1e9;
    while (a <= b) {
        int mid = (a+b)/2;
        if (checkn(mid)) {
            b = mid-1;
            ugly = min(ugly, mid);
       }
        else {
            a = mid+1;
        }
    }
    if (checkn(0)) ugly = 0;
    return ugly;
}

int binarySearchm() {
    int ugly = 2e9+1;
    int a = 1;
    int b = 1e9;
    while (a <= b) {
        int mid = (a+b)/2;
        if (checkm(mid)) {
            b = mid-1;
            ugly = min(ugly, mid);
        }
        else {
            a = mid+1;
        }
    }
    if (checkm(0)) ugly = 0;
    return ugly;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        cin >> l[i];
    }
    for (int i = 1; i <= m; i ++) {
        cin >> r[i];
    }
    sort(l+1, l+n+1);
    sort(r+1, r+m+1);
    if (n <= m) {
        cout << binarySearchn();
    }
    else if (m < n) {
        cout << binarySearchm();
    }
    return 0;
}

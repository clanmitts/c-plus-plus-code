#include <bits/stdc++.h>

using namespace std;

int n;
vector<int> arr [100001];
int s [100001];
bool vis [100001];
deque<int> q;
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n-1; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }
    s[1] = ceil(log2(arr[1].size()+1));
    s[1] += arr[1].size();
    vis[1] = true;
    for (int i: arr[1]) q.push_back(i);
    while (!q.empty()) {
        int cur = q.front();
        q.pop_front();
        vis[cur] = true;
        s[cur] = ceil(log2(arr[cur].size()));
        s[cur] += arr[cur].size()-1;
        for (int i: arr[cur]) {
            if (!vis[i]) q.push_back(i);
        }
    }
    for (int i: s) total += i;
    cout << total << endl;
    return 0;
}

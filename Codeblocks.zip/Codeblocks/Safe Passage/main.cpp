#include <bits/stdc++.h>

using namespace std;

int n;
int arr [16];
int total;
int counter;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> arr[i];
    sort(arr+1, arr+n+1);
    if (n > 2) {
        for (int i = n; i > 3; i-=2 ) {
            total += arr[i];
            counter ++;
        }
        for (int i = 1; i <= counter; i++) {
            total += arr[2];
            total += arr[1];
            total += arr[2];
        }
        if (n%2 == 1) {
            total += arr[3];
            total += arr[1];
            total += arr[2];
        }
        else total += arr[2];
        cout << total << endl;
    }
    else cout << arr[n];
    return 0;
}

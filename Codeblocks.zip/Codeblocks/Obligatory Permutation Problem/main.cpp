#include <bits/stdc++.h>

using namespace std;

int n;
long long k;
int num [100001];
int leader [100001];
deque<int> d;
int dis [100001];
bool used [100001];
int total [100001];
vector<int> sequence [100001];
int out [100001];

void loop (int a) {
    while (true) {
        if (!used[num[a]]) {
            sequence[leader[a]].push_back(num[a]);
            dis[num[a]] = dis[a]+1;
            used[num[a]] = true;
            leader[num[a]] = leader[a];
            total[leader[num[a]]] ++;
            a = num[a];
        }
        else return;
    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> k;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
    }
    for (int i = 1; i <= n; i++) {
        leader[i] = i;
    }
    for (int i = 1; i <= n; i++) {
        total[i] = 1;
    }
    for (int i = 1; i <= n; i++) {
        if (!used[i]) {
            sequence[i].push_back(i);
            used[i] = true;
            loop(i);
        }
    }
    for (int i = 1; i <= n; i++) {
        int temp = sequence[leader[i]][(int)(((long long)((long long)dis[i]+k))%sequence[leader[i]].size())];
        out[temp] = num[i];
    }
    for (int i = 1; i <= n; i++) cout << out[i] << " ";
    cout << "\n";
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int q;
int arr [1000000];
hash_map<int, int>

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    sort(arr, arr+n+1);
    cin >> q;
    for (int i = 1; i <= q; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        cout << binarySearchl(b+1)-binarySearchr(a-1) << endl;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
long num [100001];
long lar = 0;
long mod = 10;

bool compare(long long a, long long b) {
    if (a%mod == b%mod) return a < b;
    return (a%mod < b%mod);
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
    }
    for (int i = 1; i <= n; i++) {
        lar = max(lar, num[i]);
    }
    lar = floor(log10 (lar));
    for (int i = 1; i <= lar+1; i++) {
        sort(num, num+n+1, compare);
        cout << num[1];
        for (int j = 2; j <= n; j++) cout << " " << num[j];
        mod*= 10;
        cout << endl;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

string str;

bool z() {
    int counter = 0;
    for (char i: str) {
        if (i == 'z' || i == 'Z') counter ++;
    }
    return counter >= 3;
}

int main()
{
    std::getline(std::cin, str);
    if (z()) cout << "YES\n";
    else cout << "NO" << endl;
    return 0;
}

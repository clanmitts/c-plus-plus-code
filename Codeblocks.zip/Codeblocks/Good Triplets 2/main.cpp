#include <bits/stdc++.h>

using namespace std;

int n, c;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n, c;
    int point [2*n+1];
    for (int i = 1; i <= n; i++) {
        cin >> point[i];
        point[n+i] = point[i]+c;
    }
    int l = 1;
    while (l <= n) {
        while (point[0]-point[l] >= (c+1)/2) ;

    }
    return 0;
}

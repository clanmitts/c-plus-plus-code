#include <bits/stdc++.h>

using namespace std;
const int MAX_n = 1e6 + 1;


int n;
int b;
int t;
int num [MAX_n];
unordered_map<int, int> rightmost;
priority_queue<int, vector<int>> maxq;
priority_queue<int, vector<int>, greater<>> minq;
long long total;
int l = 1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> b;
    cin >> t;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
    }
    l = 1;
    for (int i = 1; i <= n; i++) {
        if (rightmost[num[i]] < i) {
            maxq.push(num[i]);
            minq.push(num[i]);
        }
        rightmost[num[i]] = i;
        while (!maxq.empty() && !minq.empty() && maxq.top() - minq.top() > t) {
            l++;
            while (!maxq.empty()) {
                if (rightmost[maxq.top()] < l) {
                    maxq.pop();
                }
                else break;
            }
            while (!minq.empty()) {
                if (rightmost[minq.top()] < l) {
                    minq.pop();
                }
                else break;
            }
        }
        total += i-l+1;
    }
    rightmost.clear();
    maxq = priority_queue<int, vector<int>>();
    minq = priority_queue<int, vector<int>, greater<>>();
    l = 1;
    for (int i = 1; i <= n; i++) {
        if (rightmost[num[i]] < i) {
            maxq.push(num[i]);
            minq.push(num[i]);
        }
        rightmost[num[i]] = i;
        while (!maxq.empty() && !minq.empty() && maxq.top() - minq.top() >= b) {
            l++;
            while (!maxq.empty()) {
                if (rightmost[maxq.top()] < l) {
                    maxq.pop();
                }
                else break;
            }
            while (!minq.empty()) {
                if (rightmost[minq.top()] < l) {
                    minq.pop();
                }
                else break;
            }
        }
        total -= i-l+1;
    }
    cout << total << endl;
    return 0;
}

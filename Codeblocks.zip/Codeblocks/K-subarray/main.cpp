#include <bits/stdc++.h>

using namespace std;

int n;
int k;
int arr [20001];
int psa [20001];
pair<int, int> optimized [20001];
vector<int> v;
int positive;
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> k;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    for (int i = 1; i <= n; i++) {
        psa[i] = psa[i-1]+arr[i];
    }
    for (int i = 1; i <= n; i++) {
        optimized[i].first = arr[i];
        optimized[i].second = i;
    }
    sort(optimized+1, optimized+n+1, greater<pair<int, int>>());
    for (int i = 1; i <= n; i++) if (arr[i] > 0) positive ++;
    if (positive <= k){
        for (int i = 1; i <= k; i++) total += optimized[i].first;
        cout << total;
    }
    return 0;
}

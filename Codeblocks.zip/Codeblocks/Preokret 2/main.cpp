#include <bits/stdc++.h>

using namespace std;

int n;
int arr [10000];
int a;
int b;
int even = 1;
int l;
int r;
int m;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> arr[i];
    for (int i = 1; i <= n; i++) {
        if (arr[i] == 1) a ++;
        if (arr[i] == 2) b ++;
        if (a == b) even ++;
    }
    cout << a << " " << b << "\n";
    cout << even << "\n";
    a = 0;
    b = 0;
    l = 1;
    r = 1;
    while (r <= n) {
        if (arr[l] == arr[r]) r++;
        if (arr[l] != arr[r]) {
            if (arr[l] == 1 && a < b && a+(r-l) > b) {
                    m = max(m, r-l);
            }
            if (arr[l] == 2 && b < a && b+(r-l) > a) {
                    m = max(m, r-l);
            }
            if (arr[l] == 1) a += (r-l);
            if (arr[l] == 2) b += (r-l);
            l = r;

        }
    }
    cout << m << "\n";
    return 0;
}

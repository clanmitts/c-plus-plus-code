#include <bits/stdc++.h>

using namespace std;

int n;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    if (n == 1) cout << 1 << endl;
    if (n == 2) cout << 2 << endl;
    if (n == 3) cout << 2 << endl;
    if (n == 4) cout << 3 << endl;
    if (n == 5) cout << 3 << endl;
    if (n == 6) cout << 3 << endl;
    if (n == 7) cout << 2 << endl;
    if (n == 8) cout << 2 << endl;
    if (n == 9) cout << 1 << endl;
    if (n == 10) cout << 1 << endl;
    return 0;
}

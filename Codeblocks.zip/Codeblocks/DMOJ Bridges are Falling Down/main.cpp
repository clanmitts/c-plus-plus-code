#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int leader [200001];
int connected [200001];
int path [100001][3];
long long output [100001];

int findLeader(int a) {
    if (leader[a] == a) return a;
    leader[a] = findLeader(leader[a]);
    return findLeader(leader[a]);
}

void connect(int a, int b, int c) {
    leader[a] = findLeader(a);
    leader[b] = findLeader(b);
    if (a == b) return;
    output[c] = connected[leader[a]]*connected[leader[b]];
    connected[leader[a]] += connected[leader[b]];
    leader[b] = findLeader(a);

}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) leader[i] = i;
    for (int i = 1; i <= n; i++) connected[i] = 1;
    for (int i = 1; i <= m; i++) {
        cin >> path[i][1];
        cin >> path[i][2];
    }
    for (int i = m; i >= 1; i--) {
        connect(findLeader(path[i][1]), findLeader(path[i][2]), i);
    }
    for (int i = 1; i <= m; i++) {
        output[i] += output[i-1];
    }
    for (int i = 1; i <= m; i++) {
        cout << output[i] << "\n";
    }
    return 0;
}

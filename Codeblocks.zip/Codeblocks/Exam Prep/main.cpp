#include <bits/stdc++.h>

using namespace std;

int n;
int q;
long long note [1000001];
int leader [1000001];
int sizeOf [1000001];

int leaderOf(int a) {
    if (leader[a] == a) return a;
    leader[a] = leaderOf(leader[a]);
    return leader[a];
}

void join (int a, int b) {
    leaderOf(a);
    leaderOf(b);
    if (leaderOf(a) == leaderOf(b)) return;
    note[leaderOf(b)] += note[leaderOf(a)];
    sizeOf[leaderOf(b)] += sizeOf[leaderOf(a)];
    leader[leaderOf(a)] = leaderOf(b);
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= n; i++) cin >> note[i];
    for (int i = 1; i <= n; i++) leader[i] = i;
    for (int i = 1; i <= n; i++) sizeOf[i] = 1;
    for (int i = 1; i <= q; i++) {
        int a;
        cin >> a;
        if (a == 1) {
            int b;
            int c;
            cin >> b;
            cin >> c;
            join(b, c);
        }
        else if (a == 2) {
            int b;
            cin >> b;
            cout << sizeOf[leaderOf(b)] << "\n";
        }
        else if (a == 3) {
            int b;
            cin >> b;
            cout << note[leaderOf(b)] << "\n";
        }
    }
    return 0;
}

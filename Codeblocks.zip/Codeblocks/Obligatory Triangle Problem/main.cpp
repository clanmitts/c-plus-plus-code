#include <bits/stdc++.h>

using namespace std;

int n;
int q;
double deg;
int ind;
double a;
double b;
long dis = 1000000000;
double temp;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> deg;
    for (int i = 1; i <= n; i++) {
        cin >> a;
        cin >> b;
        if (a == 0) {
            if (b > 0) {
                temp = 0;
            }
            else {
                temp = 180;
            }
            if (abs(q-temp) < dis) {
                ind = i;
                dis = abs(q-temp);
            }
            continue;
        }
        if (b == 0) {
            if (a > 0) {
                temp = 90;
            }
            else {
                temp = 270;
            }
            if (abs(q-temp) < dis) {
                ind = i;
                dis = abs(q-temp);
            }
            continue;
        }
        if (a >= 0 && b <= 0) {
            temp = 270;
        }
        else if (a <= 0 && b <= 0) {
            temp = 180;
        }
        else if (a <= 0 && b >= 0) {
            temp = 90;
        }
        else {
            temp = 0;
        }
        a = abs(a);
        b = abs(b);
        temp = atan(b/a*M_PI/180)*180/M_PI;
        if (abs(deg-temp) < dis) {
            dis = abs(deg-temp);
            ind = i;
        }
        cout << temp << endl;
    }
    cout << ind << "\n";

    return 0;
}

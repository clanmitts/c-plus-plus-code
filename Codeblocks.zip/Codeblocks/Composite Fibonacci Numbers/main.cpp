#include <bits/stdc++.h>

using namespace std;

bool fib [100001];
bool comp [100001];
int t;
int n;
int a;
int b;

int main()
{
    a = 1;
    b = 1;
    while (a+b <= 100000) {
        fib[a+b] = true;
        int temp = b;
        b = a+b;
        a = temp;
    }
    for (int i = 2; i * i <= 100000; i++) {
        if (!comp[i]) {
            for (int j = i * i; j <= 100000; j += i)
                comp[j] = true;
        }
    }
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        if (fib[n] && comp[n]) cout << "YES" << endl;
        else cout << "NO" << endl;
    }
    return 0;
}

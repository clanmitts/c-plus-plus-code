#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int puzzle [1501][1501];

bool func() {
    for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (puzzle[i][j] == 0) puzzle[i][j] = max(puzzle[i-1][j], puzzle[i][j-1])+1;
            }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (puzzle[i][j] <= puzzle[i-1][j] || puzzle[i][j] <= puzzle[i][j-1]) return false;
        }
    }
    return true;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> puzzle[i][j];
        }
    }
        if (func()) {
            for (int i = 1; i<= n; i++) {
                for (int j = 1; j <= m; j++) {
                    cout << puzzle[i][j] << " \n"[j == m];
                }
            }
        }
        else cout << -1 << "\n";
    return 0;
}

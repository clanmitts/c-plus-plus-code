#include <bits/stdc++.h>

using namespace std;

int n;
int c;
int point [2000002];
long long freq [1000001];
long long total = 0;
int l = 1;
int r = 1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> c;
    for (int i = 1; i <= n; i++) {
        cin >> point[i];
    }
    sort(point, point+n+1);
    for (int i = 1; i <= n; i++) {
        point[i+n] = point[i]+c;
    }
    for (l = 1; l <= n; l++) {
        while (r+1 <= 2*n && point[r+1]-point[l] < (c+1)/2) {
            r++;
        }
        total += (long long)(r-l)*(r-l-1)/2;
    }
    for (int i = 1; i <= n; i++) {
        freq[point[i]] ++;
    }
    if (c%2 == 0) {
        for (int i = 0; i < c/2; i++) {
            total += (long long)freq[i]*(long long)freq[i+(c/2)]*(long long)(n-freq[i]-(long long)freq[i+c/2]);
            total += (long long)freq[i]*(long long)(freq[i]-1)/2*(long long)freq[i+c/2] + (long long)freq[i]*(long long)(freq[i+c/2]*(long long)(freq[i+c/2]-1)/2);
        }
    }
    cout << (long long)n*(long long)(n-1)*(long long)(n-2)/6 - total << endl;
    return 0;
}

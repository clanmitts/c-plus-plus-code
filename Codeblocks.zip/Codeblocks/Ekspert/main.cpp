#include <bits/stdc++.h>

using namespace std;

long long x;
long long y;
long long product;
vector<pair<char, char>> arr;
char m;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> x;
    cin >> y;
    if (x < y) m = 'A';
    else {
            m = 'B';
            swap(x, y);
    }
    product = x*y;
    while (product/2 >= y) {
            cout << product << endl;
        if (product%2 == 1) {
            product -= 1;
            arr.push_back({'C', 'D'});
        }
        else {
            product /= 2;
            arr.push_back({'C', 'C'});
        }
    }
    while (product - x >= 0) {
        product -= x;
        arr.push_back({'C', m});
    }
    for (int i = arr.size()-1; i >= 0; i++) {
        cout << arr[i].first << " " << arr[i].second << endl;
    }
    return 0;
}

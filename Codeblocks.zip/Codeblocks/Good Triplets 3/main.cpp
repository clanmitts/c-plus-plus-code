#include <bits/stdc++.h>

using namespace std;

    vector<int> arr;
	int quarter;
	bool used [1000001];
	int middle(int a, int b, int c) {
		if ((a < b && b < c) || (c < b && b < a))
			return b;
		else if ((b < a && a < c) || (c < a && a < b))
			return a;
		else
			return c;
	}
	bool works (int a, int b, int c) {
		int one = abs(arr[a]-arr[b]);
		int two = abs(arr[a]-arr[c]);
		int three = abs(arr[c]-arr[c]);
		return (min(one, min(two, three)) + middle(one, two, three)) > quarter;
	}
	main() {
	    int n;
	    cin >> n;
	    int c;
	    cin >> c;
		quarter = (c+1)/2;
		for (int i = 1; i <= n; i++) {
			int temp;
			cin >> temp;
			if (!used[temp]) {
				arr.push_back(temp);
				used[temp] = true;
			}
		}
		int counter = 0;
		for (int i = 0; i < arr.size(); i++) {
			for (int j = i+1; j < arr.size(); j++) {
				for (int k = j+1; k < arr.size(); k++) {
					if (works(i, j, k)) counter ++;
				}
			}
		}
		cout << counter-1 << endl;
	}

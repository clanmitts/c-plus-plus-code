#include <bits/stdc++.h>

using namespace std;

int l;
int n;
int rf;
int rb;
tuple<int, int, int> grass [1000001];
int loc;
int ind =1;
long long ans;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> l;
    cin >> n;
    cin >> rf;
    cin >> rb;
    for (int i = 1; i <= n; i++) {
        cin >> get<1>(grass[i]);
        cin >> get<2>(grass[i]);
        get<0>(grass[i]) = (rf-rb)*get<1>(grass[i])*get<2>(grass[i]);
    }
    sort(grass+1, grass+n+1, greater<tuple<int, int, int>>());
    while (ind <= n) {
        while (get<1> (grass[ind]) < loc) {
            ind++;
        }
        ans += (rf-rb)*(get<1>(grass[ind])-loc)*get<2>(grass[ind]);
    }
    cout << ans << endl;
    return 0;
}

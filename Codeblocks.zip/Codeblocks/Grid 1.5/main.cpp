#include <bits/stdc++.h>

using namespace std;

int w;
int h;
int x;
pair<int, int> one;
pair<int, int> two;
long long total;

long long factorial(int n) {
    int factorial = 1;
    for (int i = 2; i <= n; i++)
        factorial = factorial * i % (1e9+7);
    return factorial;
}

long long  choose(int a, int b) {
    return factorial(a) / (factorial(b) * factorial(a - b));
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> w;
    cin >> h;
    cin >> x;
    if (x == 0) {
        choose(w+h, w);
    }
    else if (x == 1) {
        cin >> one.first;
        cin >> one.second;
        cout << choose(w+h, w) - choose(one.first+one.second, one.first)*choose(w-one.first+h-one.second, w-one.first) << endl;
    }
    else {

    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int k;
long long sum;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n >> k;
    for (int i = 1; i <= n-1; i++) {
        cout << i << " ";
        sum += i;
    }

    int temp =  ((n/k)+1)*k;
    temp += (k-sum%k);
    cout << temp << endl;
    return 0;
}

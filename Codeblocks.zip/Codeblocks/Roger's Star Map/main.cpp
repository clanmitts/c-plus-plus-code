#include <bits/stdc++.h>

using namespace std;



int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    int row [32001];
    int col [32001];
    int stars [15001][3];
    for (int i = 1; i <= n; i++) {
        cin >> stars[i][1];
        cin >> stars[i][2];
    }

    return 0;
}

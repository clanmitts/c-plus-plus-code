#include <bits/stdc++.h>

using namespace std;

int n;
char arr [500000];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    if (n == 1) {
        cout << 1 << endl;
        cout << 'M' << endl;
    }
    else {
        arr[1] = '_';
        for (int i = 2; i < n; i++) {
            if (arr[i-1] == '_') {
                    arr[i] = 'M';
                    i++;
                    arr[i] = 'M';
            }
            else {
                arr[i] = '_';
                i++;
                arr[i] = '_';
            }
        }
    }
    arr[n] = '_';
    int c = 0;
    for (int i = 1; i <= n; i++) if (arr[i] == 'M') c++;
    cout << c << endl;
    for (int i = 1; i <= n; i++) {
        cout << arr[i];
    }
    cout << endl;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int q;
unordered_map<string, bool> m [400001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i =1; i <= q; i++) {
        int a;
        cin >> a;
        if (a == 1) {
            int b;
            cin >> b;
            string c;
            cin >> c;
            if (m[b][c]) cout << 1 << "\n";
            else cout << 0 << "\n";
        }
        else {
            int b;
            cin >> b;
            string c;
            cin >> c;
            m[b][c] = true;
        }
    }
    return 0;
}

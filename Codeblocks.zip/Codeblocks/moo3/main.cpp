#include <bits/stdc++.h>

using namespace std;

string str;
int n;

void check() {

    if (str[0] == 'o') {
        if (str[1] == 'o') {
            str = 'm' + str;
        }
        else {
            str = "mo" + str;
        }
    }
    if (str[str.length()-1] == 'm') {
        str = str + "oo";
    }
    if (str[str.length()-1] == 'o') {
        if (str[str.length()-2] == 'm') {
            str = str + "o";
        }
    }
    if (str.length()/3 > n) {
        cout << "no" << endl;
        return;
    }
    for (int i = 2; i < str.length(); i += 3) {
        if (str.substr(i-2, 3) != "moo") {
                cout << "no" << endl;
                return;
        }
    }
    cout << "yes" << endl;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str;
    check();
    return 0;
}

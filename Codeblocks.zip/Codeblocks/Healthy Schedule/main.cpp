#include <bits/stdc++.h>

using namespace std;

int s;
int w;

int main()
{
    cin >> s;
    cin >> w;
    w += 24;
    if (20 <= s && s <= 23 && 30 <= w && w <= 33 && 8 <= w-s && w-s <= 10) {
        cout << "Healthy" << endl;
    }
    else {
        cout << "Unhealthy" << endl;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
vector<pair<int, int>> arr [200001];
int leader [200001];
tuple <int, int, int> edge [200001];
vector<pair<int, int>> dijkstra [200001];
int begdis [200001];
bool begvis [200001];
int enddis [200001];
bool endvis [200001];
int s;
int e;
vector<pair<int, int>> extraEdge;

int findLeader(int x) {
    if (leader[x] == x) return x;
    else {
        leader[x] = findLeader(leader[x]);
        return leader[x];
    }
}

void dfsbeg(int x) {
    begvis[x] = true;
    for (pair<int, int> i: dijkstra[x]) {
        if (!begvis[i.first]) {
            begdis[i.first] = begdis[x] + i.second;
            dfsbeg(i.first);
        }
    }
}

void dfsend(int x) {
    endvis[x] = true;
    for (pair<int, int> i: dijkstra[x]) {
        if (!endvis[i.first]) {
            enddis[i.first] = enddis[x] + i.second;
            dfsend(i.first);
        }
    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        int c;
        cin >> a;
        cin >> b;
        cin >> c;
        arr[a].push_back({b, c});
        arr[b].push_back({a, c});
        edge[i] = {c, a, b};
    }
    cin >> s;
    cin >> e;
    sort(edge, edge+m+1);
    for (int i = 1; i <= n; i++) {
            leader[i] = i;
    }
    for (int i = 1; i <= m; i++) {
        if (findLeader(get<1>(edge[i])) != findLeader(get<2>(edge[i]))) {
            dijkstra[get<1>(edge[i])].push_back({get<2>(edge[i]), get<0>(edge[i])});
            dijkstra[get<2>(edge[i])].push_back({get<1>(edge[i]), get<0>(edge[i])});
            leader[findLeader(get<1>(edge[i]))] = findLeader(get<2>(edge[i]));
        }
    }
    dfsbeg(s);
    dfsend(e);
    return 0;
}

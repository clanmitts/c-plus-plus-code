#include <bits/stdc++.h>

using namespace std;

int n;
int q;
long long bit [1000001];
long long num [1000001];

void updateSum(int index, long long val) {
    while (index <= n) {
        bit[index] += val;
        index += (index & -index);
    }
}

long long freqToSum(int index) {
    long long sum = 0;
    while (index > 0) {
        sum += bit[index];
        index -= (index & -index);
    }
    return sum;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
        updateSum(i, num[i]);
    }
    for (int i = 0; i < q; i++) {
        string temp;
        cin >> temp;
        int a = temp[0];
        if (a == '1') {
            int l;
            int r;
            int k;
            cin >> l;
            cin >> r;
            cin >> k;
            for (int i = l; i <= r; i++) updateSum(i, k);
            updateSum(r+1, -k);
            num[l] += k;
        }
        else if (a == '2') {
            int x;
            cout << freqToSum(x)-freqToSum(x-1) << endl;

        }
        else {
            cout << "SOMETHING IS WRONG" << endl;
        }
        cout << "ERER ";
        for (int i = 1;i <= n; i++) {
            cout << freqToSum(i) << " \n"[i == n];
        }
    }
    return 0;
}

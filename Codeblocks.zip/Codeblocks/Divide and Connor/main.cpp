#include <bits/stdc++.h>

using namespace std;

int n;
int arr [1000001];

void divide(int l, int r) {
    if (l == r) cout << arr[l] << " ";
    else {
        int temp = r-l+1;
        temp /= 3;
        divide(l+temp+temp, l+temp+temp+temp-1);
        divide(l, l+temp-1);
        divide(l+temp, l+temp+temp-1);
    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    divide(1, n);
    return 0;
}

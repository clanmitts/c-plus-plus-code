#include <bits/stdc++.h>

using namespace std;

int n;
int num [100001];
long long a;
long long b;
long long c;
long long out = 0;

long long func (int x) {
    long long temp = 0;
    for (int i = 1; i <= n; i++) {
        temp += abs(x-num[i]);
    }
    return temp;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> num[i];
    }
    long long l = -1000000000; long long r = 1000000000;
    long long mid = l+(r-l+1)/2;
    long long ans = func(mid);
    while (l <= r) {
        mid = l+(r-l+1)/2;
        a = func(mid+1);
        b = func(mid-1);
        c = func(mid);
        if (c < ans) {
            ans = c;
            out = mid;
        }
        if (a < b) {
            l = mid+1;
        }
        else {
            r = mid-1;
        }
    }
    cout << out << endl;
    return 0;
}

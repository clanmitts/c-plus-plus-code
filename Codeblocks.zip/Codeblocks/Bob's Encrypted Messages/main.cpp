#include <bits/stdc++.h>

using namespace std;

string a;
string b;
int counter = 0;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> a;
    cin >> b;
    while (counter < 26 && a != b) {
        for (int i = 0; i < a.length(); i++) {
            if (a[i] == 'z') a[i] = 'a';
            else a[i] ++;
        }
        counter ++;
    }
    if (a == b) cout << "Yes" << endl;
    else cout << "No" << endl;
    return 0;
}

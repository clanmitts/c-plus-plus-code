#include <bits/stdc++.h>

using namespace std;

unordered_set<string> s;
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    while (true) {
        string temp;
        cin >> temp;
        if (temp == "exit") break;
        else {
            s.insert(temp);
        }
        cout << s.size() << endl;
    }
    return 0;
}

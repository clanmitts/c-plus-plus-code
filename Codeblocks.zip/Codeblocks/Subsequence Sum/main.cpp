#include <bits/stdc++.h>

using namespace std;

int n;
int arr [1000001];
long long mult;
long long MOD = 1e9+7;
long long total;

long long fast_power(long long base, long long power) {
        int result = 1;
        for (int i = 1; i <= power; i++) {
            result *= 2;
            result %= MOD;
        }
        return result;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    mult = fast_power(2, n-1);
    for (int i = 1; i <= n; i++) cin >> arr[i];
    for (int i = 1; i <= n; i++) {
        total += mult*arr[i];
        total %= MOD;
    }
    if (n == 1) cout << arr[1];
    else cout << total << endl;
    return 0;
}

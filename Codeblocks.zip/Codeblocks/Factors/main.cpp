#include <bits/stdc++.h>

using namespace std;

long long n;
long long total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= sqrt(n); i++) {
        total += max((long)(n/i)*2-1, (long)0);
        cout << (long)(n/i)*2-1 << endl;
    }
    cout << total << endl;
    return 0;
}

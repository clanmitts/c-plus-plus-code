#include <bits/stdc++.h>

using namespace std;

int n;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = n; i >= 1; i --) {
        cout << i << " ";
    }
    cout << endl;
    if (n == 1) cout << 1 << endl;
    else if (n == 2) cout << "1 2" << endl;
    else {
        cout << 1;
        for (int i = 3; i <= n; i++) {
            cout << " " << i;
        }
        cout << " " << 2 << endl;
    }
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
pair<int, int> sorted [1000];
int arr [1000][3];
long long money;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 0; i < n; i ++) {
        cin >> arr[i][1];
    }
    for (int i = 0; i < n; i++) {
        cin >> arr[i][2];
    }
    for (int i = 0; i < n; i++) {
        sorted[i].first = arr[i][1]-arr[i][2];
        sorted[i].second = i;
    }
    sort(sorted, sorted+n);
    for (int i = 0; i < m; i++) {
        money += arr[sorted[i].second][2];
    }
    for (int i = m; i < n; i++) {
        money += arr[sorted[i].second][1];
    }
    cout << money << endl;
    return 0;
}

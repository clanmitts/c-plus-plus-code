#include <bits/stdc++.h>

using namespace std;

int t;
int n;
int arr [100001];
bool win [5000001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    for (int q = 1; q <= t; q++) {
        cin >> n;
        for (int i = 1; i <= n; i++) {
            cin >> arr[i];
        }

    }
    return 0;
}

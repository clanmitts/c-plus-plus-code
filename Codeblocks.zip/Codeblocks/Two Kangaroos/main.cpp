#include <bits/stdc++.h>

using namespace std;

long long x1;
long long y;
long long k;
long long x2;
long long y2;
long long l;
long long hops;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> x1;
    cin >> y;
    cin >> k;
    cin >> x2;
    cin >> y2;
    cin >> l;
    hops += max((abs(x2-x1) + (k-l)-1) / (k-l), (abs(x2-x1) + (l-1)-1) / (l-1));
    hops += max((abs(y2-y) + (k-l)-1) / (k-l), (abs(y2-y) + (l-1)-1) / (l-1));
    cout << hops << endl;
    return 0;
}

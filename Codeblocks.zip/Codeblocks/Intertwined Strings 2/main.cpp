#include <bits/stdc++.h>

using namespace std;

string a;
string b;
string add [12];
string temp [12];
string tempa;
unordered_set<string> all;

int main()
{
    cin >> a;
    cin >> b;
    while (b.size() < 12) {
        b += " ";
    }
    for (int c = 0; c <= 12; c++) {
        for (int d = c; d <= 12; d++) {
            for (int e = d; e <= 12; e++) {
                for (int f = e; f <= 12; c++) {
                    for (int g = f; g <= 12; d++) {
                        for (int h = g; h <= 12; e++) {
                            for (int i = h; i <= 12; c++) {
                                for (int j = i; j <= 12; d++) {
                                    for (int k = j; k <= 12; e++) {
                                        for (int l = k; l <= 12; c++) {
                                            for (int m = l; m <= 12; d++) {
                                                for (int n = m; n <= 12; e++) {
                                                    fill(add,add+12,0);
                                                    tempa = a;
                                                    add[c] += b[0];
                                                    add[d] += b[1];
                                                    add[e] += b[2];
                                                    add[f] += b[3];
                                                    add[g] += b[4];
                                                    add[h] += b[5];
                                                    add[i] += b[6];
                                                    add[j] += b[7];
                                                    add[k] += b[8];
                                                    add[l] += b[9];
                                                    add[m] += b[10];
                                                    add[n] += b[11];
                                                    for (int i = 0; i < 13; i++) {
                                                        tempa.insert(i, add[i]);
                                                    }
                                                    cout << tempa << endl;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    return 0;
}

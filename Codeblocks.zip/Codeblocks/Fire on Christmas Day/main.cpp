#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int arr [100001][3];
int dis [100001][3];
int q;
int closest = 1;
int works = 1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[i][1] = a;
        arr[i][2] = b;
    }
    for (int i = 1; i <= n; i++) {
        while (abs(arr[works][1] - i) <= arr[works][2]) {
            works ++;
            closest ++;
        }
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
vector<int> arr [100001];
int dp [100001];


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i < n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].puch_back(a);
    }

    return 0;
}

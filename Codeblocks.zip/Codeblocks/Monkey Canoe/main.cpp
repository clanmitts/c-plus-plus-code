#include <bits/stdc++.h>

using namespace std;

int n, m;
int grid [12345][24234];
vector<int> arr [124432];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; ++) {

        }
    }
    return 0;
}

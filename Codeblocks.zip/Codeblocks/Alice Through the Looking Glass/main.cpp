#include <bits/stdc++.h>

using namespace std;

int t;
int n;
long long x;
long long y;

bool works(int m) {
    if (m == 1) {
        if ((x == 1 && y == 0) || (x == 2 && y == 0) || (x == 2 && y == 1) || (x == 3 && y == 0)) {
            return true;
        }
        else {
            return false;
        }
    }
    if (x >= pow(5, m-1) && x < 2*pow(5, m-1)) {
        if (y < pow(5, m-1)) {
            return true;
        }
        x -= pow(5, m-1);
        y -= pow(5, m-1);
        return works(m-1);
    }
    else if (x >= 2*pow(5, m-1) && x < 3*pow(5, m-1)) {
        if (y < 2*pow(5, m-1)) {
            return true;
        }
        x -= 2*pow(5, m-1);
        y -= 2*pow(5, m-1);
        return works(m-1);
    }
    else if (x >= 3*pow(5, m-1) &&  x < 4*pow(5, m-1)) {
        if (y < pow(5, m-1)) {
            return true;
        }
        x -= 3*pow(5, m-1);
        y -= pow(5, m-1);
        return works(m-1);
    }
    return false;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        cin >> x;
        cin >> y;
        if (works(n)) {
            cout << "crystal" << endl;
        }
        else {
            cout << "empty" << endl;
        }
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
string arr [3];
int bad;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> arr[1];
    cin >> arr[2];
    for (int i = 0; i < n; i++) {
        if (arr[1][i] == 'S' && arr[2][i] == 'S') {
            bad ++;
        }
    }
    if (bad > 2) cout << "NO";
    else cout << "YES";
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int q;
int arr [100001];

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= n; i++) {
        int temp;
        cin >> temp;
        arr[temp] ++;
    }
    for (int i = 1; i <= q; i++) {
        int temp;
        cin >> temp;
        int y;
        cin >> y;
        if (temp == 1) {
            arr[(y+1)/2] += arr[y];
            arr[y/2] += arr[y];
            arr[y] = 0;
        }
        else if (temp == 2) {
            cout << arr[y] << "\n";
        }
    }
    return 0;
}

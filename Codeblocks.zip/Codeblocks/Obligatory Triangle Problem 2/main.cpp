#include <bits/stdc++.h>

using namespace std;

int n;
float a;
float x;
float y;
double dis = 1000000000;
int ind;
double cur;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> a;
    for (int i = 1; i <= n; i++) {
        cin >> x;
        cin >> y;
        if (x == 0) {
            if (y > 0) {
                cur = tan(0)*180/M_PI;
            }
            else {
                cur = tan(180)*180/M_PI;
            }
        }
    }
    return 0;
}

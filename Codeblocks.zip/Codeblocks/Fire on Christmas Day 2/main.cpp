#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int exits [500001];
int maxdis [500001];
int closestplace[500001];
int closestdis[500001];
int ind = 1;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= n; i++) closestdis[i] = 1000000001;
    for (int i = 1; i <= m; i++) {
        cin >> exits[i];
        cin >> maxdis[i];
    }
    for (int i = 1; i <= n; i++) {
        while (abs(exits[ind]-i) < closestdis[i] && ind <= m) {
                cout << i<< endl;
            if (abs(exits[ind]-i) <= maxdis[ind]) {
                closestdis[i] = abs(exits[ind]-i);
                closestplace[i] = exits[ind];
            }
            ind ++;
        }
    }
    for (int i = 1; i <= n; i++) {
        cout << closestdis[i] << endl;
    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
int m;
vector<pair<int, int>> arr [200002];
priority_queue<pair<long long,int>,vector<pair<long long,int>>,greater<>> begq;
priority_queue<pair<long long,int>,vector<pair<long long,int>>,greater<>> endq;
long long begdis [200001];
long long enddis [200001];
int s;
int e;

bool treevis [200001];
long long treedis [200001];
long long shortestdis = 1e18;

void treedfs(int x, int prev) {
    treevis[x] = true;
    for (pair<int, int> i: arr[x]) {
        if (!treevis[i.first]) {
            treedis[i.first] = treedis[x] + i.second;
            treedfs(i.first, x);
        }
        else if (i.first != prev){
            shortestdis = min(shortestdis, begdis[i.first]+enddis[i.first] + abs(treedis[i.first]-treedis[x]) + i.second);
        }
    }
}

void begbfs() {
    while (begq.size() > 0) {
        auto cur = begq.top();
        begq.pop();
        if (begdis[cur.second] < cur.first) {
            continue;
        }
        for (auto x: arr[cur.second]) {
            if (begdis[x.first] > cur.first + x.second) {
                begdis[x.first] = cur.first + x.second;
                begq.push({begdis[x.first], x.first});
            }
        }
    }
}


void endbfs() {
    while (endq.size() > 0) {
        auto cur = endq.top();
        endq.pop();
        if (enddis[cur.second] < cur.first) {
            continue;
        }
        for (auto x: arr[cur.second]) {
            if (enddis[x.first] > cur.first + x.second) {
                enddis[x.first] = cur.first + x.second;
                endq.push({enddis[x.first], x.first});
            }
        }
    }
}


int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        int c;
        cin >> a;
        cin >> b;
        cin >> c;
        arr[a].push_back({b, c});
        arr[b].push_back({a, c});
    }
    cin >> s;
    cin >> e;
    fill(begdis, begdis+n+1, 1e18);
    fill(enddis, enddis+n+1, 1e18);
    begdis[s] = 0;
    enddis[e] = 0;
    begq.push({0, s});
    begbfs();
    endq.push({0, e});
    endbfs();
    treedfs(s, 0);
    if (shortestdis == 1e18) cout << -1 << endl;
    else cout << shortestdis << endl;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int h;
int a;
int s;
int t;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> h;
    cin >> a;
    cin >> s;
    t = min(h, a);
    t = max(0, t-s);
    cout << t << endl;
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int n;
char str [200002];

int main()
{
    cin >> n;
    scanf("%s", str + 1);

    int ret = 0;
    for (int idx = n; idx >= 2; idx -= 2)
    {
        if (str[idx] == str[idx-1])
            continue;

        if (str[idx] == 'G' && ret % 2 == 1)
            ++ret;

        if (str[idx] == 'H' && ret % 2 == 0)
            ++ret;
    }

    cout << ret << "\n";

    return 0;
}

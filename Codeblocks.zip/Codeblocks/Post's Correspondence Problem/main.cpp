#include <bits/stdc++.h>

using namespace std;

int n, k;
string ans [10000];
int best;
int brute;
string value [2]

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> k;
    for (int i = 1; i <= n; i++) {
        cin >> ans[i];
    }
    for (int i = 0; i < Math.pow(k, 2); i++) {
        for (int j = 1; j <= n; j++)
    }
    return 0;
}

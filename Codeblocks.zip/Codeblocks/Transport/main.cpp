#include <bits/stdc++.h>

using namespace std;

int n;
int fuel [100001];
vector<pair<int, int>> road [100001];
int sts [100001];
bool centroid [100001];
long long total;
map<long long, int> previousPath;
vector<pair<int, long long>> currentPath;
queue<int> q;
bool vis [100001];

int a [100001];
int b [100001];

finda(int cur) {
    q.push(cur);
    fill(vis, vis+n+1, false);
    vis[cur] = true;
    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        for (pair<int, int> i: road[cur]) {
            a[i] = min(a[cur] + )
        }
    }
}

int bit [100001];

void updateSum(int index, long long val) {
    while (index <= n) {
        bit[index] += val;
        index += (index & -index);
    }
}

long long freqToSum(int index) {
    long long sum = 0;
    while (index > 0) {
        sum += bit[index];
        index -= (index & -index);
    }
    return sum;
}


int dfs(int loc, int parent) {
    sts[loc] = 1;
    for (auto x: road[loc]) {
        if (!centroid[x.first] && x.first != parent) {
            sts[loc] += dfs(x.first, loc);
        }
    }
    return sts[loc];
}

int getCentroid(int cur, int parent, int treeSize) {
    for (auto x: road[cur]) {
        if (x.first != parent && !centroid[x.first]) {
           if (sts[x.first] > treeSize) {
                return getCentroid(x.first, cur, treeSize);
           }
        }
    }
    return cur;
}

void dfspath(int cur, int parent, int depth, long long length) {
    currentPath.push_back({depth, length});
    for (auto x: road[cur]) {
        if (x.first != parent && !centroid[x.first]) {
            dfspath(x.first, cur, depth+1, length + x.second);
        }
    }
}

void decomposeTree(int cur) {
    int cent = getCentroid(cur, -1, dfs(cur, -1)/2);
    centroid[cent] = true;
    previousPath[0] = 0;
    for (auto x :road[cent]) {
        if (!centroid[x.first]) {
            fill(a, a+n+1, INT_MIN);
            fill(b, b+n+1, INT_MIN);
            finda(x.first);
            findb(x.first);
        }
    }
    for (auto x: road[cent]) {
        if (!centroid[x.first]) {
            decomposeTree(x.first);
        }
    }
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n;i ++) {
        cin >> fuel[i];
    }
    for (int i = 1; i < n; i++) {
        int x;
        int y;
        int w;
        cin >> x;
        cin >> y;
        cin >> w;
        road[x].push_back({y, w});
        road[y].push_back({x, w});
    }
    decomposeTree(1);
    return 0;
}

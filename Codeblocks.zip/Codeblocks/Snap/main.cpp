#include <bits/stdc++.h>

using namespace std;

int n;
int arr [3000000];
int total;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= 2*n; i++) cin >> arr[i];
    for (int i = 1; i <= n; i++) {
        if (arr[i] == arr[i+n]) total ++;
    }
    cout << total << endl;
    return 0;
}

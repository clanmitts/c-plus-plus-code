#include <bits/stdc++.h>

using namespace std;

int most = 0;
int secondmost = 0;
int frequencya = 0;
int frequencyb = 0;
int n;
int thing [10000001];


int main()
{
    cin >> n;
    for (int i = 0; i < n; i++) {
        int temp;
        cin >> temp;
        thing[temp]++;
    }
    for (int i = 1; i <= 2000000; i++) {
        if (thing[i] > frequencya) {
            frequencya = thing[i];
            most = i;
        }
        else if (thing[i] == frequencya) {
                if (i > most) {
                        most = i;
                }
        }
    }
    secondmost = most;
    thing[most] = 0;
    for (int i = 1; i <= 2000000; i++) {
        if (thing[i] > frequencyb) {
            frequencyb = thing[i];
            secondmost = i;
        }
        else if (thing[i] == frequencyb) {
            if (abs(most - secondmost) < abs(most - i)) secondmost = i;
        }
    }

    cout << abs(most-secondmost) << endl;
    return 0;
}

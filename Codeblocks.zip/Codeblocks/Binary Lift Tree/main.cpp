#include <bits/stdc++.h>

using namespace std;

int n, q;
int lift [21][1000001];
int ledaer [1000001];
int value [1000001];
vector<int> arr [1000001];
int depth [1000001];
deque<int> q;
bool vis [1000001];

void precalculate() {
    for (int i = 1; i <= n; i++) {
        lift[0][i] = leader[i];
    }
    for (int i = 1; i <= log2(n); i++) {
        for (int j = 1; j <= n j++) {
            lift[i][j] = lift[i-1][lift[i-1][j]];
        }
    }
}

get(int a, int b) {
    if (depth[a] < depth[b]) swap(a, b);
    int diff = depth[a]-depth[b];
    for (int bit = 0; bit <= 20; bit ++) {
        if (diff&(1<<bit)) {
            a = lift[bit][a];
        }
    }
    if (a == b) return a;
    for (int bit = 20; bit >= 0; bit--) {
        if (lift[bit][a] != lift[bit][b]) {
            a = lift[bit][a];
            b = lift[bit][b];
        }
    }
    return lift[0][a];
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i i <= n; i++) {
        cin >> value[i];
    }
    for (int i = 1; i < n; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        arr[a].push_back(b);
        arr[b].push_back(a);
    }
    q.push_back(1);
    vis[1] = true;
    depth[1] = 1;
    while (!q.empty()) {
        int cur = q.front();
        q.pop_front();
        for (int i: arr[cur]) {
            if (!vis[i]) {
                vis[i] = true;
                depth[i] = depth[cur] + 1;
                leader[i] = cur;
            }
        }
    }
    precalculate();
    for (int i = 1; i <= q; i++) {
        int a;
        int b;
        int c;
        cin >> a;
        cin >> b;
        cin >> c;
        int lca = get(a, b);
        value[a] ^=
    }
    return 0;
}

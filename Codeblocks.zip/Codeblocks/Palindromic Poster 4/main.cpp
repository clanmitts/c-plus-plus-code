#include <bits/stdc++.h>

using namespace std;
int n;
int m;
int r;
int c;
char grid [1000][1000];

bool isPalindrome(string str) {
    int n = str.length();
    for (int i=0; i<n/2; i++) {
        if (str[i] != str[n-i-1]) {
            return false;
        }
    }
    return true;
}


int32_t main() {
    cin >> n;
    cin >> m;
    cin >> r;
    cin >> c;
    for (int i=1; i<=n; i++) {
        for (int j=1; j<=m; j++) {
            grid[i][j] = 'a';
        }
    }
    if (r == 0 && c == 0 && n == 2 && m == 2) {
        cout << "ab\nba\n";
        return false;
    }
    if (r == 0 && c == 0 && n == 1 && m == 1) {
        cout << "IMPOSSIBLE" << endl;
        return false;
    }
    if (r == n && c != m && m%2 == 1) {
        if (c%2 == 0) {
            int a = c/2 + 1;
            int b = c/2 + 1 + m - c - 1;
            for (int i = 2; i<=n; i++) {
                for (int j = a; j <= b; j++) {
                    grid[i][j] = 'b';
                }
            }
        }
        else {
            for (int i=2; i<=n; i++) {
                int start = 1;
                int total = 0;
                int adder = m-1;
                while (total < m - c) {
                    grid[i][start] = 'b';
                    grid[i][start+adder] = 'b';
                    total += 2;
                    adder -= 2;
                    start++;
                }
            }
        }
        for (int i=1; i<=n; i++) {
            for (int j=1; j<=m; j++) {
                cout << grid[i][j];
            }
            cout << endl;
        }
        return false;
    }
    if (c == m && r != n && n%2 == 1 && r != 0) {
        if (r%2 == 0) {
            int start = r/2 + 1;
            int en = r/2 + 1 + n - r - 1;
            for (int i = 2; i<=m; i++) {
                for (int j = start; j <= en; j++) {
                    grid[j][i] = 'b';
                }
            }
        }
        else {
            for (int i=2; i<=m; i++) {
                grid[1][i] = 'b';
                grid[n][i] = 'b';
            }
        }
        for (int i=1; i<=n; i++) {
            for (int j=1; j<=m; j++) {
                cout << grid[i][j];
            }
            cout << endl;
        }
        return false;
    }
    if (r == n && c != m && m%2==0) {
        if (c%2 == 1) {
            cout << "IMPOSSIBLE" << endl;
            return false;
        }
        else {
            for (int i=2; i<=n; i++) {
                int start = 1;
                int total = 0;
                int adder = m-1;
                while (total < m - c) {
                    grid[i][start] = 'b';
                    grid[i][start+adder] = 'b';
                    total += 2;
                    adder -= 2;
                    start++;
                }
            }
        }
        for (int i=1; i<=n; i++) {
            for (int j=1; j<=m; j++) {
                cout << grid[i][j];
            }
            cout << endl;
        }
        return false;
    }
    if (c == m && r != n && n%2==0 && r != 0) {
        if (r%2 == 1) {
            cout << "IMPOSSIBLE" << endl;
            return false;
        }
        else {
            for (int i=(r+2)/2; i<=n - (r+2)/2 + 1; i++) {
                int start = 2;
                int total = 0;
                int adder = n-1;
                while (total < n - r) {
                    grid[i][start] = 'b';
                    grid[i][start+adder] = 'b';
                    total += 2;
                    adder -= 2;
                    start++;
                }
            }
        }
        for (int i=1; i<=n; i++) {
            for (int j=1; j<=m; j++) {
                cout << grid[i][j];
            }
            cout << endl;
        }
        return false;
    }
    for (int i=r+1; i<=n; i++) {
        grid[i][m] = 'c';
    }
    for (int i=c+1; i<=m; i++) {
        if (grid[n][i] == 'c') grid[n][i] = 'd';
        else grid[n][i] = 'b';
    }
    int rp = 0;
    for (int i=1; i<=n; i++) {
        string abc;
        for (int j=1; j<=m; j++) {
            abc += grid[i][j];
        }
        if (isPalindrome(abc)) rp++;
    }
    int cp = 0;
    for (int i=1; i<=m; i++) {
        string abc;
        for (int j=1; j<=n; j++) {
            abc += grid[j][i];
        }
        if (isPalindrome(abc)) cp++;
    }
    if (rp == r && cp == c) {
        for (int i=1; i<=n; i++) {
            for (int j=1; j<=m; j++) {
                cout << grid[i][j];
            }
            cout << endl;
        }
    }
    else cout << "IMPOSSIBLE" << endl;
}

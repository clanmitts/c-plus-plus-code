#include <bits/stdc++.h>

using namespace std;

long long arr [100001];
int n;
int a;
int b;
int c;
int ind;

long long first() {
    a = n;
    b = n-1;
    c = n-2;
    while (c > 3) {
        if ((long long)(arr[c])+(long long)(arr[b]) > (long long)(arr[a])) {
            ind = c;
            return ((long long) (arr[c] + arr[b] + arr[a]));
        }
        a--;
        b--;
        c--;
    }
    return -1;
}

long long second() {
    a = c-1;
    b = c-2;
    c = c-3;
    while (c > 0) {
        if (arr[c] + arr[b] > arr[a]) {
            return (arr[c] + arr[b] + arr[a]);
        }
        a--;
        b--;
        c--;
    }
    return -1;
}

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    sort(arr+1, arr+n+1);
    if (n < 6) cout << 0 << endl;
    else {
        long long x = first();
        long long y = second();
        if(x < 0 ) {
                cout << 0 << endl;
        }
        else if (y < 0) {
            if ((arr[ind-3]+arr[ind-1] > arr[ind] && arr[ind-2]+arr[ind+1] > arr[ind+2]) || (arr[ind-2]+arr[ind-1] > arr[ind] && arr[ind-3]+arr[ind+1] > arr[ind+2]) || (arr[ind-3]+arr[ind-2] > arr[ind] && arr[ind-1]+arr[ind+1] > arr[ind+2])) {
                cout << (arr[ind-3] + arr[ind-2] + arr[ind-1] + arr[ind] + arr[ind+1] + arr[ind+2]);
            }
            else cout << 0 << endl;
        }
        else cout << (x+y) << endl;
    }
    return 0;
}

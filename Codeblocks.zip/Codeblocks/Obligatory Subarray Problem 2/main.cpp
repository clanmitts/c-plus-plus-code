#include <bits/stdc++.h>

using namespace std;

int n;
int b;
int t;
int num [1000001];
unordered_map<int, int> freq;
long long total;
int l = 1;
int r = 1;
int temp;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> b;
    cin >> t;
    for (int i = 1; i <= n; i++) {
            cin >> num[i];
            num[i] += 1000000;
    }
    sort(num, num+n+1);
    num[n+1] = 9999999;
    for (int i = 1; i <= n; i++) {
        if (freq.count(num[i]) > 0) {
            freq.at(num[i])++;
        }
        else {
            freq.insert({num[i], 1});
        }
    }
    for (int i = 1; i <= n; i++) cout << num[i] << endl;
    for (r = 1; r <= n; r++) {
        while (num[r]-num[l] > t) l++;
        if (num[r]-num[l] >= b) total += (freq.at(num[r]))*(freq.at(num[l]))*(l-r-freq.at(num[l])+1);
        temp = r;
        cout << l << " " << r << " " << total << endl;
        while (num[r] == num[temp]) r++;
        r--;
        cout << l << " " << r << " " << total << endl;
    }
    cout << total << endl;
    return 0;
}

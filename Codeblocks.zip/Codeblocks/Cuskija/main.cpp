#include <bits/stdc++.h>

using namespace std;

int n;
int arr [10001];
int out [10001];
vector<int> zero;
vector<int> one;
vector<int> two;

bool works() {
    for (int i = 1; i <= n; i++) {
        if (out[i-1]%3 == 0) {
            if (one.size() > 0) {
                out[i] = one.back();
                one.pop_back();
            }
            else if (two.size() > 0) {
                out[i] = two.back();
                two.pop_back();
            }
            else return false;
        }
        else if (out[i-1]%3 == 1) {
            if (zero.size() > 0) {
                out[i] = zero.back();
                zero.pop_back();
            }
            else if (one.size() > 0) {
                out[i] = one.back();
                one.pop_back();
            }
            else return false;
        }
        else if (out[i-1]%3 == 2) {
            if (zero.size() > 0) {
                out[i] = zero.back();
                zero.pop_back();
            }
            else if (two.size() > 0) {
                out[i] = two.back();
                two.pop_back();
            }
            else return false;
        }
    }
    return true;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    for (int i = 1; i <= n; i++) {
        if (arr[i]%3 == 0) zero.push_back(arr[i]);
        else if (arr[i]%3 == 1) one.push_back(arr[i]);
        else if (arr[i]%3 == 2) two.push_back(arr[i]);
    }
    out[0] = 1;
    if (works()) {
        for (int i = 1; i <= n; i++) cout << out[i] << " \n"[i==n];
    }
    else {
        for (int i = 1; i <= n; i++) {
            if (arr[i]%3 == 0) zero.push_back(arr[i]);
            else if (arr[i]%3 == 1) one.push_back(arr[i]);
            else if (arr[i]%3 == 2) two.push_back(arr[i]);
        }
        out[0] = 0;
        if (works()) {
            for (int i = 1; i <= n; i++) cout << out[i] << " \n"[i==n];
        }
        else {
            for (int i = 1; i <= n; i++) {
                if (arr[i]%3 == 0) zero.push_back(arr[i]);
                else if (arr[i]%3 == 1) one.push_back(arr[i]);
                else if (arr[i]%3 == 2) two.push_back(arr[i]);
            }
            out[0] = 2;
            if (works()) {
                for (int i = 1; i <= n; i++) cout << out[i] << " \n"[i==n];
            }
            else cout << "impossible\n" << endl;
        }
    }
    return 0;
}

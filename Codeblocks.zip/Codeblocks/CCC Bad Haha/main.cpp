#include <bits/stdc++.h>

using namespace std;

int t;
string str;
char n [200001] ;
int k;
int index;
pair<int, int> best [200000];

int main()
{
    cin >> t;
    for (int q = 1; q <= t; q++) {
        best[0].first = 12904876;
        cin >> str;
        for (int i = 1; i <= str.length(); i++) {
            n[i] = str[i-1];
        }
        cin >> k;
        index = k;
        for (int i = 1; i <= str.length(); i++) {
            if (best[i].first < best[i-1].first) {
                best[i].first = n[i];
                best[i].second = i;
            }
            else {
                best[i].first = best[i-1].first;
                best[i].second = best[i-1].second;
            }
        }
    }
    return 0;
}

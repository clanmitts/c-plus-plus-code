#include <bits/stdc++.h>

using namespace std;

int n;
int q;
long long num [1000001];
long long bit [1000001];
int a, k, l, r, x;

void updateSum(int index, long long val) {
    while (index <= n) {
        bit[index] += val;
        index += (index & -index);
    }
}

long long freqToSum(int index) {
    long long sum = 0;
    while (index > 0) {
        sum += bit[index];
        index -= (index & -index);
    }
    return sum;
}

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> q;
    for (int i = 1; i <= q; i++) {
        cin >> a;
        if (a == 1) {
            cin >> l;
            cin >> r;
            cin >> k;
            updateSum(l, k);
            updateSum(r+1, -k);
        }
        else {
            cin >> x;
            cout << freqToSum(x) << endl;
        }
    }
    return 0;
}

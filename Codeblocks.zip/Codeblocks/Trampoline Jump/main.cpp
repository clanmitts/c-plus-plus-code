#include <bits/stdc++.h>

using namespace std;

int n;
long arr [500001];
int dis [500001];
queue<int> q;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    arr[1] = 1;
    arr[2] = 1;
    for (int i = 3; i <= n; i++) arr[i] = (arr[i-1] + arr[i-2])%2021;
    for (int i = 1; i <= n; i++) arr[i] += (i%50);
    fill(dis, dis+n+1, INT_MAX);
    dis[1] = 0;
    q.push(1);
    while (!q.empty()) {
        int cur = q.back();
        q.pop();
        if (cur + arr[cur] <= n) {
            if (dis[cur]+1 < dis[cur+(int)arr[cur]]) {
                q.push(cur+(int)arr[cur]);
                dis[cur+(int)arr[cur]] = dis[cur]+1;
            }
        }
        if (cur < n) {
            if (dis[cur]+1 < dis[cur+1]) {
                q.push(cur+1);
                dis[cur+1] = dis[cur]+1;
            }
        }
        if (cur-arr[cur] >= 1) {
            if (dis[cur]+1 < dis[cur-(int)arr[cur]]) {
                q.push(cur-(int)arr[cur]);
                dis[cur-(int)arr[cur]] = dis[cur]+1;
            }
        }
        if (cur >= 1) {
            if (dis[cur]+1 < dis[cur-1]) {
                q.push(cur-1);
                dis[cur-1] = dis[cur]+1;
            }
        }
    }
    cout << dis[n] << "\n";
    return 0;
}

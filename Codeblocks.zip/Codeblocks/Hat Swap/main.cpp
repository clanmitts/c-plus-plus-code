#include <bits/stdc++.h>

using namespace std;

class s {
public:
    int a;
    int b;
};

int n;
int m;
int hat [1000001];
list<s> arr [1000001];
int shiroganea [1000001];
int shiroganeb [1000001];
bool shiroganevis [1000001];
int shiroganedis [1000001];
int kaguyaa [1000001];
int kaguyab[1000001];
bool kaguyavis [1000001];
int kaguyadis [1000001];
int small;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i =1; i <= n; i++) {
        cin >> hat[n];
    }
    for (int i = 1; i <= m; i++) {
        int a;
        int b;
        cin >> a;
        cin >> b;
        s temp;
        temp.a = b;
        temp.b = i;
        arr[a].push_back(temp);
        temp.a = a;
        temp.b = i;
        arr[b].push_back(temp);
    }
    deque<s> d;
    s temp;
    temp.a = 1;
    temp.b =0;
    d.push_back(temp);
    shiroganevis[temp.a] = true;
    while (!d.empty()) {
        temp = d.front();
        d.pop_front();
        for (s i: arr[temp.a]) {
            if (!shiroganevis[i.a]) {
                shiroganedis[i.a] = shiroganedis[temp.a]+1;
                shiroganevis[i.a] = true;
                if (!shiroganea[i.b]) {
                    shiroganea[i.b] = shiroganedis[i.a];
                }
                else if (!shiroganeb[i.b]) {
                    shiroganeb[i.b] = shiroganedis[i.a];
                }
                d.push_back(i);
            }
        }
    }
    temp.a = n;
    temp.b =0;
    d.push_back(temp);
    kaguyavis[temp.a] = true;
    while (!d.empty()) {
        temp = d.front();
        d.pop_front();
        for (s i: arr[temp.a]) {
            if (!kaguyavis[i.a]) {
                kaguyadis[i.a] = kaguyadis[temp.a]+1;
                kaguyavis[i.a] = true;
                if (!kaguyaa[i.b]) {
                    kaguyaa[i.b] = kaguyadis[i.a];
                }
                else if (!kaguyab[i.b]) {
                    kaguyab[i.b] = kaguyadis[i.a];
                }
                d.push_back(i);
            }
        }
    }
    if (hat[1] == hat[n]) cout << 0 << endl;
    small = 1000000000;
    for (int i = 1; i <= n; i++) {
        cout << shiroganea[i] << " " << kaguyaa[i] << endl;
        if (!shiroganea[i] && !kaguyaa[i] && shiroganea[i] != kaguyaa[i]) {
            small = min(small, shiroganea[i] + kaguyaa[i]);
        }
        else if (!shiroganeb[i]) {
            small = min(small, shiroganeb[i] + kaguyaa[i]);
        }
        else if (!kaguyab[i]) {
            small = min(small, shiroganea[i] + kaguyab[i]);
        }
    }
    cout << small;
    return 0;
}

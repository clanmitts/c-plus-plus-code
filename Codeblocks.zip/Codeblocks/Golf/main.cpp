#include <bits/stdc++.h>

using namespace std;

int d;
int n;
int balls [100000];
int dis [60000];
queue<int> q;

int main()
{
        cin >> d;
		cin >> n;
		for (int i = 0; i < n; i++) {
			cin >> balls[i];
		}
		fill(begin(dis), begin(dis) + 6000, 1e9);
		dis[0] = 0;
		q.push(0);
		while (!q.empty()) {
			int cur = q.back();
			q.pop();
			if (cur < d) {
				for (int i: balls) {
					if (dis[cur]+1 < dis[cur+i]) {
						dis[cur+i] = dis[cur]+1;
						q.push(cur+i);
					}
				}
			}
		}
		if (dis[d] == 1e9) {
			cout << ("Roberta acknowledges defeat.");
		}
		else {
			cout << "Roberta wins in " << dis[d] << " strokes.";
		}
    return 0;
}

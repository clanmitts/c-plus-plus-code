#include <bits/stdc++.h>

using namespace std;

long long n;
long long out;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    out = floor(sqrt(n));
    cout << out << endl;
    return 0;
}

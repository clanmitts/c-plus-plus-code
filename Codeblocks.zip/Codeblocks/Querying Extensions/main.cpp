#include <bits/stdc++.h>

using namespace std;

int n;
string str;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str;
    if (str == "left") {
        if (n % 2 == 1) cout << "left" << endl;
        else cout << "right" << endl;
    }
    else {
        if (n % 2 == 1) cout << "right" << endl;
        else cout << "left" << endl;
    }
    return 0;
}

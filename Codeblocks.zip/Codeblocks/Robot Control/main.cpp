#include <bits/stdc++.h>

using namespace std;

int n;
int m;
int p [100001];
long long total;
vector<int> space;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        cin >> p[i];
    }
    sort(p+1, p+m+1);
    for (int i = 1; i < m; i++) {
        space.push_back(p[i+1]-p[i]);
    };
    if (n >= m) cout << 0 << endl;
    else {
        sort(space.begin(), space.end());
        for (int i = 0; i < m-n; i++) {
            total += space[i];
        }
        cout << total << endl;
    }
    return 0;
}

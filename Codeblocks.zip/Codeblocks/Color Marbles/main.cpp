#include <bits/stdc++.h>

using namespace std;

int n;
string str;
int minimum;
int temp;

int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    cin >> n;
    cin >> str;
    for (char i: str) if (i == 'r') minimum ++;
    temp = minimum;
    for (int i = 0; i < n; i++) {
        if (str[i] == 'r') temp--;
        else if (str[i] == 'b') temp++;
        minimum = min(minimum, temp);
    }
    cout << minimum << endl;
    return 0;
}

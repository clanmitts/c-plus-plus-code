#include <bits/stdc++.h>

using namespace std;

int t;
string s1;
string s2;
vector<int> tree_top [1000];
int tree_bottom [100001];
bool used [1000];
bool toppivot [1000];
bool bottompivot [1000];
int countpivot;
unordered_set<int> tempused;


int total = 0;

int check() {
    total = 0;
    fill(used, used+300, false);
    fill(toppivot, toppivot+300, false);
    fill(bottompivot, bottompivot+300, false);
    countpivot = 0;

    for (int i = 'A'; i <= 'z'; i++) {
        tempused.clear();
        if (!toppivot[i]) {
            toppivot[i] = true;
            countpivot++;
        }
        for (int j: tree_top[i]) {
            tempused.insert(s1[j]);
        }
        for (int j: tempused) {
            if (used[j]) return -1;
            used[j] = true;
        }
        for (int j: tree_top[i]) {
            if (i == s1[j]) ;
            else {
                total ++;
            }
        }
    }
    return total;
}

int main()
{
    cin >> t;
    for (int q = 1; q <= t; q++) {
        cin >> s1;
        cin >> s2;
        for (int i = 0; i <= s1.length(); i++) {
            tree_bottom[i] = s1[i];
        }
        for (int i = 0; i <= s2.length(); i++) {
            tree_top[s2[i]].push_back(i);
        }
    }
    check();
    return 0;
}
